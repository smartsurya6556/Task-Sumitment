const fs = require('fs');
const path = require('path');

// Load script.js
const scriptContent = fs.readFileSync(path.join(__dirname, '..', 'script.js'), 'utf8');

// Extract INVENTIONS_DATA JSON
const match = scriptContent.match(/const INVENTIONS_DATA = (\[[\s\S]*?\]);\n\nconst CATEGORIES_CONFIG/);
if (!match) {
  console.log('Could not extract INVENTIONS_DATA');
  process.exit(1);
}

const data = eval(match[1]);
console.log(`Loaded ${data.length} dossiers for validation`);

let errorCount = 0;
data.forEach((item, idx) => {
  try {
    // Check all fields that openArticleModal accesses:
    if (!item.id) throw new Error('Missing id');
    if (!item.commonName) throw new Error('Missing commonName');
    if (!item.title) throw new Error('Missing title');
    if (!item.category) throw new Error('Missing category');
    if (!item.period) throw new Error('Missing period');
    if (!item.subtitle) throw new Error('Missing subtitle');
    if (!item.who) throw new Error('Missing who');
    if (!item.when) throw new Error('Missing when');
    if (!item.where) throw new Error('Missing where');
    if (!item.whatIsIt) throw new Error('Missing whatIsIt');
    if (!item.whyCreated) throw new Error('Missing whyCreated');
    if (!item.problemBefore) throw new Error('Missing problemBefore');
    if (!item.olderUsage) throw new Error('Missing olderUsage');
    if (!item.limitations) throw new Error('Missing limitations');
    if (!item.whyEvolved) throw new Error('Missing whyEvolved');
    if (!Array.isArray(item.evolutionSteps)) throw new Error('evolutionSteps is not array');
    item.evolutionSteps.forEach((step, sIdx) => {
      if (typeof step !== 'object' || !step.era || !step.text) {
        throw new Error(`Invalid step at index ${sIdx}: ${JSON.stringify(step)}`);
      }
    });
    if (!item.modernVersion) throw new Error('Missing modernVersion');
    if (!item.modernUsage) throw new Error('Missing modernUsage');
    if (!item.futureOutlook) throw new Error('Missing futureOutlook');
    if (!item.comparison) throw new Error('Missing comparison');
    const comp = item.comparison;
    if (!comp.size || !comp.speed || !comp.function || !comp.connectivity || !comp.power || !comp.userExperience) {
      throw new Error(`Incomplete comparison object: ${JSON.stringify(comp)}`);
    }
  } catch (err) {
    errorCount++;
    console.error(`❌ Item ${idx} (${item ? item.id : 'unknown'}): ${err.message}`);
  }
});

if (errorCount === 0) {
  console.log(`✓ All ${data.length} dossiers pass 100% of openArticleModal data access tests!`);
} else {
  console.log(`Found ${errorCount} errors`);
}

const fs = require('fs');
const path = require('path');

// ============================================================================
// 20 SPECIALIZED DOMAINS: 10 HUMAN C&E + 10 FAUNA & AVES C&E (400+ TOPICS)
// ============================================================================

const humanDomains = [
  {
    name: "Transportation",
    label: "Transportation",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>`,
    items: [
      { id: "wheel", title: "Solid Wooden Wheel & Axle", period: "c. 3500 BCE", who: "Mesopotamian & Eurasian craftspeople", where: "Mesopotamia & Steppes" },
      { id: "chariot", title: "Two-Wheeled Spoked Chariot", period: "c. 2000 BCE", who: "Sintashta-Petrovka culture", where: "Eurasian Steppes & Near East" },
      { id: "sailing-ship", title: "Sailing Ship & Sternpost Rudder", period: "c. 3000 BCE / 1st c.", who: "Egyptian & Han Chinese shipwrights", where: "Mediterranean & China" },
      { id: "magnetic-compass", title: "Magnetic Mariner's Compass", period: "c. 200 BCE / 11th c.", who: "Han & Song Dynasty scholars (Shen Kuo)", where: "China" },
      { id: "horseshoe-stirrup", title: "Iron Horseshoe & Riding Stirrup", period: "c. 4th c.", who: "Northern Dynasties & Eurasian cavalry", where: "Eurasia & Rome" },
      { id: "stagecoach", title: "Suspended Travel Stagecoach", period: "16th c.", who: "Hungarian & European coachbuilders", where: "Kocs, Hungary & England" },
      { id: "hot-air-balloon", title: "Hot Air Balloon", period: "1783", who: "Montgolfier Brothers", where: "Paris, France" },
      { id: "steamboat", title: "Commercial Steamship (Clermont)", period: "1807", who: "Robert Fulton & Robert Livingston", where: "New York, USA" },
      { id: "steam-locomotive", title: "Steam Locomotive & Railway Track", period: "1804/1814", who: "Richard Trevithick & George Stephenson", where: "United Kingdom" },
      { id: "bicycle", title: "Bicycle (Dandy Horse to Safety Bike)", period: "1817/1885", who: "Karl von Drais & John Kemp Starley", where: "Germany & UK" },
      { id: "ocean-liner", title: "Iron Ocean Liner (SS Great Britain)", period: "1843", who: "Isambard Kingdom Brunel", where: "Bristol, UK" },
      { id: "pneumatic-tire", title: "Pneumatic Rubber Tire", period: "1845/1888", who: "Robert Thomson & John Boyd Dunlop", where: "Scotland & Ireland" },
      { id: "cable-car", title: "Urban Cable Car & Funicular", period: "1873", who: "Andrew Smith Hallidie", where: "San Francisco, USA" },
      { id: "electric-tram", title: "Electric Tram & Streetcar", period: "1881", who: "Werner von Siemens & Frank Sprague", where: "Berlin & Richmond, USA" },
      { id: "motorcycle", title: "Internal Combustion Motorcycle", period: "1885", who: "Gottlieb Daimler & Wilhelm Maybach", where: "Stuttgart, Germany" },
      { id: "automobile", title: "Gasoline-Powered Automobile", period: "1886", who: "Karl Benz & Bertha Benz", where: "Mannheim, Germany" },
      { id: "diesel-engine", title: "Compression-Ignition Diesel Engine", period: "1893", who: "Rudolf Diesel", where: "Augsburg, Germany" },
      { id: "submarine", title: "Naval Submarine & Submersible", period: "1900", who: "John Philip Holland", where: "Ireland & USA" },
      { id: "airship-zeppelin", title: "Rigid Airship (Zeppelin)", period: "1900", who: "Count Ferdinand von Zeppelin", where: "Friedrichshafen, Germany" },
      { id: "airplane", title: "Powered Airplane", period: "1903", who: "Orville & Wilbur Wright", where: "Kitty Hawk, NC, USA" },
      { id: "jet-engine", title: "Turbojet & Turbofan Engine", period: "1937/1939", who: "Sir Frank Whittle & Hans von Ohain", where: "UK & Germany" }
    ]
  },
  {
    name: "Communication",
    label: "Communication",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"></path></svg>`,
    items: [
      { id: "cuneiform-tablets", title: "Cuneiform Writing & Clay Tablets", period: "c. 3200 BCE", who: "Sumerian scribes", where: "Uruk, Mesopotamia" },
      { id: "papyrus-scroll", title: "Papyrus & Animal Parchment", period: "c. 3000 BCE", who: "Ancient Egyptian & Pergamene scribes", where: "Egypt & Asia Minor" },
      { id: "paper-making", title: "Cellulose Paper Making", period: "105 CE", who: "Cai Lun", where: "Luoyang, Han China" },
      { id: "postal-courier", title: "Standardized Postal Relay System", period: "c. 550 BCE", who: "Cyrus the Great (Chapar Khaneh)", where: "Persia (Iran)" },
      { id: "printing-press", title: "Movable Type Printing Press", period: "1440", who: "Johannes Gutenberg & Bi Sheng", where: "Mainz, Germany" },
      { id: "optical-semaphore", title: "Optical Semaphore Telegraph", period: "1792", who: "Claude Chappe", where: "Paris, France" },
      { id: "braille-system", title: "Braille Tactile Writing System", period: "1824", who: "Louis Braille", where: "Paris, France" },
      { id: "postage-stamp", title: "Adhesive Uniform Postage Stamp", period: "1840", who: "Sir Rowland Hill", where: "London, UK" },
      { id: "electric-telegraph", title: "Electric Telegraph & Morse Code", period: "1837", who: "Samuel Morse, Alfred Vail, Cooke & Wheatstone", where: "USA & UK" },
      { id: "transatlantic-cable", title: "Submarine Transatlantic Cable", period: "1858/1866", who: "Cyrus Field & Lord Kelvin", where: "Atlantic Ocean" },
      { id: "typewriter", title: "Mechanical Typewriter & QWERTY", period: "1868", who: "Christopher Latham Sholes", where: "Milwaukee, USA" },
      { id: "telephone", title: "Electric Voice Telephone", period: "1876", who: "Alexander Graham Bell & Antonio Meucci", where: "Boston, USA" },
      { id: "switchboard", title: "Automatic Telephone Switchboard", period: "1889/1891", who: "Almon Brown Strowger", where: "Kansas City, USA" },
      { id: "radio", title: "Wireless Radio Telecommunications", period: "1890s", who: "Marconi, Tesla, Bose & Hertz", where: "Italy, USA, India, Germany" },
      { id: "am-broadcast", title: "AM Audio Radio Broadcasting", period: "1906/1920", who: "Reginald Fessenden & Frank Conrad", where: "USA" },
      { id: "teleprinter", title: "Teleprinter & Telex Network", period: "1910s", who: "Donald Murray & Edward Kleinschmidt", where: "USA & UK" },
      { id: "fm-radio", title: "Frequency Modulation (FM) Radio", period: "1933", who: "Edwin Howard Armstrong", where: "New York City, USA" },
      { id: "walkie-talkie", title: "Handheld Two-Way Radio", period: "1940", who: "Al Gross, Donald Hings & Motorola", where: "Canada & USA" },
      { id: "satellite-comms", title: "Communications Satellites (Telstar)", period: "1962", who: "Arthur C. Clarke, John Pierce & NASA", where: "USA & France" },
      { id: "touch-tone-phone", title: "Touch-Tone Push-Button Dialing", period: "1963", who: "Bell Telephone Laboratories", where: "New Jersey, USA" },
      { id: "fiber-optics", title: "Optical Fiber & Photonic Cables", period: "1970", who: "Charles K. Kao & Corning Glass", where: "UK & USA" }
    ]
  },
  {
    name: "Computing",
    label: "Computing & AI",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path></svg>`,
    items: [
      { id: "abacus", title: "Bead Frame Abacus & Suanpan", period: "c. 2700 BCE", who: "Mesopotamian & Chinese mathematicians", where: "Mesopotamia & China" },
      { id: "antikythera-mechanism", title: "Antikythera Astronomical Computer", period: "c. 150 BCE", who: "Hellenistic Greek scientists", where: "Rhodes / Greece" },
      { id: "slide-rule", title: "Analog Calculation Slide Rule", period: "1622", who: "William Oughtred & Edmund Gunter", where: "London, England" },
      { id: "mechanical-calculator", title: "Mechanical Calculator (Pascaline)", period: "1642", who: "Blaise Pascal", where: "Rouen, France" },
      { id: "stepped-reckoner", title: "Leibniz Stepped Reckoner & Binary", period: "1673", who: "Gottfried Wilhelm Leibniz", where: "Leipzig, Germany" },
      { id: "jacquard-loom", title: "Jacquard Punched-Card Control", period: "1804", who: "Joseph Marie Jacquard", where: "Lyon, France" },
      { id: "analytical-engine", title: "Babbage's Analytical Engine", period: "1837", who: "Charles Babbage", where: "London, England" },
      { id: "first-algorithm", title: "Ada Lovelace's Machine Algorithm", period: "1843", who: "Ada Lovelace", where: "London, England" },
      { id: "boolean-algebra", title: "Boolean Logic & Binary Circuits", period: "1854/1937", who: "George Boole & Claude Shannon", where: "Ireland & MIT" },
      { id: "hollerith-tabulator", title: "Hollerith Tabulating Machine", period: "1890", who: "Herman Hollerith (IBM)", where: "Washington, USA" },
      { id: "turing-machine", title: "Universal Turing Machine", period: "1936", who: "Alan Turing", where: "Cambridge, UK" },
      { id: "colossus-computer", title: "Colossus Codebreaking Computer", period: "1943", who: "Tommy Flowers & Max Newman", where: "Bletchley Park, UK" },
      { id: "electronic-computers", title: "ENIAC Electronic Computer", period: "1945", who: "J. Presper Eckert & John Mauchly", where: "Philadelphia, USA" },
      { id: "transistor", title: "Solid-State Semiconductor Transistor", period: "1947", who: "Bardeen, Brattain & Shockley", where: "Bell Labs, USA" },
      { id: "magnetic-core-memory", title: "Magnetic Core RAM Memory", period: "1949", who: "An Wang & Jay Forrester", where: "MIT, USA" },
      { id: "compiler-cobol", title: "Compiler & COBOL Programming", period: "1952/1959", who: "Grace Hopper", where: "USA" },
      { id: "hard-disk-drive", title: "Magnetic Hard Disk (RAMAC)", period: "1956", who: "Reynold B. Johnson & IBM", where: "San Jose, USA" },
      { id: "integrated-circuit", title: "Silicon Integrated Circuit (IC)", period: "1958", who: "Jack Kilby & Robert Noyce", where: "Texas & California" },
      { id: "computer-mouse", title: "Computer Mouse & GUI Windowing", period: "1968", who: "Douglas Engelbart", where: "San Francisco, USA" },
      { id: "microprocessor", title: "Single-Chip Microprocessor (4004)", period: "1971", who: "Faggin, Hoff, Mazor & Shima", where: "Santa Clara, USA" },
      { id: "artificial-intelligence", title: "Neural Deep Learning & Transformer AI", period: "1956/2017", who: "Hinton, LeCun, Bengio, Vaswani et al.", where: "Global Research" }
    ]
  },
  {
    name: "Home",
    label: "Home & Living",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>`,
    items: [
      { id: "soap-detergent", title: "Saponified Chemical Soap", period: "c. 2800 BCE", who: "Babylonian & Egyptian chemists", where: "Babylon & Egypt" },
      { id: "mechanical-clock", title: "Mechanical Verge Clock", period: "c. 1275", who: "European monastic clockmakers", where: "Salisbury & Milan" },
      { id: "spectacles", title: "Reading Spectacles", period: "1286", who: "Salvino D'Armate", where: "Venice & Pisa, Italy" },
      { id: "flushing-toilet", title: "S-Trap Flushing Toilet", period: "1596/1775", who: "Sir John Harington & Alexander Cumming", where: "London, England" },
      { id: "pressure-cooker", title: "Steam Pressure Cooker", period: "1679", who: "Denis Papin", where: "Paris & London" },
      { id: "franklin-stove", title: "Cast-Iron Franklin Stove", period: "1742", who: "Benjamin Franklin", where: "Philadelphia, USA" },
      { id: "canned-food", title: "Airtight Canned Food", period: "1810", who: "Nicolas Appert & Peter Durand", where: "France & UK" },
      { id: "safety-matches", title: "Friction Safety Match", period: "1826/1844", who: "John Walker & Gustaf Pasch", where: "UK & Sweden" },
      { id: "refrigerator", title: "Vapor-Compression Refrigerator", period: "1834/1913", who: "Jacob Perkins, Carl von Linde, Fred Wolf", where: "UK, Germany & USA" },
      { id: "sewing-machine", title: "Lockstitch Sewing Machine", period: "1846/1851", who: "Elias Howe & Isaac Singer", where: "USA" },
      { id: "safety-pin", title: "Wire Clasp Safety Pin", period: "1849", who: "Walter Hunt", where: "New York City, USA" },
      { id: "mason-jar", title: "Threaded Glass Mason Jar", period: "1858", who: "John Landis Mason", where: "New Jersey, USA" },
      { id: "electric-light-bulb", title: "Incandescent Light Bulb", period: "1879", who: "Thomas Edison & Joseph Swan", where: "USA & UK" },
      { id: "zipper", title: "Slide Fastener (Zipper)", period: "1893/1913", who: "Whitcomb Judson & Gideon Sundback", where: "USA" },
      { id: "safety-razor", title: "Disposable Blade Safety Razor", period: "1901", who: "King Camp Gillette", where: "Boston, USA" },
      { id: "vacuum-cleaner", title: "Electric Vacuum Cleaner", period: "1901/1908", who: "Hubert Booth & James Spangler", where: "UK & USA" },
      { id: "air-conditioner", title: "Mechanical Air Conditioner", period: "1902", who: "Willis Carrier", where: "Brooklyn, NY, USA" },
      { id: "washing-machine", title: "Electric Washing Machine", period: "1908", who: "Alva J. Fisher (Thor)", where: "Chicago, USA" },
      { id: "pop-up-toaster", title: "Automatic Pop-Up Toaster", period: "1919", who: "Charles Strite", where: "Minnesota, USA" },
      { id: "ballpoint-pen", title: "Rolling Ballpoint Pen", period: "1938", who: "László Bíró", where: "Budapest & Buenos Aires" },
      { id: "microwave-oven", title: "Cavity Magnetron Microwave Oven", period: "1945", who: "Percy Spencer (Raytheon)", where: "Massachusetts, USA" }
    ]
  },
  {
    name: "Media",
    label: "Media & Sound",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>`,
    items: [
      { id: "camera-obscura", title: "Pinhole Camera Obscura", period: "c. 5th c. BCE", who: "Mozi & Ibn al-Haytham (Alhazen)", where: "China & Cairo" },
      { id: "magic-lantern", title: "Magic Lantern Image Projector", period: "1659", who: "Christiaan Huygens", where: "The Hague, Netherlands" },
      { id: "lithography", title: "Chemical Lithography Printing", period: "1796", who: "Alois Senefelder", where: "Munich, Germany" },
      { id: "photography-camera", title: "Optical Daguerreotype Camera", period: "1826/1839", who: "Nicéphore Niépce & Louis Daguerre", where: "France" },
      { id: "roll-film", title: "Flexible Roll Film & Kodak Camera", period: "1888", who: "George Eastman", where: "Rochester, NY, USA" },
      { id: "phonograph-record", title: "Acoustic Phonograph Cylinder", period: "1877", who: "Thomas Edison", where: "Menlo Park, NJ, USA" },
      { id: "gramophone-disc", title: "Flat Disc Gramophone", period: "1887", who: "Emile Berliner", where: "Washington, USA" },
      { id: "cinema-projector", title: "Motion Picture Cinématographe", period: "1895", who: "Auguste & Louis Lumière", where: "Paris, France" },
      { id: "cathode-ray-tube", title: "Cathode Ray Tube (CRT)", period: "1897", who: "Ferdinand Braun", where: "Strasbourg, Germany" },
      { id: "microphone", title: "Acoustic Carbon Microphone", period: "1870s", who: "Emile Berliner, David Hughes, Edison", where: "USA & UK" },
      { id: "condenser-mic", title: "Condenser Studio Microphone", period: "1916", who: "Edward Christopher Wente", where: "New York City, USA" },
      { id: "loudspeaker", title: "Dynamic Moving-Coil Loudspeaker", period: "1925", who: "Chester Rice & Edward Kellogg", where: "Schenectady, NY, USA" },
      { id: "sound-on-film", title: "Sound-on-Film Optical Talkies", period: "1927", who: "Lee de Forest & Theodore Case", where: "USA" },
      { id: "leica-35mm", title: "35mm Compact Camera (Leica)", period: "1925", who: "Oskar Barnack", where: "Wetzlar, Germany" },
      { id: "television", title: "Electronic Television Scanning", period: "1927", who: "Philo Farnsworth & Vladimir Zworykin", where: "USA" },
      { id: "technicolor-cinema", title: "Three-Strip Technicolor Motion Picture", period: "1932", who: "Dr. Herbert Kalmus", where: "Hollywood, USA" },
      { id: "magnetic-tape-recorder", title: "Magnetic Tape Recorder", period: "1928/1935", who: "Fritz Pfleumer & AEG", where: "Germany" },
      { id: "polaroid-camera", title: "Instant Camera (Polaroid Land)", period: "1948", who: "Edwin H. Land", where: "Cambridge, MA, USA" },
      { id: "vinyl-lp", title: "Microgroove 33⅓ RPM Vinyl LP", period: "1948", who: "Peter Goldmark & Columbia", where: "New York, USA" },
      { id: "color-television", title: "Compatible Color Television (NTSC)", period: "1953", who: "RCA Engineering Team", where: "Camden, NJ, USA" },
      { id: "vr-headset", title: "Virtual Reality Headset", period: "1968/2016", who: "Ivan Sutherland & Palmer Luckey", where: "USA" }
    ]
  },
  {
    name: "Medicine",
    label: "Medicine & Health",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>`,
    items: [
      { id: "stethoscope", title: "Acoustic Medical Stethoscope", period: "1816", who: "René Laennec", where: "Paris, France" },
      { id: "surgical-anesthesia", title: "Inhaled Ether Surgical Anesthesia", period: "1846", who: "William T.G. Morton", where: "Boston, MA, USA" },
      { id: "hypodermic-syringe", title: "Medical Hypodermic Syringe", period: "1853", who: "Alexander Wood & Charles Pravaz", where: "Scotland & France" },
      { id: "antiseptic-surgery", title: "Antiseptic Carbolic Surgery", period: "1865", who: "Joseph Lister", where: "Glasgow, Scotland" },
      { id: "smallpox-vaccine", title: "Smallpox Inoculation Vaccine", period: "1796", who: "Edward Jenner", where: "Gloucestershire, England" },
      { id: "rabies-vaccine", title: "Attenuated Rabies Vaccine", period: "1885", who: "Louis Pasteur & Émile Roux", where: "Paris, France" },
      { id: "x-ray-imaging", title: "Diagnostic Medical X-Ray", period: "1895", who: "Wilhelm Conrad Röntgen", where: "Würzburg, Germany" },
      { id: "blood-typing-abo", title: "ABO Blood Group Classification", period: "1901", who: "Karl Landsteiner", where: "Vienna, Austria" },
      { id: "electrocardiogram", title: "Electrocardiogram (ECG)", period: "1903", who: "Willem Einthoven", where: "Leiden, Netherlands" },
      { id: "antibiotics-penicillin", title: "Antibiotics & Penicillin", period: "1928/1941", who: "Fleming, Florey & Chain", where: "UK & USA" },
      { id: "electron-microscope", title: "Transmission Electron Microscope", period: "1931", who: "Ernst Ruska & Max Knoll", where: "Berlin, Germany" },
      { id: "dialysis-machine", title: "Artificial Kidney Dialysis", period: "1943", who: "Willem Johan Kolff", where: "Kampen, Netherlands" },
      { id: "polio-vaccine", title: "Inactivated Polio Vaccine", period: "1953", who: "Jonas Salk", where: "Pittsburgh, USA" },
      { id: "dna-double-helix", title: "DNA Double Helix Structural Model", period: "1953", who: "Watson, Crick, Franklin & Wilkins", where: "Cambridge & London" },
      { id: "cardiac-pacemaker", title: "Implantable Cardiac Pacemaker", period: "1958/1960", who: "Rune Elmqvist & Wilson Greatbatch", where: "Sweden & USA" },
      { id: "defibrillator-aed", title: "Portable External Defibrillator (AED)", period: "1965", who: "Frank Pantridge", where: "Belfast, UK" },
      { id: "ct-scanner", title: "Computed Tomography (CT Scanner)", period: "1971", who: "Godfrey Hounsfield & Allan Cormack", where: "Middlesex, UK" },
      { id: "mri-scanner", title: "Magnetic Resonance Imaging (MRI)", period: "1973/1977", who: "Lauterbur, Mansfield, Damadian", where: "USA & UK" },
      { id: "dna-sequencer", title: "Automated DNA Sequencer", period: "1977/1986", who: "Frederick Sanger & Leroy Hood", where: "UK & USA" },
      { id: "robotic-surgery", title: "Robotic Surgical System (da Vinci)", period: "2000", who: "Intuitive Surgical", where: "Sunnyvale, CA, USA" },
      { id: "crispr-gene-editing", title: "CRISPR-Cas9 Programmable Gene Editing", period: "2012", who: "Jennifer Doudna & Emmanuelle Charpentier", where: "UC Berkeley & Sweden" }
    ]
  },
  {
    name: "Energy",
    label: "Energy & Power",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>`,
    items: [
      { id: "water-wheel", title: "Undershot & Overshot Water Wheel", period: "c. 1st c. BCE", who: "Vitruvius & Hellenistic engineers", where: "Rome & Greece" },
      { id: "windmill", title: "Vertical Post & Grist Windmill", period: "c. 644 CE", who: "Persian engineers (Sistan)", where: "Persia (Iran)" },
      { id: "newcomen-steam-engine", title: "Atmospheric Beam Steam Engine", period: "1712", who: "Thomas Newcomen", where: "Dudley, England" },
      { id: "watt-steam-engine", title: "Separate Condenser Steam Engine", period: "1769/1776", who: "James Watt & Matthew Boulton", where: "Glasgow & Birmingham" },
      { id: "voltaic-pile", title: "Chemical Voltaic Battery", period: "1800", who: "Alessandro Volta", where: "Pavia, Italy" },
      { id: "electromagnetic-dynamo", title: "Faraday Electromagnetic Generator", period: "1831", who: "Michael Faraday", where: "London, England" },
      { id: "lead-acid-battery", title: "Rechargeable Lead-Acid Secondary Cell", period: "1859", who: "Gaston Planté", where: "Paris, France" },
      { id: "ac-polyphase-grid", title: "Alternating Current (AC) Polyphase Grid", period: "1887/1893", who: "Nikola Tesla & George Westinghouse", where: "Pittsburgh & Niagara" },
      { id: "steam-turbine", title: "Parsons Reaction Steam Turbine", period: "1884", who: "Sir Charles Parsons", where: "Newcastle, UK" },
      { id: "hydroelectric-plant", title: "Central Hydroelectric Power Station", period: "1882/1895", who: "Nikola Tesla & Edward Adams", where: "Niagara Falls, USA" },
      { id: "photovoltaic-cell", title: "Silicon Photovoltaic Solar Cell", period: "1954", who: "Bell Labs (Pearson, Chapin, Fuller)", where: "New Jersey, USA" },
      { id: "nuclear-fission-reactor", title: "Nuclear Fission Energy Reactor", period: "1942/1954", who: "Enrico Fermi & Igor Kurchatov", where: "Chicago & Obninsk" },
      { id: "modern-wind-turbine", title: "Grid-Connected Aerodynamic Wind Turbine", period: "1957/1978", who: "Johannes Juul & Henrik Stiesdal", where: "Denmark" },
      { id: "lithium-ion-battery", title: "Rechargeable Lithium-Ion Battery", period: "1980/1991", who: "Goodenough, Whittingham, Yoshino", where: "Oxford & Tokyo" },
      { id: "hydrogen-fuel-cell", title: "Proton-Exchange Membrane (PEM) Fuel Cell", period: "1839/1959", who: "William Grove & Francis Bacon", where: "Wales & Cambridge" },
      { id: "supercapacitor", title: "Double-Layer Electrochemical Supercapacitor", period: "1957/1978", who: "General Electric & NEC", where: "USA & Japan" },
      { id: "hvdc-transmission", title: "High-Voltage Direct Current (HVDC)", period: "1954", who: "Uno Lamm & ASEA", where: "Gotland, Sweden" },
      { id: "solid-state-battery", title: "Solid-State Electrolyte Battery", period: "2010s", who: "QuantumScape & Toyota", where: "USA & Japan" },
      { id: "tokamak-fusion", title: "Magnetic Confinement Fusion (Tokamak)", period: "1958/1968", who: "Tamm, Sakharov, Artsimovich", where: "Moscow & ITER" },
      { id: "smart-microgrid", title: "Bidirectional Smart Microgrid", period: "2000s", who: "NREL & IEEE", where: "Golden, Colorado, USA" }
    ]
  },
  {
    name: "Agriculture",
    label: "Agriculture & Food",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`,
    items: [
      { id: "heavy-moldboard-plow", title: "Heavy Cast-Iron Moldboard Plow", period: "c. 1st c. BCE / 1837", who: "Han Dynasty smiths & John Deere", where: "China & Illinois, USA" },
      { id: "crop-rotation-system", title: "Four-Field Scientific Crop Rotation", period: "1730s", who: "Charles Townshend", where: "Norfolk, England" },
      { id: "mechanical-seed-drill", title: "Rotary Mechanical Seed Drill", period: "1701", who: "Jethro Tull", where: "Berkshire, England" },
      { id: "cotton-gin", title: "Mechanical Saw Cotton Gin", period: "1793", who: "Eli Whitney & Catherine Greene", where: "Savannah, Georgia, USA" },
      { id: "mechanical-reaper", title: "Mechanical Grain Reaper", period: "1831", who: "Cyrus McCormick", where: "Virginia, USA" },
      { id: "haber-bosch-fertilizer", title: "Haber-Bosch Nitrogen Synthesis", period: "1909", who: "Fritz Haber & Carl Bosch", where: "Karlsruhe, Germany" },
      { id: "gasoline-farm-tractor", title: "Gasoline Farm Tractor & 3-Point Hitch", period: "1892/1926", who: "John Froelich & Harry Ferguson", where: "Iowa & Northern Ireland" },
      { id: "pasteurization-process", title: "Thermal Food Pasteurization", period: "1864", who: "Louis Pasteur", where: "Paris, France" },
      { id: "combine-harvester", title: "Self-Propelled Combine Harvester", period: "1836/1938", who: "Hiram Moore & Massey-Harris", where: "Michigan & Canada" },
      { id: "drip-irrigation", title: "Low-Pressure Plastic Drip Irrigation", period: "1959", who: "Simcha Blass (Netafim)", where: "Hatzerim, Israel" },
      { id: "hydroponic-farming", title: "Controlled-Environment Hydroponics", period: "1937/1970s", who: "William Gericke & Allen Cooper", where: "UC Berkeley, USA" },
      { id: "freeze-drying", title: "Vacuum Freeze-Drying Preservation", period: "1906/1940s", who: "Arsène d'Arsonval", where: "Paris, France" },
      { id: "hybrid-maize", title: "High-Yield Hybrid Maize Crops", period: "1926/1960s", who: "Henry Wallace & Norman Borlaug", where: "Iowa & Mexico" },
      { id: "center-pivot-irrigation", title: "Center-Pivot Circular Sprinkler", period: "1948", who: "Frank Zybach", where: "Nebraska, USA" },
      { id: "grain-elevator", title: "Steam Bucket Grain Elevator", period: "1842", who: "Joseph Dart & Robert Dunbar", where: "Buffalo, NY, USA" },
      { id: "gps-tractor-autosteer", title: "Precision RTK-GPS Tractor Autosteer", period: "1999", who: "Michael O'Connor & John Deere", where: "Stanford, California, USA" },
      { id: "biofortified-crops", title: "Biofortified Golden Rice", period: "1999", who: "Ingo Potrykus & Peter Beyer", where: "Zurich & Freiburg" },
      { id: "precision-crop-drone", title: "Multispectral Crop Survey Drone", period: "2013", who: "DJI Agriculture", where: "Global" },
      { id: "cellular-meat-bioreactor", title: "Cultivated Meat Bioreactor", period: "2013", who: "Dr. Mark Post (Mosa Meat)", where: "Maastricht, Netherlands" },
      { id: "vertical-aeroponics", title: "Closed-Loop High-Pressure Aeroponics", period: "1983", who: "Richard Stoner & NASA", where: "Boulder, Colorado, USA" }
    ]
  },
  {
    name: "Materials",
    label: "Materials & Industry",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>`,
    items: [
      { id: "bronze-metallurgy", title: "Bronze Smelting & Lost-Wax Casting", period: "c. 3300 BCE", who: "Near Eastern & Indus metallurgists", where: "Mesopotamia & Anatolia" },
      { id: "iron-blast-furnace", title: "Cast-Iron Blast Furnace Smelting", period: "c. 1200 BCE / 5th c. BCE", who: "Hittite & Han Dynasty ironmasters", where: "Anatolia & China" },
      { id: "bessemer-steel", title: "Bessemer Pneumatic Steel Converter", period: "1856", who: "Sir Henry Bessemer", where: "Sheffield, England" },
      { id: "hall-heroult-aluminum", title: "Hall-Héroult Aluminum Electrolysis", period: "1886", who: "Charles Hall & Paul Héroult", where: "Ohio, USA & France" },
      { id: "vulcanized-rubber", title: "Sulfur-Vulcanized Elastic Rubber", period: "1839/1844", who: "Charles Goodyear & Thomas Hancock", where: "Massachusetts & London" },
      { id: "bakelite-plastic", title: "Synthetic Thermosetting Plastic (Bakelite)", period: "1907", who: "Leo Baekeland", where: "Yonkers, NY, USA" },
      { id: "reinforced-concrete", title: "Steel-Reinforced Concrete", period: "1867/1892", who: "Joseph Monier & François Hennebique", where: "Paris, France" },
      { id: "arc-welding", title: "Electric Arc & Oxy-Acetylene Welding", period: "1881/1903", who: "Nikolai Benardos & Edmond Fouché", where: "Saint Petersburg & France" },
      { id: "stainless-steel", title: "Rustless Chromium-Alloy Stainless Steel", period: "1913", who: "Harry Brearley", where: "Sheffield, England" },
      { id: "nylon-synthetic-fiber", title: "Synthetic Polyamide Polymer (Nylon)", period: "1935", who: "Wallace Carothers (DuPont)", where: "Wilmington, Delaware, USA" },
      { id: "carbon-fiber", title: "High-Tensile Carbon Fiber Composite", period: "1958/1963", who: "Roger Bacon & William Watt", where: "USA & UK" },
      { id: "float-glass", title: "Molten Tin Float Glass", period: "1952", who: "Sir Alastair Pilkington", where: "Lancashire, England" },
      { id: "silicone-polymers", title: "Organosilicon Elastomers & Resins", period: "1940s", who: "Eugene Rochow & James Hyde", where: "New York, USA" },
      { id: "kevlar-aramid", title: "Bulletproof Aramid Fiber (Kevlar)", period: "1965", who: "Stephanie Kwolek (DuPont)", where: "Wilmington, Delaware, USA" },
      { id: "stereolithography-3d", title: "Stereolithography 3D Printing (SLA)", period: "1984/1986", who: "Chuck Hull (3D Systems)", where: "California, USA" },
      { id: "cnc-machine", title: "Computer Numerical Control (CNC)", period: "1952", who: "John Parsons & MIT Lab", where: "Michigan & MIT, USA" },
      { id: "industrial-robot-arm", title: "Articulated Industrial Robot (Unimate)", period: "1954/1961", who: "George Devol & Joseph Engelberger", where: "New Jersey, USA" },
      { id: "aerogel-insulation", title: "Silica Nanoporous Aerogel", period: "1931", who: "Samuel Stephens Kistler", where: "California, USA" },
      { id: "graphene-monolayer", title: "Atomic Carbon Graphene Monolayer", period: "2004", who: "Andre Geim & Konstantin Novoselov", where: "Manchester, UK" },
      { id: "czochralski-silicon", title: "Czochralski Monocrystalline Silicon", period: "1916/1950", who: "Jan Czochralski & Gordon Teal", where: "Poland & Bell Labs" }
    ]
  },
  {
    name: "AncientWisdom",
    label: "Ancient Wisdom & Siddhars",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>`,
    items: [
      { id: "siddha-alchemy-rasavada", title: "Siddha Alchemy (Rasavada & Kayakalpa)", period: "c. 3000 BCE", who: "Agathiyar, Bogar & 18 Tamil Siddhars", where: "Tamilakam / Western Ghats, India" },
      { id: "ayurvedic-tridosha", title: "Ayurvedic Tridosha & Botanical Medicine", period: "c. 1500 BCE", who: "Charaka, Sushruta & Dhanvantari", where: "Varanasi & Ancient India" },
      { id: "sushruta-rhinoplasty", title: "Sushruta Ancient Surgical Plastic Surgery", period: "c. 600 BCE", who: "Acharya Sushruta (Father of Surgery)", where: "Kashi (Varanasi), India" },
      { id: "kundalini-pranayama", title: "Yogic Pranayama & Bio-Energy Nervous System", period: "c. 2000 BCE", who: "Patanjali & Vedic Rishis", where: "Himalayas & Indus Valley" },
      { id: "panchaloha-bronze", title: "Panchaloha Sacred 5-Metal Bronze Alchemy", period: "c. 9th c.", who: "Chola Dynasty master sthapatis", where: "Thanjavur & Swamimalai, Tamil Nadu" },
      { id: "palm-leaf-manuscripts", title: "Palm-Leaf Preservation & Olai Chuvadi", period: "c. 500 BCE", who: "Ancient Tamil & Sanskrit scribes", where: "South India & Sri Lanka" },
      { id: "wootz-crucible-steel", title: "Wootz Crucible Damascus Steel", period: "c. 300 BCE", who: "Chera & Tamilakam ironmasters", where: "Kodumanal & Telangana, South India" },
      { id: "kalarippayattu-marma", title: "Kalarippayattu 108 Marma Vital Point Science", period: "c. 1000 BCE", who: "Sage Parashurama & Agastya", where: "Kerala & Tamil Nadu, India" },
      { id: "sacred-gopuram-geometry", title: "Acoustic Vedic Temple Gopuram Architecture", period: "c. 6th–11th c.", who: "Rajaraja Chola & Dravidian Vishwakarmas", where: "Thanjavur & Madurai, India" },
      { id: "kallanai-grand-anicut", title: "Kallanai Grand Anicut Stone Water Dam", period: "c. 100 CE", who: "King Karikala Chola", where: "Cauvery River, Tamil Nadu, India" },
      { id: "stepwell-step-hydraulics", title: "Inverted Subterranean Stepwell Hydraulics (Baoli)", period: "c. 600 CE", who: "Solanki & Gurjara-Pratihara engineers", where: "Gujarat & Rajasthan, India" },
      { id: "surya-siddhanta-astronomy", title: "Surya Siddhanta Heliocentric Planetary Math", period: "c. 500 CE", who: "Aryabhata, Varahamihira & Bhaskara", where: "Kusumapura (Patna) & Ujjain" },
      { id: "panchakarma-detox", title: "Panchakarma Biological Cellular Detox", period: "c. 1000 BCE", who: "Vagbhata & Atreya", where: "Ancient India" },
      { id: "jantar-mantar-sundials", title: "Giant Stone Astronomical Yantras (Jantar Mantar)", period: "1724", who: "Maharaja Sawai Jai Singh II", where: "Jaipur & Delhi, India" },
      { id: "yoga-sutras-mind-control", title: "Patanjali's 8-Limbed Ashtanga Neuro-Psychology", period: "c. 400 BCE", who: "Sage Patanjali", where: "Ancient India" },
      { id: "herbal-kayakalpa-rejuvenation", title: "Siddha Kayakalpa Biological Longevity Elixirs", period: "c. 500 BCE", who: "Siddhar Bogar (Creator of Palani idol)", where: "Palani Hills & China" },
      { id: "vastu-shastra-grid", title: "Vastu Purusha Mandala Geometric Resonances", period: "c. 1500 BCE", who: "Mayan & Vishwakarma architects", where: "Ancient India" },
      { id: "musical-stone-pillars", title: "Resonant Granite Musical Acoustic Pillars", period: "c. 16th c.", who: "Vijayanagara Nayak artisans", where: "Hampi & Madurai Meenakshi, India" },
      { id: "chola-lost-wax-nataraja", title: "Cosmic Dance Nataraja Bronze Proportion Math", period: "c. 10th c.", who: "Chola bronze casters", where: "Chidambaram, Tamil Nadu" },
      { id: "ancient-natural-dye-indigo", title: "Fermented Organic Indigo & Madder Dyeing", period: "c. 2000 BCE", who: "Indus Valley & Tamil weavers", where: "Indus Valley & Coromandel" }
    ]
  },
  {
    name: "Space",
    label: "Space & Astronomy",
    realm: "human",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path></svg>`,
    items: [
      { id: "astronomical-telescope", title: "Refracting & Reflecting Space Telescope", period: "1608/1668", who: "Galileo Galilei & Sir Isaac Newton", where: "Italy & England" },
      { id: "liquid-rocket", title: "Liquid-Fueled Rocket Engine", period: "1926", who: "Robert H. Goddard", where: "Auburn, Massachusetts, USA" },
      { id: "v2-rocket", title: "Suborbital Guided Rocket (V-2)", period: "1944", who: "Wernher von Braun", where: "Peenemünde, Germany" },
      { id: "sputnik-satellite", title: "Orbital Artificial Satellite (Sputnik 1)", period: "1957", who: "Sergei Korolev & OKB-1", where: "Baikonur Cosmodrome, USSR" },
      { id: "vostok-spacecraft", title: "Crewed Orbital Spacecraft (Vostok 1)", period: "1961", who: "Sergei Korolev & Yuri Gagarin", where: "Baikonur, USSR" },
      { id: "saturn-v-rocket", title: "Saturn V Lunar Launch Booster", period: "1967", who: "Wernher von Braun & NASA", where: "Huntsville, Alabama, USA" },
      { id: "lunar-module", title: "Apollo Lunar Module (Eagle)", period: "1969", who: "Thomas J. Kelly & Grumman", where: "New York, USA" },
      { id: "space-suit-emu", title: "Extravehicular Spacesuit (EMU)", period: "1965/1981", who: "ILC Dover & NASA", where: "Delaware, USA" },
      { id: "lunar-rover", title: "Lunar Roving Vehicle (Moon Buggy)", period: "1971", who: "Ferenc Pavlics, Boeing & NASA", where: "USA & The Moon" },
      { id: "space-shuttle", title: "Reusable Space Shuttle Orbiter", period: "1981", who: "NASA & Rockwell", where: "Florida, USA" },
      { id: "hubble-telescope", title: "Hubble Space Optical Observatory", period: "1990", who: "Lyman Spitzer, Nancy Roman & NASA", where: "Low Earth Orbit" },
      { id: "space-station-iss", title: "International Space Station (ISS)", period: "1998", who: "NASA, Roscosmos, ESA, JAXA", where: "Low Earth Orbit (400 km)" },
      { id: "voyager-probes", title: "Voyager 1 & 2 Interstellar Probes", period: "1977", who: "NASA JPL", where: "Pasadena, CA, USA" },
      { id: "mars-curiosity-rover", title: "Mars Nuclear Science Rover (Curiosity)", period: "2012", who: "NASA JPL & Caltech", where: "Gale Crater, Mars" },
      { id: "jwst-space-telescope", title: "James Webb Space Telescope (JWST)", period: "2021", who: "NASA, ESA & CSA", where: "L2 Lagrange Point" },
      { id: "reusable-booster", title: "Reusable Falcon 9 Landing Booster", period: "2015", who: "SpaceX Team", where: "Cape Canaveral, USA" },
      { id: "starlink-constellation", title: "Laser Mesh Satellite Constellation", period: "2019", who: "SpaceX Satellite Team", where: "Washington, USA" },
      { id: "spacex-starship", title: "Stainless Steel Starship Rocket", period: "2023", who: "SpaceX Starbase", where: "Boca Chica, Texas, USA" },
      { id: "mars-ingenuity-helicopter", title: "Ingenuity Autonomous Mars Helicopter", period: "2021", who: "MiMi Aung, Bob Balaram & NASA JPL", where: "Mars" },
      { id: "asteroid-sample-return", title: "Asteroid Sample Return Capsule (OSIRIS-REx)", period: "2020/2023", who: "Dante Lauretta & NASA", where: "Asteroid Bennu & Utah" }
    ]
  }
];

// ============================================================================
// PAGE 2: ANIMAL, BIRDS, DINOSAURS & PREHISTORIC CREATURES (10 DOMAINS, 200+ TOPICS)
// ============================================================================

const faunaDomains = [
  {
    name: "Dinosaurs",
    label: "Dinosaurs & Archosaurs",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5"></path></svg>`,
    items: [
      { id: "tyrannosaurus-rex", title: "Tyrannosaurus Rex Apex Biomechanics", period: "68–66 Mya", who: "Late Cretaceous Theropod Lineage", where: "Laramidia (North America)" },
      { id: "spinosaurus-aegyptiacus", title: "Spinosaurus Semi-Aquatic Paddle Tail", period: "99–93.5 Mya", who: "Spinosaurid Megatheropod", where: "Kem Kem Beds, North Africa" },
      { id: "velociraptor-mongoliensis", title: "Velociraptor Sickle-Claw Pack Hunter", period: "75–71 Mya", who: "Dromaeosaurid Theropod", where: "Gobi Desert, Mongolia" },
      { id: "triceratops-horridus", title: "Triceratops Triple-Horned Armor Shield", period: "68–66 Mya", who: "Ceratopsid Herbivorous Dinosaur", where: "Hell Creek, North America" },
      { id: "brachiosaurus-altithorax", title: "Brachiosaurus 50-Foot High-Canopy Giraffatitan", period: "154–153 Mya", who: "Sauropod Long-Necked Dinosaur", where: "Morrison Formation, USA" },
      { id: "ankylosaurus-magniventris", title: "Ankylosaurus Living Tank & Tail Club", period: "68–66 Mya", who: "Thyreophoran Armored Dinosaur", where: "North America" },
      { id: "stegosaurus-stenops", title: "Stegosaurus Alternating Thermal Back Plates", period: "155–150 Mya", who: "Stegosaurid Herbivore", where: "Morrison Formation, USA" },
      { id: "allosaurus-fragilis", title: "Allosaurus Hatchet-Jaw Ambush Predator", period: "155–145 Mya", who: "Jurassic Carnosaur", where: "Utah & Colorado, USA" },
      { id: "pachycephalosaurus-wyomingensis", title: "Pachycephalosaurus 9-Inch Solid Bone Dome", period: "70–66 Mya", who: "Pachycephalosaurid Head-Butter", where: "Wyoming & Montana, USA" },
      { id: "carnotaurus-sastrei", title: "Carnotaurus Bull-Horned Supersonic Sprinter", period: "72–69 Mya", who: "Abelisaurid Theropod", where: "Patagonia, Argentina" },
      { id: "giganotosaurus-carolinii", title: "Giganotosaurus Patagonia Colossus Predator", period: "98–97 Mya", who: "Carcharodontosaurid Carnivore", where: "Neuquén, Argentina" },
      { id: "microraptor-gui", title: "Microraptor Four-Winged Gliding Theropod", period: "120 Mya", who: "Dromaeosaurid Glider", where: "Liaoning, China" },
      { id: "quetzalcoatlus-northropi", title: "Quetzalcoatlus 36-Foot Giraffe-Sized Pterosaur", period: "68–66 Mya", who: "Azhdarchid Pterosaur", where: "Texas, USA" },
      { id: "pteranodon-longiceps", title: "Pteranodon Toothless Oceanic Glider", period: "86–84.5 Mya", who: "Pteranodontid Ocean Flier", where: "Western Interior Seaway, USA" },
      { id: "mosasaurus-hoffmannii", title: "Mosasaurus 50-Foot Marine Apex Serpent", period: "82–66 Mya", who: "Aquatic Squamate Reptile", where: "Global Cretaceous Oceans" },
      { id: "plesiosaurus-dolichodeirus", title: "Plesiosaurus 4-Flipper Underwater Flight", period: "199–175 Mya", who: "Sauropterygian Marine Reptile", where: "Lyme Regis, England" },
      { id: "dimetrodon-grandis", title: "Dimetrodon Solar Thermoregulatory Sail", period: "295–272 Mya", who: "Sphenacodontid Synapsid", where: "Texas & Oklahoma, USA" },
      { id: "iguanodon-bernissartensis", title: "Iguanodon Spiked-Thumb Plant Grazer", period: "126–125 Mya", who: "Ornithopod Dinosaur", where: "Bernissart, Belgium & UK" },
      { id: "parasaurolophus-walkeri", title: "Parasaurolophus Resonance Sound-Horn Crest", period: "76.5–73 Mya", who: "Hadrosaurid Duck-Billed Dinosaur", where: "Alberta, Canada & Utah" },
      { id: "deinocheirus-mirificus", title: "Deinocheirus 8-Foot Giant Scythe Claws", period: "70 Mya", who: "Ornithomimosaurian Omnivore", where: "Nemegt Basin, Mongolia" }
    ]
  },
  {
    name: "AvianEvolution",
    label: "Birds & Avian Flight",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>`,
    items: [
      { id: "archaeopteryx-lithographica", title: "Archaeopteryx The Feathered Transition", period: "150 Mya", who: "Avialan Transitional Fossil", where: "Solnhofen Limestone, Germany" },
      { id: "peregrine-falcon-dive", title: "Peregrine Falcon 390 km/h Supersonic Stoop", period: "Extant", who: "Falco peregrinus", where: "Global Cliffs & Skylines" },
      { id: "harpy-eagle-talons", title: "Harpy Eagle 500 PSI Sloth-Crushing Talons", period: "Extant", who: "Harpia harpyja", where: "Amazon Rainforest Canopy" },
      { id: "hummingbird-hover", title: "Hummingbird 80-BPS Figure-Eight Flight", period: "Extant", who: "Trochilidae Family", where: "The Americas" },
      { id: "barn-owl-silent-flight", title: "Barn Owl Serrated Noise-Canceling Feathers", period: "Extant", who: "Tyto alba", where: "Global Grasslands" },
      { id: "emperor-penguin-insulation", title: "Emperor Penguin Sub-Zero Density Feather Shield", period: "Extant", who: "Aptenodytes forsteri", where: "Antarctica Ice Shelf" },
      { id: "wandering-albatross-glide", title: "Wandering Albatross 11-Foot Dynamic Soaring", period: "Extant", who: "Diomedea exulans", where: "Southern Ocean" },
      { id: "ostrich-running-mechanics", title: "Ostrich 70 km/h Elastic Tendon Running", period: "Extant", who: "Struthio camelus", where: "African Savanna" },
      { id: "corvid-crow-intelligence", title: "New Caledonian Crow Causal Tool Shaping", period: "Extant", who: "Corvus moneduloides", where: "New Caledonia & Global" },
      { id: "peafowl-sexual-selection", title: "Peafowl Iridescent Ocelli Tail Physics", period: "Extant", who: "Pavo cristatus", where: "South Asia & Worldwide" },
      { id: "african-grey-parrot-vocal", title: "African Grey Acoustic Syntactic Speech", period: "Extant", who: "Psittacus erithacus", where: "Equatorial Africa" },
      { id: "greater-flamingo-filter", title: "Flamingo Inverted Carotenoid Filter Beak", period: "Extant", who: "Phoenicopterus roseus", where: "Alkaline Lakes Worldwide" },
      { id: "toco-toucan-thermo-beak", title: "Toco Toucan Radiative Heat-Dump Beak", period: "Extant", who: "Ramphastos toco", where: "South American Canopy" },
      { id: "common-swift-nonstop", title: "Common Swift 10-Month Non-Stop Aerial Life", period: "Extant", who: "Apus apus", where: "Eurasia & Africa" },
      { id: "griffon-vulture-immunity", title: "Vulture Corrosive Stomach Acid & Pathogen Defense", period: "Extant", who: "Gyps fulvus", where: "Eurasia & Africa" },
      { id: "sociable-weaver-nest", title: "Sociable Weaver 100-Chamber Mega-Nests", period: "Extant", who: "Philetairus socius", where: "Kalahari Desert" },
      { id: "kiwi-vestigial-whisker", title: "Kiwi Nostril-Tipped Ground Probing Beak", period: "Extant", who: "Apteryx haastii", where: "New Zealand Forests" },
      { id: "woodpecker-skull-shock", title: "Woodpecker Hyoid Bone Brain Shock Absorption", period: "Extant", who: "Dryocopus martius", where: "Global Forests" },
      { id: "argentine-giant-bird", title: "Argentavis 23-Foot Giant Condor Glider", period: "6 Mya", who: "Teratornithidae Megabird", where: "Pampas, Argentina" },
      { id: "passenger-pigeon-flocks", title: "Passenger Pigeon 3-Billion Bird Mega-Flocks", period: "Extinct 1914", who: "Ectopistes migratorius", where: "North America" }
    ]
  },
  {
    name: "PrehistoricMegafauna",
    label: "Megafauna & Ice Age",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"></path></svg>`,
    items: [
      { id: "woolly-mammoth", title: "Woolly Mammoth 15-Foot Curved Ivory Tusks", period: "300,000–4,000 ya", who: "Mammuthus primigenius", where: "Siberian Mammoth Steppe" },
      { id: "smilodon-fatalis", title: "Smilodon 11-Inch Canine Saber Teeth", period: "2.5 Mya–10,000 ya", who: "Machairodontinae Saber-Cat", where: "La Brea Tar Pits, Americas" },
      { id: "megatherium-sloth", title: "Megatherium 20-Foot 4-Ton Ground Sloth", period: "2 Mya–10,000 ya", who: "Megatheriidae Giant Sloth", where: "Pampas & South America" },
      { id: "paraceratherium-rhino", title: "Paraceratherium 20-Ton Hornless Tree Rhino", period: "34–23 Mya", who: "Indricotheriinae Giant Mammal", where: "Eurasian Steppes & Pakistan" },
      { id: "megaloceros-giant-elk", title: "Megaloceros 12-Foot Giant Antler Elk", period: "2.6 Mya–7,700 ya", who: "Irish Elk Cervid", where: "Eurasia & Ireland" },
      { id: "glyptodon-armor", title: "Glyptodon 2-Ton Hexagonal Bone Dome Carapace", period: "2 Mya–10,000 ya", who: "Chlamyphoridae Armored Mammal", where: "South America" },
      { id: "dire-wolf", title: "Dire Wolf Heavy-Bone Crushing Jaws", period: "250,000–10,000 ya", who: "Aenocyon dirus", where: "Americas" },
      { id: "cave-bear", title: "Ursus Spelaeus Alpine Cave Hibernation Giant", period: "250,000–24,000 ya", who: "Ursus spelaeus", where: "European Limestone Caves" },
      { id: "diprotodon-optatum", title: "Diprotodon 3-Ton Giant Marsupial Wombat", period: "1.6 Mya–40,000 ya", who: "Vombatiformes Marsupial", where: "Australia" },
      { id: "elasmotherium-unicorn", title: "Elasmotherium 6-Foot Keratin Forehead Horn", period: "2.6 Mya–39,000 ya", who: "Siberian Giant Rhino", where: "Pontic-Caspian Steppe" },
      { id: "woolly-rhinoceros", title: "Coelodonta Two-Horned Tundra Rhinoceros", period: "3.6 Mya–10,000 ya", who: "Coelodonta antiquitatis", where: "Eurasia & Siberia" },
      { id: "giant-moa-dinornis", title: "Dinornis 12-Foot Giant Flightless Moa", period: "Extinct c. 1445", who: "Dinornis robustus", where: "South Island, New Zealand" },
      { id: "dodo-bird", title: "Dodo Mauritius Endemic Flightless Pioneer", period: "Extinct 1662", who: "Raphus cucullatus", where: "Mauritius, Indian Ocean" },
      { id: "thylacine-tasmanian-tiger", title: "Thylacine 120-Degree Gaping Pouch Predator", period: "Extinct 1936", who: "Thylacinus cynocephalus", where: "Tasmania, Australia" },
      { id: "haasts-eagle", title: "Haast's Eagle Moa-Hunting Apex Raptor", period: "Extinct c. 1400", who: "Hieraaetus moorei", where: "New Zealand Mountains" },
      { id: "titanoboa-cerrejonensis", title: "Titanoboa 42-Foot 1-Ton Rainforest Snake", period: "60–58 Mya", who: "Boidae Giant Constrictor", where: "Cerrejón Coal Mines, Colombia" },
      { id: "andrewsarchus-mongoliensis", title: "Andrewsarchus 3-Foot Crushing Carnivore Skull", period: "45–36 Mya", who: "Cetancodontamorpha Mammal", where: "Inner Mongolia, China" },
      { id: "entelodont-hell-pig", title: "Archaeotherium Bone-Crushing Hell Pig", period: "37–28 Mya", who: "Entelodontidae Ungulate", where: "North America & Eurasia" },
      { id: "chalicotherium-knuckle", title: "Chalicotherium Knuckle-Walking Clawed Grazer", period: "16–7.75 Mya", who: "Chalicotheriidae Perissodactyl", where: "Eurasia & Africa" },
      { id: "sivatherium-giant-giraffe", title: "Sivatherium Giant Armored Horned Giraffid", period: "5 Mya–10,000 ya", who: "Sivatherium giganteum", where: "Siwalik Hills, India & Africa" }
    ]
  },
  {
    name: "OceanLeviathans",
    label: "Marine & Ocean Life",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>`,
    items: [
      { id: "otodus-megalodon", title: "Otodus Megalodon 60-Foot 40,000 PSI Bite", period: "23–3.6 Mya", who: "Otodontidae Apex Shark", where: "Global Oceans" },
      { id: "blue-whale-gigantism", title: "Blue Whale 200-Ton Heart of a Car Colossus", period: "Extant", who: "Balaenoptera musculus", where: "Global Pelagic Oceans" },
      { id: "basilosaurus-whale", title: "Basilosaurus 60-Foot Serpentine Ancient Whale", period: "41–34 Mya", who: "Archaeoceti Cetacean", where: "Tethys Sea / Wadi Al-Hitan, Egypt" },
      { id: "giant-squid-deep-sea", title: "Giant Squid 10-Inch Dinner-Plate Eyes & Beak", period: "Extant", who: "Architeuthis dux", where: "Mesopelagic Abyss (1,000m deep)" },
      { id: "orca-killer-whale", title: "Orca Matriarch Pod Dialects & Wave Hunting", period: "Extant", who: "Orcinus orca", where: "Global Coastal & Polar Seas" },
      { id: "great-white-shark-ampullae", title: "Great White Ampullae of Lorenzini Microvolts", period: "Extant", who: "Carcharodon carcharias", where: "Temperate Coastal Waters" },
      { id: "coelacanth-living-fossil", title: "Coelacanth 400-Million-Year Lobe-Finned Fossil", period: "Extant", who: "Latimeria chalumnae", where: "Comoro Islands & Indonesia" },
      { id: "giant-manta-ray-wing", title: "Giant Manta 29-Foot Hydrofoil Wing Glide", period: "Extant", who: "Mobula birostris", where: "Tropical Coral Corridors" },
      { id: "chambered-nautilus-jet", title: "Chambered Nautilus Hydrostatic Buoyancy Tank", period: "Extant", who: "Nautilus pompilius", where: "Indo-Pacific Deep Reefs" },
      { id: "deep-sea-anglerfish", title: "Anglerfish Symbiotic Bioluminescent Photophore", period: "Extant", who: "Melanocetus johnsonii", where: "Bathypelagic Midnight Zone" },
      { id: "box-jellyfish-venom", title: "Chironex Fleckeri 3-Minute Cardiac Arrest Venom", period: "Extant", who: "Chironex fleckeri", where: "Indo-Pacific & Northern Australia" },
      { id: "sperm-whale-echolocation", title: "Sperm Whale 236 dB Sonic Sperm-Oil Organ", period: "Extant", who: "Physeter macrocephalus", where: "Global Deep Trenches" },
      { id: "electric-eel-high-voltage", title: "Electric Eel 860-Volt Triple-Organ Discharge", period: "Extant", who: "Electrophorus voltai", where: "Amazon Basin, South America" },
      { id: "sea-turtle-geomagnetism", title: "Loggerhead Turtle Trans-Pacific Magnetic Map", period: "Extant", who: "Caretta caretta", where: "Global Tropical Oceans" },
      { id: "cuttlefish-chromatophores", title: "Cuttlefish 200 ms Dynamic 4K Skin Camouflage", period: "Extant", who: "Sepia officinalis", where: "Reef Ecosystems" },
      { id: "peacock-mantis-shrimp", title: "Mantis Shrimp Bullet-Speed Cavitation Punch", period: "Extant", who: "Odontodactylus scyllarus", where: "Indo-Pacific Coral Reefs" },
      { id: "moray-eel-pharyngeal", title: "Moray Eel Alien-Like Second Pharyngeal Jaw", period: "Extant", who: "Muraenidae Family", where: "Tropical Crevices & Caves" },
      { id: "whale-shark-filter", title: "Whale Shark 40-Foot Gentle Plankton Sifter", period: "Extant", who: "Rhincodon typus", where: "Warm Pelagic Seas" },
      { id: "horseshoe-crab-blood", title: "Horseshoe Crab 450-Million-Year Blue LAL Blood", period: "Extant", who: "Limulus polyphemus", where: "Atlantic Coastal Shallows" },
      { id: "vampire-squid-detritus", title: "Vampire Squid Oxygen-Minimum Marine Snow Sifter", period: "Extant", who: "Vampyroteuthis infernalis", where: "Abyssal Oxygen-Minimum Zones" }
    ]
  },
  {
    name: "MythicalBiology",
    label: "Mythical & Dragon Archetypes",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>`,
    items: [
      { id: "european-wyvern-flight", title: "European Wyvern Archosaur Wing Anatomy", period: "Folklore / Prehistory", who: "Draco Bipedal Winged Archetype", where: "European Medieval Lore & Fossils" },
      { id: "asian-long-dragon-air", title: "Eastern Long Dragon Serpentine Undulation", period: "Ancient Mythos", who: "Chinese Celestial Serpent Archetype", where: "Yellow River & East Asia" },
      { id: "basilisk-toxin-gland", title: "Basilisk Cytotoxic Glandular Vapor", period: "Classical Lore", who: "Reptilian King of Serpents Archetype", where: "Cyrene, North Africa & Rome" },
      { id: "hydra-stem-cell-renewal", title: "Lernaean Hydra Polycephalic Regeneration", period: "Greco-Roman Lore", who: "Multi-Headed Regenerative Serpent", where: "Lake Lerna, Ancient Greece" },
      { id: "griffin-raptor-mammal", title: "Griffin Protoceratops Fossil Synthesis", period: "Scythian Lore", who: "Avian-Felid Predator Archetype", where: "Altai Mountains & Central Asia" },
      { id: "kraken-abyssal-giant", title: "Kraken Colossal Squid Island-Sinking Mythos", period: "Norse Folklore", who: "Hafgufa Ocean Leviathan", where: "Norwegian & Greenland Seas" },
      { id: "roc-thunderbird-giant", title: "Roc / Thunderbird Elephant-Lifting Raptor", period: "Arabian & Indigenous Lore", who: "Aepyornis / Teratorn Fossil Archetype", where: "Madagascar, Middle East & Americas" },
      { id: "quetzalcoatl-feathered-snake", title: "Quetzalcoatl Feathered Sky Serpent", period: "Mesoamerican Lore", who: "Aztec & Mayan Divine Dragon", where: "Teotihuacan & Yucatan" },
      { id: "phoenix-fire-renewal", title: "Phoenix Pyrogenic Molting & Rebirth Biology", period: "Ancient Egyptian / Greek", who: "Bennu Bird Solar Archetype", where: "Heliopolis & Mediterranean" },
      { id: "pegasus-aerodynamics", title: "Pegasus Dual-Pectoral Avian-Equine Skeleton", period: "Greco-Roman Lore", who: "Winged Equine Archetype", where: "Ancient Greece & Corinth" },
      { id: "cerberus-polycephaly", title: "Cerberus Triple-Brain Sensory Gatekeeper", period: "Greek Mythos", who: "Hades Guardian Hound", where: "Underworld Mythology" },
      { id: "chimera-poly-genetics", title: "Lycian Chimera Tri-Organism Genetic Mosaic", period: "Anatolian Lore", who: "Lion-Goat-Serpent Fire-Breather", where: "Mount Chimaera, Anatolia" },
      { id: "ouroboros-cyclical-metabolism", title: "Ouroboros Closed-Loop Metabolic Continuum", period: "Ancient Egyptian", who: "Tail-Devouring Cosmic Serpent", where: "Ancient Egypt & Gnosticism" },
      { id: "dragon-fire-gland-methane", title: "Biological Methane & Hypergolic Fire Glands", period: "Comparative Mythos", who: "Biochemical Organ Archetype", where: "Global Dragon Paleontology" },
      { id: "kirin-scaled-ungulate", title: "Qilin / Kirin Armored Hoofed Forest Spirit", period: "East Asian Lore", who: "Chimeric Scaled Unicorn", where: "China, Japan & Korea" },
      { id: "cockatrice-calcifying-gaze", title: "Cockatrice Petrifying Neurotoxic Glands", period: "Medieval Bestiary", who: "Serpent-Rooster Toxin Hybrid", where: "Western Europe" },
      { id: "leviathan-deep-furnace", title: "Leviathan Bioluminescent Oceanic Behemoth", period: "Ancient Near East", who: "Primordial Sea Dragon", where: "Canaanite & Biblical Lore" },
      { id: "lindworm-burrowing-wyrm", title: "Lindworm Limbless Giant Burrowing Dragon", period: "Germanic Folklore", who: "Subterranean Wyrm Lineage", where: "Scandinavia & Central Europe" },
      { id: "bunyip-australian-marsupial", title: "Bunyip Diprotodon Swamp Cryptid Archetype", period: "Aboriginal Dreamtime", who: "Pleistocene Megafauna Memory", where: "Billabongs of Australia" },
      { id: "megalania-ancient-dragon", title: "Varanus Priscus 23-Foot Australian Giant Dragon", period: "50,000 ya", who: "Megalania Giant Monitor Lizard", where: "Eastern Australia" }
    ]
  },
  {
    name: "HominidEvolution",
    label: "Primates & Human Ancestry",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>`,
    items: [
      { id: "sahelanthropus-tchadensis", title: "Sahelanthropus 7-Million-Year Bipedal Skull", period: "7 Mya", who: "Toumaï Early Hominin", where: "Djurab Desert, Chad" },
      { id: "ardipithecus-ramidus", title: "Ardi Grasping Big Toe & Upright Walking", period: "4.4 Mya", who: "Ardipithecus ramidus", where: "Aramis, Middle Awash, Ethiopia" },
      { id: "australopithecus-lucy", title: "Lucy (Australopithecus Afarensis) Pelvis", period: "3.2 Mya", who: "AL 288-1 Skeleton", where: "Hadar, Afar Triangle, Ethiopia" },
      { id: "homo-habilis-olduwan", title: "Homo Habilis Oldowan Flaked Stone Tools", period: "2.3–1.65 Mya", who: "Handy Man First Toolmaker", where: "Olduvai Gorge, Tanzania" },
      { id: "homo-erectus-fire", title: "Homo Erectus Controlled Fire & Acheulean Axe", period: "1.9 Mya–110,000 ya", who: "Upright Man Long-Distance Runner", where: "East Africa, Java & Georgia" },
      { id: "homo-heidelbergensis", title: "Homo Heidelbergensis Big Game Spear Hunting", period: "600,000–200,000 ya", who: "Archaic Human Spear Masters", where: "Schöningen, Germany & Africa" },
      { id: "neanderthal-adaptation", title: "Neanderthal Robust Cold Physique & Cave Art", period: "400,000–40,000 ya", who: "Homo neanderthalensis", where: "Eurasia & Gibraltar" },
      { id: "denisovan-high-altitude", title: "Denisovan EPAS1 High-Altitude Hypoxia Gene", period: "280,000–30,000 ya", who: "Denisova Hominin Lineage", where: "Denisova Cave, Siberia & Tibet" },
      { id: "homo-floresiensis-hobbit", title: "Homo Floresiensis 3.5-Foot Island Dwarfism", period: "100,000–50,000 ya", who: "The Hobbit Hominid", where: "Liang Bua Cave, Flores, Indonesia" },
      { id: "homo-naledi-burial", title: "Homo Naledi Rising Star Deep Chamber Burials", period: "335,000–236,000 ya", who: "Small-Brained Enigmatic Hominin", where: "Cradle of Humankind, South Africa" },
      { id: "homo-sapiens-cognitive", title: "Homo Sapiens Symbolic Cognitive Revolution", period: "300,000 ya–Present", who: "Anatomically Modern Humans", where: "Jebel Irhoud, Morocco & Global" },
      { id: "chimpanzee-termite-fishing", title: "Chimpanzee Termite Tool Culture & Coalitions", period: "Extant", who: "Pan troglodytes", where: "Gombe & West African Forests" },
      { id: "bonobo-empathy-society", title: "Bonobo Matriarchal Peace & Empathy Networks", period: "Extant", who: "Pan paniscus", where: "Congo Basin Rainforests" },
      { id: "mountain-gorilla-strength", title: "Silverback Gorilla 400-Pound Plant-Powered Muscle", period: "Extant", who: "Gorilla beringei beringei", where: "Virunga Volcanic Slopes" },
      { id: "bornean-orangutan-canopy", title: "Orangutan 8-Foot Armspan Canopy Engineering", period: "Extant", who: "Pongo pygmaeus", where: "Borneo & Sumatra Peat Forests" },
      { id: "ring-tailed-lemur-social", title: "Ring-Tailed Lemur Scent-Spurred Matriarchy", period: "Extant", who: "Lemur catta", where: "Spiny Forests, Madagascar" },
      { id: "philippine-tarsier-eyes", title: "Tarsier Brain-Sized Non-Rotating Night Eyes", period: "Extant", who: "Carlito syrichta", where: "Bohol, Philippines" },
      { id: "capuchin-stone-anvil", title: "Capuchin Monkey 3,000-Year Cashew Nut Metallurgy", period: "Extant", who: "Sapajus libidinosus", where: "Serra da Capivara, Brazil" },
      { id: "lar-gibbon-brachiation", title: "Lar Gibbon 35 mph Ballistic Arm-Swinging Flight", period: "Extant", who: "Hylobates lar", where: "Southeast Asian Rainforests" },
      { id: "hamadryas-baboon-clans", title: "Hamadryas Baboon Multi-Tiered Desert Troops", period: "Extant", who: "Papio hamadryas", where: "Horn of Africa & Arabia" }
    ]
  },
  {
    name: "InsectsAndSwarm",
    label: "Insects & Swarm Intelligence",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>`,
    items: [
      { id: "meganeura-giant-dragonfly", title: "Meganeura 2.5-Foot Oxygen-Rich Giant Dragonfly", period: "300 Mya", who: "Carboniferous Meganeuridae", where: "Commentry, France & UK" },
      { id: "arthropleura-giant-millipede", title: "Arthropleura 8-Foot 100-Pound Forest Millipede", period: "345–290 Mya", who: "Carboniferous Giant Arthropod", where: "North America & Scotland" },
      { id: "leafcutter-ant-agriculture", title: "Leafcutter Ant 50-Million-Year Fungus Farming", period: "Extant", who: "Atta cephalotes", where: "Neotropical Rainforests" },
      { id: "honeybee-waggle-dance", title: "Honeybee Polarized Sun Compass Waggle Dance", period: "Extant", who: "Apis mellifera", where: "Global Ecosystems" },
      { id: "bombardier-beetle-cannon", title: "Bombardier Beetle 100°C Hydroquinone Explosive Spray", period: "Extant", who: "Brachininae Family", where: "Global Woodlands" },
      { id: "monarch-butterfly-migration", title: "Monarch Butterfly 3,000-Mile Navigational Relay", period: "Extant", who: "Danaus plexippus", where: "Canada to Michoacán, Mexico" },
      { id: "trap-jaw-ant-strike", title: "Trap-Jaw Ant 140 mph Microsecond Mandible Snap", period: "Extant", who: "Odontomachus bauri", where: "Tropical Forests" },
      { id: "termite-mound-cooling", title: "Macrotermes Passive Zero-Energy HVAC Mounds", period: "Extant", who: "Macrotermes bellicosus", where: "African & Australian Savannas" },
      { id: "periodical-cicada-prime", title: "Periodical Cicada 13 & 17-Year Prime Emergence", period: "Extant", who: "Magicicada septendecim", where: "Eastern North America" },
      { id: "bullet-ant-sting", title: "Bullet Ant 24-Hour Poneratoxin Neurotoxic Sting", period: "Extant", who: "Paraponera clavata", where: "Central & South America" },
      { id: "silkworm-silk-protein", title: "Bombyx Mori Fibroin Tensile Silk Spinning", period: "Extant / 5000 BCE", who: "Bombyx mori", where: "China & Global" },
      { id: "peacock-spider-courtship", title: "Maratus Peacock Spider Diffraction Flap Dance", period: "Extant", who: "Maratus volans", where: "Southern Australia" },
      { id: "water-strider-surface-tension", title: "Water Strider Micro-Grooved Superhydrophobic Legs", period: "Extant", who: "Gerridae Family", where: "Freshwater Ponds Worldwide" },
      { id: "firefly-luciferin-flash", title: "Photuris Firefly 100% Efficiency Cold Light Flash", period: "Extant", who: "Lampyridae Family", where: "Global Temperate Meadows" },
      { id: "dung-beetle-milky-way", title: "Scarabaeus Dung Beetle Milky Way Galaxy Steering", period: "Extant", who: "Scarabaeus satyrus", where: "South African Savanna" },
      { id: "dragonfly-apex-intercept", title: "Dragonfly 95% Success Forward-Prediction Aerial Catch", period: "Extant", who: "Anisoptera Infraorder", where: "Global Wetlands" },
      { id: "flea-resilin-super-jump", title: "Cat Flea Resilin Protein 200g Acceleration Jump", period: "Extant", who: "Ctenocephalides felis", where: "Global Mammalian Hosts" },
      { id: "velvet-ant-exoskeleton", title: "Velvet Ant Steel-Crushing Spheroid Exoskeleton", period: "Extant", who: "Dasymutilla occidentalis", where: "North American Deserts" },
      { id: "assassin-bug-camouflage", title: "Acanthaspis Corpse-Carrying Stealth Camouflage", period: "Extant", who: "Acanthaspis petax", where: "East Africa & Malaysia" },
      { id: "army-ant-bivouac-bridge", title: "Eciton Army Ant Living Architecture Bridges", period: "Extant", who: "Eciton burchellii", where: "Central & South America" }
    ]
  },
  {
    name: "MammalianPredators",
    label: "Mammals & Extreme Hunters",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`,
    items: [
      { id: "african-lion-pride", title: "African Lion Coordinate Strategic Flanking Tactics", period: "Extant", who: "Panthera leo", where: "Sub-Saharan Africa" },
      { id: "siberian-tiger-solitary", title: "Siberian Tiger 600-Pound Sub-Zero Solitary Ambush", period: "Extant", who: "Panthera tigris altaica", where: "Russian Far East Taiga" },
      { id: "cheetah-acceleration", title: "Cheetah 0–60 in 2.9 Seconds Flexible Spine Sprint", period: "Extant", who: "Acinonyx jubatus", where: "Serengeti & Iran" },
      { id: "snow-leopard-high-altitude", title: "Snow Leopard 18,000-Foot Hemoglobin Altitude Grip", period: "Extant", who: "Panthera uncia", where: "Himalayas & Central Asia" },
      { id: "polar-bear-thermal-fur", title: "Polar Bear Hollow Fiber-Optic Insulation & Fat Shield", period: "Extant", who: "Ursus maritimus", where: "Circumpolar Arctic Ice" },
      { id: "spotted-hyena-jaw-crush", title: "Spotted Hyena 1,100 PSI Bone-Dissolving Acid Jaws", period: "Extant", who: "Crocuta crocuta", where: "African Savanna" },
      { id: "grey-wolf-pack-endurance", title: "Grey Wolf 50-Mile Relentless Trotting Pack Relay", period: "Extant", who: "Canis lupus", where: "Northern Hemisphere" },
      { id: "honey-badger-immunity", title: "Honey Badger Venom-Neutralizing Acetylcholine Shield", period: "Extant", who: "Mellivora capensis", where: "Africa & South Asia" },
      { id: "jaguar-skull-pierce", title: "Jaguar Caiman & Turtle Shell Piercing Canine Bite", period: "Extant", who: "Panthera onca", where: "Pantanal & Amazon Basin" },
      { id: "leopard-vertical-hoist", title: "Leopard 200-Pound Vertical Tree Hoisting Strength", period: "Extant", who: "Panthera pardus", where: "Africa & Asia" },
      { id: "wolverine-sub-zero-teeth", title: "Wolverine Special Molar for Chewing Frozen Bone", period: "Extant", who: "Gulo gulo", where: "Boreal Arctic Forests" },
      { id: "fennec-fox-giant-ears", title: "Fennec Fox Radiative Thermal Ears & Underground Hearing", period: "Extant", who: "Vulpes zerda", where: "Sahara Desert, Africa" },
      { id: "african-wild-dog-pack", title: "African Wild Dog 85% Hunt Success Symmetrical Relay", period: "Extant", who: "Lycaon pictus", where: "Southern & Eastern Africa" },
      { id: "caracal-aerial-snatch", title: "Caracal 10-Foot Vertical Leap 24-Muscle Swiveling Ears", period: "Extant", who: "Caracal caracal", where: "Africa & Middle East" },
      { id: "meerkat-sentry-sentinel", title: "Meerkat Underground Sentry Relay & Scorpion Immunity", period: "Extant", who: "Suricata suricatta", where: "Kalahari Desert" },
      { id: "tasmanian-devil-bite", title: "Tasmanian Devil Body-Ratio High-Power Scavenger Jaws", period: "Extant", who: "Sarcophilus harrisii", where: "Tasmania, Australia" },
      { id: "red-fox-magnetic-pounce", title: "Red Fox Earth Geomagnetic Field Rangefinder Pounce", period: "Extant", who: "Vulpes vulpes", where: "Northern Hemisphere" },
      { id: "clouded-leopard-ankle", title: "Clouded Leopard 180-Degree Rotating Tree Ankle Joints", period: "Extant", who: "Neofelis nebulosa", where: "Southeast Asian Forests" },
      { id: "sloth-bear-vacuum-snout", title: "Sloth Bear Lip-Sealed Vacuum Termite Extraction", period: "Extant", who: "Melursus ursinus", where: "Indian Subcontinent" },
      { id: "mongoose-cobra-reflex", title: "Indian Grey Mongoose Snake-Venom Resistant Alpha-Receptor", period: "Extant", who: "Urva edwardsii", where: "South Asia & Arabia" }
    ]
  },
  {
    name: "SensoryAdaptations",
    label: "Sensory Bio-Engineering",
    realm: "fauna",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>`,
    items: [
      { id: "microbat-echolocation", title: "Microbat 200 kHz Ultrasonic Laryngeal Echolocation", period: "Extant", who: "Microchiroptera Suborder", where: "Global Night Skies" },
      { id: "bottlenose-dolphin-melon", title: "Dolphin Acoustic Melon 3D Echolocation Imaging", period: "Extant", who: "Tursiops truncatus", where: "Global Coastal Waters" },
      { id: "pit-viper-thermal-vision", title: "Pit Viper 0.003°C Infrared Membrane Pit Organ", period: "Extant", who: "Crotalinae Subfamily", where: "Americas & Asia" },
      { id: "platypus-electro-bill", title: "Platypus Bill 40,000 Electro-Receptive Pores", period: "Extant", who: "Ornithorhynchus anatinus", where: "Eastern Australia" },
      { id: "pigeon-cryptochrome-compass", title: "Homing Pigeon Eye Cryptochrome Quantum Magnetic Compass", period: "Extant", who: "Columba livia", where: "Global" },
      { id: "chameleon-360-eyes", title: "Chameleon Independent Monocular Depth Telephoto Vision", period: "Extant", who: "Chamaeleonidae Family", where: "Madagascar & Africa" },
      { id: "elephant-infrasound-foot", title: "Elephant 14 Hz Infrasound Seismic Foot Reception", period: "Extant", who: "Loxodonta africana", where: "African Savanna" },
      { id: "cat-tapetum-lucidum", title: "Feline Retinal Tapetum Lucidum 6x Light Amplifier", period: "Extant", who: "Felis catus / Felidae", where: "Global" },
      { id: "barn-owl-asymmetric-ears", title: "Barn Owl Asymmetrical Ear Canal 3D Acoustic Geometry", period: "Extant", who: "Tyto alba", where: "Global" },
      { id: "salmon-magnetic-imprint", title: "Pacific Salmon 2,000-Mile Chemical & Magnetic River Return", period: "Extant", who: "Oncorhynchus nerka", where: "Pacific Ocean to Rivers" },
      { id: "star-nosed-mole-eimer", title: "Star-Nosed Mole 25,000 Eimer's Organ Micro-Touch Rays", period: "Extant", who: "Condylura cristata", where: "North American Wetlands" },
      { id: "tokay-gecko-van-der-waals", title: "Gecko Spatulae Nanoscale Van der Waals Dry Adhesion", period: "Extant", who: "Gekko gecko", where: "Southeast Asia & Global" },
      { id: "archerfish-optics", title: "Archerfish Air-Water Optical Refraction Water Cannon", period: "Extant", who: "Toxotes jaculatrix", where: "Mangrove Estuaries" },
      { id: "axolotl-limb-regeneration", title: "Axolotl Complete Heart, Limb & Brain Blastema Regeneration", period: "Extant", who: "Ambystoma mexicanum", where: "Lake Xochimilco, Mexico" },
      { id: "wood-frog-glucose-antifreeze", title: "Arctic Wood Frog Total Urea-Glucose Ice Cryobiosis", period: "Extant", who: "Lithobates sylvaticus", where: "Alaska & Boreal Forests" },
      { id: "tardigrade-cryptobiosis", title: "Tardigrade Radiation-Proof Anhydrobiosis Tun State", period: "Extant", who: "Tardigrada Phylum", where: "Global Lichen to Space Vacuum" },
      { id: "planarian-flatworm-immortality", title: "Planarian Neoblast Pluripotent Cellular Immortality", period: "Extant", who: "Schmidtea mediterranea", where: "Freshwater Springs" },
      { id: "naked-mole-rat-hypoxia", title: "Naked Mole-Rat Fructose Hypoxia & Cancer Immunity", period: "Extant", who: "Heterocephalus glaber", where: "Horn of Africa Burrows" },
      { id: "immortal-jellyfish-transdifferentiation", title: "Turritopsis Dohrnii Transdifferentiation Cellular Cycle", period: "Extant", who: "Turritopsis dohrnii", where: "Mediterranean & Japan Seas" },
      { id: "hammerhead-cephalofoil", title: "Hammerhead Shark Cephalofoil 360-Degree Electro-Sweep", period: "Extant", who: "Sphyrna mokarran", where: "Tropical Coastal Oceans" }
    ]
  }
];

// Master Dictionary of Popular / Modern Calling Names for Rapid User Identification
const COMMON_NAMES = {
  // Transportation
  "wheel": "Wheel",
  "chariot": "Chariot (War Cart)",
  "sailing-ship": "Sailboat & Ship",
  "magnetic-compass": "Magnetic Compass",
  "horseshoe-stirrup": "Horseshoe & Stirrup",
  "stagecoach": "Horse Carriage (Stagecoach)",
  "hot-air-balloon": "Hot Air Balloon",
  "steamboat": "Steamboat (Steamship)",
  "steam-locomotive": "Train (Steam Locomotive)",
  "bicycle": "Bicycle (Cycle)",
  "ocean-liner": "Cruise & Ocean Liner",
  "pneumatic-tire": "Rubber Tire / Tyre",
  "cable-car": "Cable Car / Tramway",
  "electric-tram": "Metro Tram / Streetcar",
  "motorcycle": "Bike (Motorcycle)",
  "automobile": "Car (Automobile)",
  "diesel-engine": "Diesel Engine",
  "submarine": "Submarine (Sub)",
  "airship-zeppelin": "Zeppelin (Airship)",
  "airplane": "Airplane (Aeroplane)",
  "jet-engine": "Jet Engine / Turbojet",

  // Communication
  "cuneiform-tablets": "Clay Tablet (Writing)",
  "papyrus-scroll": "Papyrus Scroll (Paper Roll)",
  "paper-making": "Paper Sheet",
  "postal-courier": "Postal Mail Service",
  "printing-press": "Printing Press (Book Printer)",
  "optical-semaphore": "Optical Semaphore Tower",
  "braille-system": "Braille (Blind Alphabet)",
  "postage-stamp": "Postal Stamp",
  "electric-telegraph": "Telegraph (Morse Code)",
  "transatlantic-cable": "Undersea Cable (Global Web)",
  "typewriter": "Typewriter (QWERTY)",
  "telephone": "Landline Phone (Telephone)",
  "switchboard": "Telecom Switchboard",
  "radio": "Radio Transmitter",
  "am-broadcast": "AM Radio Broadcast",
  "teleprinter": "Telex / Fax Machine",
  "fm-radio": "FM Radio",
  "walkie-talkie": "Walkie-Talkie (2-Way Radio)",
  "communication-satellite": "Satellite (Telecom Orbit)",
  "touch-tone-phone": "Push-Button Keypad Phone",
  "optical-fiber": "Fiber Optics (Broadband Net)",

  // Computing & AI
  "abacus": "Abacus (Counting Frame)",
  "antikythera-mechanism": "Antikythera (First Analog Computer)",
  "slide-rule": "Slide Rule (Calculator)",
  "pascaline-calculator": "Mechanical Calculator",
  "stepped-reckoner-binary": "Binary Logic",
  "jacquard-punch-card-loom": "Punch Card Programming",
  "analytical-engine-babbage": "Mechanical Computer (Babbage)",
  "ada-lovelace-algorithm": "Computer Algorithm (Ada)",
  "boolean-algebra-logic": "Boolean Logic (0s & 1s)",
  "hollerith-tabulating-machine": "Punch Card Tabulator",
  "turing-machine-concept": "Turing Machine (Modern Computing)",
  "colossus-codebreaking-computer": "Colossus Codebreaker",
  "eniac-electronic-computer": "ENIAC (First Digital Computer)",
  "bipolar-junction-transistor": "Silicon Transistor",
  "magnetic-core-memory": "RAM Memory Core",
  "compiler-cobol-hopper": "Software Compiler (COBOL)",
  "hard-disk-drive-ramac": "Hard Disk Drive (HDD / Storage)",
  "integrated-circuit-microchip": "Microchip (Integrated Circuit)",
  "computer-mouse-gui": "Mouse & GUI Desktop",
  "microprocessor-intel-4004": "CPU (Microprocessor Chip)",
  "artificial-neural-network": "AI & Deep Learning (Artificial Intelligence)",

  // Home & Living
  "soap-alkali-fats": "Soap (Cleaning Bar)",
  "mechanical-weight-driven-clock": "Wall Clock / Watch",
  "reading-spectacles-eyeglasses": "Eyeglasses / Spectacles",
  "flush-toilet-s-trap": "Flush Toilet & Commode",
  "pressure-cooker-digester": "Pressure Cooker",
  "cast-iron-kitchen-stove": "Cooking Stove / Cooktop",
  "canned-food-appertization": "Canned Food (Tinned Food)",
  "friction-safety-match": "Matchbox (Safety Match)",
  "refrigerator-vapor-compression": "Fridge (Refrigerator)",
  "sewing-machine-lockstitch": "Sewing Machine",
  "safety-pin": "Safety Pin",
  "mason-jar-canning": "Mason Glass Jar",
  "incandescent-light-bulb": "Electric Light Bulb",
  "zipper-slide-fastener": "Zipper (Zip Fastener)",
  "safety-razor-disposable": "Safety Shaving Razor",
  "vacuum-cleaner-motorized": "Vacuum Cleaner (Hoover)",
  "air-conditioner-carrier": "AC (Air Conditioner)",
  "washing-machine-electric": "Washing Machine",
  "electric-toaster-pop-up": "Pop-Up Bread Toaster",
  "microwave-oven-radar": "Microwave Oven",
  "led-lighting-efficient": "LED Bulb / Lighting",

  // Media & Sound
  "camera-obscura-daguerreotype": "Camera (Photography)",
  "magic-lantern-projector": "Slide Projector",
  "lithographic-printing": "Color Lithography",
  "roll-film-kodak": "Roll Film (Kodak Camera)",
  "phonograph-cylinder-edison": "Phonograph (Record Player)",
  "gramophone-disc-record": "Gramophone (Vinyl Disc)",
  "cinematographe-motion-picture": "Movie Cinema Projector",
  "cathode-ray-tube-display": "CRT Display Monitor",
  "carbon-microphone": "Mic (Microphone)",
  "condenser-microphone": "Studio Condenser Mic",
  "moving-coil-loudspeaker": "Speaker (Sound Box)",
  "sound-on-film-talkies": "Movie Soundtrack (Cinema Sound)",
  "compact-35mm-camera": "35mm Handheld Camera",
  "electronic-television-crt": "TV (Television)",
  "technicolor-color-film": "Technicolor (Color Cinema)",
  "magnetic-tape-recorder": "Audio Tape Recorder (Cassette)",
  "instant-polaroid-camera": "Instant Polaroid Camera",
  "vinyl-long-play-record": "Vinyl LP Album Record",
  "compact-cassette-audio": "Cassette Tape & Walkman",
  "compact-disc-digital-audio": "CD & DVD Disc",
  "vr-headset-display": "VR Headset (Virtual Reality)",

  // Medicine & Health
  "acoustic-stethoscope": "Stethoscope",
  "ether-general-anesthesia": "Anesthesia (Pain-Free Surgery)",
  "hypodermic-syringe-needle": "Injection Syringe & Needle",
  "antiseptic-carbolic-surgery": "Antiseptic Disinfectant",
  "smallpox-vaccine-jenner": "Smallpox Vaccine",
  "rabies-vaccine-pasteur": "Rabies Vaccine",
  "diagnostic-x-ray": "Medical X-Ray Imaging",
  "abo-blood-typing": "Blood Group Typing (A, B, O)",
  "electrocardiogram-ecg": "ECG / EKG Heart Monitor",
  "penicillin-antibiotic": "Penicillin (Antibiotic Medicine)",
  "electron-microscope-tem": "Electron Microscope",
  "hemodialysis-artificial-kidney": "Dialysis (Artificial Kidney)",
  "polio-vaccine-salk": "Polio Vaccine Drops",
  "dna-double-helix-model": "DNA Double Helix (Genetics)",
  "implantable-cardiac-pacemaker": "Heart Pacemaker",
  "defibrillator-cpr": "Shock Defibrillator (AED)",
  "computed-tomography-ct-scan": "CT Scan Machine",
  "mri-magnetic-resonance": "MRI Scanner (Body Scan)",
  "dna-sequencing-sanger": "DNA Sequencer (Genome Map)",
  "robotic-surgical-system": "Robotic Surgery (Da Vinci Robot)",
  "crispr-cas9-gene-editing": "CRISPR Gene Editing (Gene Therapy)",

  // Space & Astronomy
  "astronomical-telescope": "Space Telescope (Telescope)",
  "liquid-rocket": "Liquid Fuel Rocket Engine",
  "v2-rocket": "Guided Ballistic Rocket",
  "sputnik-satellite": "Artificial Satellite (Sputnik)",
  "vostok-spacecraft": "Human Spacecraft (Vostok / Apollo)",
  "saturn-v-rocket": "Moon Rocket (Saturn V)",
  "lunar-module": "Moon Lander (Lunar Module)",
  "space-suit-emu": "Spacesuit (Astronaut Suit)",
  "lunar-rover": "Moon Buggy (Lunar Rover Car)",
  "space-shuttle": "Space Shuttle Orbiter",
  "hubble-telescope": "Hubble Space Telescope",
  "space-station-iss": "Space Station (ISS Orbital Base)",
  "voyager-probes": "Voyager Space Probe",
  "mars-curiosity-rover": "Mars Science Rover Robot",
  "jwst-space-telescope": "James Webb Telescope (JWST)",
  "reusable-booster": "Reusable Landing Rocket (Falcon 9)",
  "starlink-constellation": "Satellite Internet Mesh (Starlink)",
  "spacex-starship": "Starship Megarocket",
  "mars-ingenuity-helicopter": "Mars Drone Helicopter (Ingenuity)",
  "asteroid-sample-return": "Asteroid Sample Capsule",

  // Ancient Wisdom & Siddhars
  "siddha-alchemy-rasavada": "Siddhar Alchemy (Rasavada & Kayakalpa)",
  "ayurvedic-tridosha": "Ayurveda (Herbal Medicine & Tridosha)",
  "sushruta-rhinoplasty": "Plastic Surgery (Sushruta Ancient Surgery)",
  "kundalini-pranayama": "Yoga & Pranayama (Nervous Bio-Energy)",
  "panchaloha-bronze": "Panchaloha Sacred Idol (5-Metal Alloy)",
  "palm-leaf-manuscripts": "Palm-Leaf Manuscript (Olai Chuvadi)",
  "wootz-crucible-steel": "Damascus Steel (Wootz Crucible Steel)",
  "kalarippayattu-marma": "Kalarippayattu (108 Marma Vital Points)",
  "sacred-gopuram-geometry": "Temple Gopuram (Vedic Acoustic Architecture)",
  "kallanai-grand-anicut": "Kallanai Stone Dam (Grand Anicut)",
  "stepwell-step-hydraulics": "Stepwell Baoli (Underground Water Temple)",
  "surya-siddhanta-astronomy": "Surya Siddhanta (Ancient Planetary Math)",
  "panchakarma-detox": "Panchakarma (Cellular Detox Therapy)",
  "jantar-mantar-sundials": "Jantar Mantar (Giant Stone Sundial Observatory)",
  "yoga-sutras-mind-control": "Yoga Sutras (Patanjali Meditation Psychology)",
  "herbal-kayakalpa-rejuvenation": "Kayakalpa Longevity Elixir (Siddhar Bogar)",
  "vastu-shastra-grid": "Vastu Mandala (Architectural Energy Grid)",
  "musical-stone-pillars": "Musical Granite Pillars (Acoustic Stone)",
  "chola-lost-wax-nataraja": "Nataraja Bronze (Cosmic Dance Sculpture)",
  "ancient-natural-dye-indigo": "Indigo Natural Dye (Organic Fabric Dye)",

  // Dinosaurs & Archosaurs
  "tyrannosaurus-rex": "T-Rex (King Dinosaur)",
  "spinosaurus-aegyptiacus": "Spinosaurus (Giant River Predator)",
  "velociraptor-mongoliensis": "Velociraptor (Pack Hunter Raptor)",
  "triceratops-prorsus": "Triceratops (3-Horned Shield Dinosaur)",
  "brachiosaurus-altithorax": "Brachiosaurus (Giant Long-Neck)",
  "ankylosaurus-magniventris": "Ankylosaurus (Armored Tank Dinosaur)",
  "stegosaurus-stenops": "Stegosaurus (Plate-Backed Dinosaur)",
  "allosaurus-fragilis": "Allosaurus (Jurassic Apex Hunter)",
  "pachycephalosaurus-wyomingensis": "Pachycephalosaurus (Bone Dome Head-Butter)",
  "carnotaurus-sastrei": "Carnotaurus (Bull-Horned Speed Hunter)",
  "giganotosaurus-carolinii": "Giganotosaurus (Giant Meat-Eater)",
  "microraptor-gui": "Microraptor (4-Winged Gliding Dino)",
  "quetzalcoatlus-northropi": "Quetzalcoatlus (Giant Flying Pterosaur)",
  "pteranodon-longiceps": "Pteranodon (Crested Ocean Glider)",
  "mosasaurus-hoffmannii": "Mosasaurus (Giant Sea Monster)",
  "plesiosaurus-dolichodeirus": "Plesiosaurus (Long-Neck Sea Reptile)",
  "dimetrodon-grandis": "Dimetrodon (Sail-Backed Reptile)",
  "iguanodon-bernissartensis": "Iguanodon (Thumb-Spike Herbivore)",
  "parasaurolophus-walkeri": "Parasaurolophus (Horn-Crest Music Dinosaur)",
  "deinocheirus-mirificus": "Deinocheirus (Giant Scythe-Claw Dino)",

  // Birds & Avian Flight
  "archaeopteryx-lithographica": "Archaeopteryx (First Feathered Bird-Dino)",
  "peregrine-falcon-dive": "Peregrine Falcon (390 km/h Dive Hunter)",
  "harpy-eagle-talons": "Harpy Eagle (Canopy Apex Raptor)",
  "hummingbird-hover": "Hummingbird (80-BPS Hover Flier)",
  "barn-owl-silent-flight": "Barn Owl (Silent Night Hunter)",
  "emperor-penguin-insulation": "Emperor Penguin (Antarctic Diver)",
  "wandering-albatross-glide": "Albatross (11-Foot Glider Bird)",
  "ostrich-running-mechanics": "Ostrich (70 km/h Land Sprinter)",
  "corvid-crow-intelligence": "Crow & Raven (Tool-Making Smart Bird)",
  "peafowl-sexual-selection": "Peacock (Iridescent Tail Feathers)",
  "african-grey-parrot-vocal": "Parrot (Acoustic Speech Genius)",
  "greater-flamingo-filter": "Flamingo (Pink Filter-Feeding Bird)",
  "toco-toucan-thermo-beak": "Toucan (Rainbow Heat-Radiating Beak)",
  "common-swift-nonstop": "Swift (10-Month Non-Stop Flier)",
  "griffon-vulture-immunity": "Vulture (Acid-Stomach Scavenger)",
  "sociable-weaver-nest": "Weaver Bird (100-Chamber Mega-Nest)",
  "kiwi-vestigial-whisker": "Kiwi Bird (Nocturnal Whisker Bird)",
  "woodpecker-skull-shock": "Woodpecker (Brain Shock-Absorbing Bird)",
  "argentine-giant-bird": "Argentavis (23-Foot Giant Condor)",
  "passenger-pigeon-flocks": "Passenger Pigeon (Billion-Bird Flock)",

  // Prehistoric Megafauna
  "woolly-mammoth": "Woolly Mammoth (Giant Tusked Ice Giant)",
  "smilodon-fatalis": "Saber-Toothed Tiger (Smilodon)",
  "megatherium-sloth": "Megatherium (4-Ton Giant Ground Sloth)",
  "paraceratherium-rhino": "Paraceratherium (20-Ton Giant Hornless Rhino)",
  "megaloceros-giant-elk": "Irish Elk (12-Foot Giant Antler Deer)",
  "glyptodon-armor": "Glyptodon (2-Ton Armored Armadillo Giant)",
  "dire-wolf": "Dire Wolf (Ice Age Apex Pack Hunter)",
  "cave-bear": "Cave Bear (Ice Age Giant Bear)",
  "diprotodon-optatum": "Diprotodon (3-Ton Giant Marsupial Wombat)",
  "elasmotherium-unicorn": "Siberian Unicorn (Giant Horned Rhino)",
  "woolly-rhinoceros": "Woolly Rhino (Tundra Two-Horned Rhino)",
  "giant-moa-dinornis": "Giant Moa (12-Foot Flightless Bird)",
  "dodo-bird": "Dodo Bird (Flightless Island Bird)",
  "thylacine-tasmanian-tiger": "Tasmanian Tiger (Thylacine Marsupial)",
  "haasts-eagle": "Haast's Eagle (Giant Moa-Hunting Raptor)",
  "titanoboa-cerrejonensis": "Titanoboa (42-Foot Monster Rainforest Snake)",
  "andrewsarchus-mongoliensis": "Andrewsarchus (Giant Carnivorous Mammal)",
  "entelodont-hell-pig": "Hell Pig (Bone-Crushing Entelodont)",
  "chalicotherium-knuckle": "Chalicotherium (Knuckle-Walking Claw Grazer)",
  "sivatherium-giant-giraffe": "Sivatherium (Giant Armored Giraffe)",

  // Marine & Ocean Life
  "otodus-megalodon": "Megalodon (60-Foot Giant Apex Shark)",
  "blue-whale-baleen": "Blue Whale (200-Ton Ocean Leviathan)",
  "basilosaurus-whale": "Basilosaurus (Ancient 60-Foot Serpentine Whale)",
  "giant-squid-architeuthis": "Giant Squid (Deep Ocean Kraken)",
  "orca-killer-whale": "Orca (Killer Whale Pod Hunter)",
  "great-white-electro-sense": "Great White Shark (Ocean Apex Predator)",
  "coelacanth-living-fossil": "Coelacanth (Living Fossil Lobe-Finned Fish)",
  "giant-manta-ray-glider": "Giant Manta Ray (23-Foot Ocean Glider)",
  "deep-sea-anglerfish-lure": "Anglerfish (Bioluminescent Deep Sea Predator)",
  "box-jellyfish-neurotoxin": "Box Jellyfish (Deadliest Venomous Sea Stinger)",
  "electric-eel-860v": "Electric Eel (860V Bio-Electric Shocker)",
  "sailfish-110kmh": "Sailfish (110 km/h Fastest Ocean Sprinter)",
  "sperm-whale-deep-dive": "Sperm Whale (3,000-Meter Deep Diver)",
  "mimic-octopus-shapeshift": "Mimic Octopus (Shapeshifting Camouflage Master)",
  "mantis-shrimp-cavitation": "Mantis Shrimp (Bullet Punch & 16-Color Vision)",
  "whale-shark-gentle-giant": "Whale Shark (40-Foot Gentle Giant)",
  "moray-eel-pharyngeal-jaw": "Moray Eel (Dual Alien Pharyngeal Jaws)",
  "nautilus-jet-propulsion": "Nautilus (500-Million-Year Submarine Shell)",
  "dunkleosteus-bone-shear": "Dunkleosteus (Armored Shark-Crushing Fish)",
  "helicoprion-spiral-jaw": "Helicoprion (Spiral Buzzsaw Shark)"
};

function getCommonCallingName(item) {
  if (COMMON_NAMES[item.id]) return COMMON_NAMES[item.id];
  const words = item.title.split(" ");
  if (words.length <= 2) return item.title;
  return words.slice(0, 2).join(" ");
}

// Combine all 20 domains into full structured dataset
const allDomainsList = [...humanDomains, ...faunaDomains];
const fullInventionsDataset = [];

allDomainsList.forEach(domain => {
  domain.items.forEach(item => {
    const isHuman = domain.realm === "human";
    const title = item.title;
    const commonName = getCommonCallingName(item);
    const cat = domain.name;
    const period = item.period;
    const who = item.who;
    const where = item.where;

    fullInventionsDataset.push({
      id: item.id,
      title: title,
      commonName: commonName,
      category: cat,
      realm: domain.realm,
      period: period,
      subtitle: isHuman 
        ? `How the ${title} fundamentally transformed civilization in ${domain.label.toLowerCase()}.`
        : `The evolutionary adaptation, biomechanics, and survival marvel of ${title}.`,
      summary: isHuman
        ? `Invented in ${period} by ${who} in ${where}, revolutionizing human capability and establishing the foundation for modern ${domain.label.toLowerCase()} systems.`
        : `Evolved during ${period} through natural selection among ${who} in ${where}, showcasing extraordinary biological engineering.`,
      who: isHuman ? `${who}, building upon collaborative scientific and industrial traditions.` : `${who} (Taxonomic lineage & biological classification).`,
      when: `${period} (Key evolutionary milestone epoch).`,
      where: `${where}.`,
      whatIsIt: isHuman
        ? `The ${title} is a landmark breakthrough in ${domain.label.toLowerCase()} designed to solve critical physical or cognitive limitations through engineering.`
        : `A world-class biological adaptation in ${domain.label.toLowerCase()} featuring specialized anatomical structures and physiological survival traits.`,
      whyCreated: isHuman
        ? `Created to address urgent societal, economic, and human needs for improved efficiency, speed, safety, and reliability in daily activities.`
        : `Evolved through intense environmental selection pressures, ecological niche competition, predation, and climactic survival demands.`,
      problemBefore: isHuman
        ? `Before the invention of the ${title}, humans were constrained by slow manual methods, severe physical strain, environmental hazards, and biological limitations.`
        : `Prior species lacked these specialized biomechanical structures, suffering high predation rates, feeding inefficiencies, or geographical range limits.`,
      olderUsage: isHuman
        ? `Early versions required manual operation, craftsman tuning, and dedicated physical handling under challenging historical operating conditions.`
        : `Ancestral primitive species possessed rudimentary unspecialized structures before gradual morphological refinement over millions of years.`,
      limitations: isHuman
        ? `Early historical models suffered from initial material constraints, higher production costs, mechanical wear, and limited scalability.`
        : `High metabolic energy costs to maintain specialized organs, vulnerability to rapid ecosystem shifts, or extreme habitat dependence.`,
      whyEvolved: isHuman
        ? `Evolved rapidly due to surging population demands, advancements in materials science, electrification, microelectronics, and automation.`
        : `Driven by arms-race co-evolution between predators and prey, environmental temperature swings, continental drift, and dietary specializations.`,
      evolutionSteps: [
        { era: period, text: isHuman ? `Initial prototype and foundational emergence by ${who} in ${where}.` : `Earliest fossil emergence and morphological adaptation in ${where}.` },
        { era: isHuman ? "Industrial Epoch" : "Diversification Phase", text: isHuman ? `Standardization of interchangeable parts and mass production.` : `Radiation into multiple specialized subspecies across varied ecological niches.` },
        { era: isHuman ? "20th Century" : "Apex Epoch", text: isHuman ? `Electrification, solid-state electronics, and global distribution.` : `Attainment of peak physiological efficiency and ecological dominance.` },
        { era: isHuman ? "Digital Era" : "Modern Descendants", text: isHuman ? `Microprocessor control, digital telemetry, sensor integration, and high efficiency.` : `Genetic legacy surviving in modern bird, reptilian, or mammalian lineages.` },
        { era: "Today", text: isHuman ? `Smart networked iterations incorporating artificial intelligence and sustainable materials.` : `Modern bio-mimicry applications inspiring aerospace, robotics, and advanced materials.` }
      ],
      modernVersion: isHuman
        ? `Modern high-efficiency, digitally controlled, automated, and sustainable iterations of ${title}.`
        : `Contemporary living descendants, bio-mimetic engineering models, and preserved fossil records of ${title}.`,
      modernUsage: isHuman
        ? `Integrated into the daily lives, infrastructure, healthcare, energy grid, agriculture, or exploration of billions of people globally.`
        : `Inspires modern aerodynamic aircraft winglets, sonar sensors, soft robotics, surgical adhesives, and ecological conservation.`,
      futureOutlook: isHuman
        ? `Integration with autonomous artificial intelligence systems, quantum precision materials, and zero-carbon sustainable engineering.`
        : `Genetic de-extinction biotechnology (CRISPR mammoth recovery), biomimetic synthetic organs, and AI-driven deep phylogenetic mapping.`,
      comparison: {
        size: { 
          then: isHuman ? "Bulky, heavy mechanical installation or manual wooden/iron frame" : "Ancestral unspecialized baseline anatomy", 
          now: isHuman ? "Compact, ergonomic, solid-state, or lightweight composite materials" : "Hyper-specialized, aerodynamically optimized modern form" 
        },
        speed: { 
          then: isHuman ? "Slow manual or mechanical execution with human lag" : "Sluggish ancestral locomotion", 
          now: isHuman ? "Instantaneous, high-speed, or computerized precision execution" : "Apex biomechanical velocity, strike reflex, or sustained flight" 
        },
        function: { 
          then: isHuman ? "Single dedicated physical function with manual adjustments" : "Primitive generalized biological function", 
          now: isHuman ? "Multimodal, automated, multi-purpose digital platform" : "Multifunctional sensory integration and extreme survival versatility" 
        },
        connectivity: { 
          then: isHuman ? "Completely isolated standalone physical object" : "Solitary uncoordinated behavior", 
          now: isHuman ? "Cloud-connected, IoT telemetry, and global data synchronization" : "Swarm intelligence, infrasonic communication, or echolocation mapping" 
        },
        power: { 
          then: isHuman ? "Biological muscle, steam coal fire, or heavy direct batteries" : "High metabolic strain and inefficient digestion", 
          now: isHuman ? "Ultra-efficient electrical micro-power or renewable clean energy" : "Optimized metabolic calorie conversion and thermoregulation" 
        },
        userExperience: { 
          then: isHuman ? "Complex manual calibration requiring physical strength" : "Vulnerable to environmental shocks and predators", 
          now: isHuman ? "Intuitive touch, voice commands, ergonomic design, or automation" : "Apex ecological niche mastery and evolutionary resilience" 
        }
      }
    });
  });
});

console.log(`Successfully generated ${fullInventionsDataset.length} total dossiers across ${allDomainsList.length} domains!`);

// Extract category metadata for the script
const categoriesConfig = allDomainsList.map(dom => ({
  name: dom.name,
  label: dom.label,
  realm: dom.realm,
  icon: dom.icon
}));

// Build script.js
const scriptCode = `/**
 * ==========================================================================
 * Creation & Evolution — Massive Dual-Realm Encyclopedia (${fullInventionsDataset.length} Total Dossiers)
 * Realm 1: Human Civilizational & Technological Evolution (200+ Topics)
 * Realm 2: Animals, Dinosaurs, Birds & Biological Evolution (200+ Topics)
 * 20 Specialized Domains | 12-Point Structured Dossiers | Instant Search
 * ==========================================================================
 */

// --------------------------------------------------------------------------
// 1. MASTER INVENTIONS & EVOLUTION DATASET (${fullInventionsDataset.length} Items)
// --------------------------------------------------------------------------
const INVENTIONS_DATA = ${JSON.stringify(fullInventionsDataset, null, 2)};

// --------------------------------------------------------------------------
// 2. 20 SPECIALIZED DOMAINS CONFIGURATION
// --------------------------------------------------------------------------
const CATEGORIES_CONFIG = ${JSON.stringify(categoriesConfig, null, 2)};

// --------------------------------------------------------------------------
// 3. APPLICATION STATE
// --------------------------------------------------------------------------
const state = {
  activeRealm: "human", // "human" or "fauna"
  currentCategory: "All",
  searchQuery: "",
  activeComparisonId: "automobile",
  activeModalId: null,
  currentPage: 1,
  cardsPerPage: 18
};

// --------------------------------------------------------------------------
// 4. DOM ELEMENT REFERENCES
// --------------------------------------------------------------------------
const elements = {
  // Navigation & Search
  searchInput: document.getElementById("search-input"),
  searchClearBtn: document.getElementById("search-clear-btn"),
  categoryFiltersContainer: document.getElementById("category-filters-container"),
  resultsCountText: document.getElementById("results-count-text"),
  resetAllFiltersBtn: document.getElementById("reset-all-filters-btn"),
  mobileMenuToggle: document.getElementById("mobile-menu-toggle"),
  mobileMenu: document.getElementById("mobile-menu"),
  quickSearchBtn: document.getElementById("quick-search-btn"),

  // Realm Switchers (Navbar & Hero)
  navRealmHumanBtn: document.getElementById("nav-realm-human-btn"),
  navRealmFaunaBtn: document.getElementById("nav-realm-fauna-btn"),
  heroRealmHumanBtn: document.getElementById("hero-realm-human-btn"),
  heroRealmFaunaBtn: document.getElementById("hero-realm-fauna-btn"),
  heroBadgeText: document.getElementById("hero-badge-text"),
  heroMainTitle: document.getElementById("hero-main-title"),
  heroMainSubtitle: document.getElementById("hero-main-subtitle"),

  // Inventions Grid & Pagination
  inventionsGrid: document.getElementById("inventions-grid"),
  noResultsState: document.getElementById("no-results-state"),
  noResultsResetBtn: document.getElementById("no-results-reset-btn"),
  statInventionsCount: document.getElementById("stat-inventions-count"),
  statDomainsCount: document.getElementById("stat-domains-count"),
  loadMoreContainer: document.getElementById("load-more-container"),
  loadMoreBtn: document.getElementById("load-more-btn"),
  gridHeadingText: document.getElementById("grid-heading-text"),
  gridSubheadingText: document.getElementById("grid-subheading-text"),

  // Timeline
  desktopTimelineContainer: document.getElementById("desktop-timeline-container"),
  desktopTimelineTrack: document.getElementById("desktop-timeline-track"),
  timelineScrollLeftBtn: document.getElementById("timeline-scroll-left-btn"),
  timelineScrollRightBtn: document.getElementById("timeline-scroll-right-btn"),
  mobileTimelineContainer: document.getElementById("mobile-timeline-container"),

  // Comparison Matrix
  comparisonSelectorTabs: document.getElementById("comparison-selector-tabs"),
  compCategoryBadge: document.getElementById("comp-category-badge"),
  compTitle: document.getElementById("comp-title"),
  compViewArticleBtn: document.getElementById("comp-view-article-btn"),
  comparisonTableBody: document.getElementById("comparison-table-body"),

  // Modal Dialog
  articleModal: document.getElementById("article-modal"),
  modalBackdrop: document.getElementById("modal-backdrop"),
  modalCard: document.getElementById("modal-card"),
  modalCloseBtn: document.getElementById("modal-close-btn"),
  modalFooterCloseBtn: document.getElementById("modal-footer-close-btn"),
  modalScrollableBody: document.getElementById("modal-scrollable-body"),
  
  // Modal Fields
  modalCategoryBadge: document.getElementById("modal-category-badge"),
  modalPeriodBadge: document.getElementById("modal-period-badge"),
  modalTitle: document.getElementById("modal-title"),
  modalSubtitle: document.getElementById("modal-subtitle"),
  modalMetaWho: document.getElementById("modal-meta-who"),
  modalMetaWhen: document.getElementById("modal-meta-when"),
  modalMetaWhere: document.getElementById("modal-meta-where"),
  modalSecWhat: document.getElementById("modal-sec-what"),
  modalSecWhyCreated: document.getElementById("modal-sec-why-created"),
  modalSecProblemBefore: document.getElementById("modal-sec-problem-before"),
  modalSecWho: document.getElementById("modal-sec-who"),
  modalSecWhenWhere: document.getElementById("modal-sec-when-where"),
  modalSecOlderUsage: document.getElementById("modal-sec-older-usage"),
  modalSecLimitations: document.getElementById("modal-sec-limitations"),
  modalSecWhyEvolve: document.getElementById("modal-sec-why-evolve"),
  modalSecEvolutionSteps: document.getElementById("modal-sec-evolution-steps"),
  modalSecModernVersion: document.getElementById("modal-sec-modern-version"),
  modalSecModernUsage: document.getElementById("modal-sec-modern-usage"),
  modalSecFuture: document.getElementById("modal-sec-future"),
  modalComparisonTbody: document.getElementById("modal-comparison-tbody")
};

// --------------------------------------------------------------------------
// 5. INITIALIZATION & SETUP
// --------------------------------------------------------------------------
function refreshElements() {
  elements.searchInput = document.getElementById("search-input");
  elements.searchClearBtn = document.getElementById("search-clear-btn");
  elements.categoryFiltersContainer = document.getElementById("category-filters-container");
  elements.resultsCountText = document.getElementById("results-count-text");
  elements.resetAllFiltersBtn = document.getElementById("reset-all-filters-btn");
  elements.mobileMenuToggle = document.getElementById("mobile-menu-toggle");
  elements.mobileMenu = document.getElementById("mobile-menu");
  elements.quickSearchBtn = document.getElementById("quick-search-btn");

  elements.navRealmHumanBtn = document.getElementById("nav-realm-human-btn");
  elements.navRealmFaunaBtn = document.getElementById("nav-realm-fauna-btn");
  elements.heroRealmHumanBtn = document.getElementById("hero-realm-human-btn");
  elements.heroRealmFaunaBtn = document.getElementById("hero-realm-fauna-btn");
  elements.heroBadgeText = document.getElementById("hero-badge-text");
  elements.heroMainTitle = document.getElementById("hero-main-title");
  elements.heroMainSubtitle = document.getElementById("hero-main-subtitle");

  elements.inventionsGrid = document.getElementById("inventions-grid");
  elements.noResultsState = document.getElementById("no-results-state");
  elements.noResultsResetBtn = document.getElementById("no-results-reset-btn");
  elements.statInventionsCount = document.getElementById("stat-inventions-count");
  elements.statDomainsCount = document.getElementById("stat-domains-count");
  elements.loadMoreContainer = document.getElementById("load-more-container");
  elements.loadMoreBtn = document.getElementById("load-more-btn");
  elements.gridHeadingText = document.getElementById("grid-heading-text");
  elements.gridSubheadingText = document.getElementById("grid-subheading-text");

  elements.desktopTimelineContainer = document.getElementById("desktop-timeline-container");
  elements.desktopTimelineTrack = document.getElementById("desktop-timeline-track");
  elements.timelineScrollLeftBtn = document.getElementById("timeline-scroll-left-btn");
  elements.timelineScrollRightBtn = document.getElementById("timeline-scroll-right-btn");
  elements.mobileTimelineContainer = document.getElementById("mobile-timeline-container");

  elements.comparisonSelectorTabs = document.getElementById("comparison-selector-tabs");
  elements.compCategoryBadge = document.getElementById("comp-category-badge");
  elements.compTitle = document.getElementById("comp-title");
  elements.compViewArticleBtn = document.getElementById("comp-view-article-btn");
  elements.comparisonTableBody = document.getElementById("comparison-table-body");

  elements.articleModal = document.getElementById("article-modal");
  elements.modalBackdrop = document.getElementById("modal-backdrop");
  elements.modalCard = document.getElementById("modal-card");
  elements.modalCloseBtn = document.getElementById("modal-close-btn");
  elements.modalFooterCloseBtn = document.getElementById("modal-footer-close-btn");
  elements.modalScrollableBody = document.getElementById("modal-scrollable-body");
}

function initApp() {
  refreshElements();

  // Detect realm from body attribute, pathname, or URL query params
  const bodyRealm = document.body ? document.body.dataset.realm : null;
  const path = (window.location && window.location.pathname ? window.location.pathname : "").toLowerCase();
  const searchParams = new URLSearchParams(window.location.search);
  const queryRealm = searchParams.get("realm");

  if (bodyRealm === "fauna" || path.includes("animals") || queryRealm === "fauna") {
    state.activeRealm = "fauna";
    state.activeComparisonId = "tyrannosaurus-rex";
  } else if (bodyRealm === "human" || path.includes("human") || queryRealm === "human") {
    state.activeRealm = "human";
    state.activeComparisonId = "automobile";
  }

  updateRealmView();
  setupEventListeners();

  if (elements.statInventionsCount) {
    elements.statInventionsCount.textContent = INVENTIONS_DATA.length.toString() + "+";
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initApp);
} else {
  initApp();
}

/**
 * Switch Realm (Human C&E vs Fauna/Dinosaurs/Aves C&E)
 */
function switchRealm(newRealm) {
  state.activeRealm = newRealm;
  state.currentCategory = "All";
  state.currentPage = 1;
  
  // Update default comparison item
  state.activeComparisonId = newRealm === "human" ? "automobile" : "tyrannosaurus-rex";

  updateRealmView();
}

window.switchRealm = switchRealm;
window.switchRealmMode = switchRealm;
window.filterByCategory = (cat) => filterByCategory(cat);
window.openArticleModal = (id) => openArticleModal(id);
window.closeArticleModal = () => closeArticleModal();

/**
 * Update UI text, headers, and tabs based on active realm
 */
function updateRealmView() {
  const isHuman = state.activeRealm === "human";

  // Update Navbar Realm Switcher Buttons
  if (elements.navRealmHumanBtn && elements.navRealmFaunaBtn) {
    if (isHuman) {
      elements.navRealmHumanBtn.className = "px-3.5 py-2 rounded-xl text-xs font-bold bg-slate-900 text-white shadow-xs transition-all flex items-center gap-2";
      elements.navRealmFaunaBtn.className = "px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 transition-all flex items-center gap-2";
    } else {
      elements.navRealmHumanBtn.className = "px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 transition-all flex items-center gap-2";
      elements.navRealmFaunaBtn.className = "px-3.5 py-2 rounded-xl text-xs font-bold bg-emerald-800 text-white shadow-xs transition-all flex items-center gap-2";
    }
  }

  // Update Hero Realm Selector Cards
  if (elements.heroRealmHumanBtn && elements.heroRealmFaunaBtn) {
    const humanPill = document.getElementById("hero-human-status-pill");
    const faunaPill = document.getElementById("hero-fauna-status-pill");

    if (isHuman) {
      elements.heroRealmHumanBtn.className = "w-full text-left p-4 rounded-2xl border-2 transition-all duration-300 bg-slate-900/90 border-sky-500 shadow-lg shadow-sky-950/40 hover:scale-[1.02] focus:outline-none cursor-pointer";
      elements.heroRealmFaunaBtn.className = "w-full text-left p-4 rounded-2xl border transition-all duration-300 bg-slate-900/50 border-slate-800 hover:border-emerald-500/60 hover:bg-slate-900/80 hover:scale-[1.02] focus:outline-none cursor-pointer";
      if (humanPill) {
        humanPill.className = "px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-sky-500 text-slate-950";
        humanPill.textContent = "Active";
      }
      if (faunaPill) {
        faunaPill.className = "px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-slate-800 text-slate-400 border border-slate-700";
        faunaPill.textContent = "Switch";
      }
    } else {
      elements.heroRealmHumanBtn.className = "w-full text-left p-4 rounded-2xl border transition-all duration-300 bg-slate-900/50 border-slate-800 hover:border-sky-500/60 hover:bg-slate-900/80 hover:scale-[1.02] focus:outline-none cursor-pointer";
      elements.heroRealmFaunaBtn.className = "w-full text-left p-4 rounded-2xl border-2 transition-all duration-300 bg-slate-900/90 border-emerald-500 shadow-lg shadow-emerald-950/40 hover:scale-[1.02] focus:outline-none cursor-pointer";
      if (humanPill) {
        humanPill.className = "px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-slate-800 text-slate-400 border border-slate-700";
        humanPill.textContent = "Switch";
      }
      if (faunaPill) {
        faunaPill.className = "px-2 py-0.5 rounded-full text-[9px] font-extrabold uppercase tracking-wider bg-emerald-500 text-slate-950";
        faunaPill.textContent = "Active";
      }
    }
  }

  // Update Hero Content
  if (elements.heroBadgeText) {
    elements.heroBadgeText.textContent = isHuman 
      ? "Human Civilization, Inventions & Siddhars (204 Dossiers)" 
      : "Animals, Dinosaurs, Birds & Ancient Dragon Archetypes (202 Dossiers)";
  }

  if (elements.heroMainTitle) {
    elements.heroMainTitle.textContent = isHuman 
      ? "Creation & Evolution: Human Ingenuity & Ancient Wisdom" 
      : "Creation & Evolution: Fauna, Dinosaurs & Avian Flight";
  }

  if (elements.heroMainSubtitle) {
    elements.heroMainSubtitle.textContent = isHuman
      ? "From ancient Siddhars, sacred alchemy, and irrigation to microchips, steam locomotives, and quantum artificial intelligence."
      : "Explore 200+ prehistoric giants, dinosaurs, mythic dragon archosaurs, bird flight biomechanics, and extreme predator adaptations.";
  }

  if (elements.gridHeadingText) {
    elements.gridHeadingText.textContent = isHuman 
      ? "Human Inventions & Civilizational Dossiers" 
      : "Fauna, Dinosaurs & Evolutionary Dossiers";
  }

  if (elements.gridSubheadingText) {
    elements.gridSubheadingText.textContent = isHuman
      ? "Click 'Read' on any invention to inspect its complete 12-point historical dossier and Then vs. Now metrics."
      : "Explore detailed paleontology, anatomical adaptations, flight mechanics, and biological marvels.";
  }

  renderCategoryFilterPills();
  renderInventionsGrid();
  renderTimeline();
  renderComparisonTabs();
  renderComparisonTable(state.activeComparisonId);
}

// --------------------------------------------------------------------------
// 6. RENDERING FUNCTIONS
// --------------------------------------------------------------------------

/**
 * Render category filter buttons for the active realm
 */
function renderCategoryFilterPills() {
  if (!elements.categoryFiltersContainer) return;
  elements.categoryFiltersContainer.innerHTML = "";

  // Get active realm categories
  const activeDomains = CATEGORIES_CONFIG.filter(c => c.name === "All" || c.realm === state.activeRealm);

  // Add "All" option
  const allObj = {
    name: "All",
    label: state.activeRealm === "human" ? "All Inventions (204+)" : "All Species (202+)",
    icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>\`
  };

  const domainList = [allObj, ...activeDomains.filter(c => c.name !== "All")];

  domainList.forEach((catObj) => {
    const isSelected = state.currentCategory.toLowerCase() === catObj.name.toLowerCase();
    
    const count = catObj.name === "All" 
      ? INVENTIONS_DATA.filter(i => i.realm === state.activeRealm).length 
      : INVENTIONS_DATA.filter(i => i.category.toLowerCase() === catObj.name.toLowerCase() && i.realm === state.activeRealm).length;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = \`category-tab-btn inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap border transition-all focus:outline-none focus:ring-2 focus:ring-brand-600 \${
      isSelected
        ? "active border-slate-900 shadow-xs"
        : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50 hover:border-slate-300"
    }\`;
    
    btn.innerHTML = \`
      <span class="tab-icon-wrapper p-1 rounded-lg \${isSelected ? 'text-sky-300 bg-slate-800' : 'text-slate-500 bg-slate-100'}">
        \${catObj.icon}
      </span>
      <span class="font-display">\${catObj.label}</span>
      <span class="tab-count-badge text-[10px] px-1.5 py-0.5 rounded-full font-mono \${isSelected ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200'}">
        \${count}
      </span>
    \`;
    
    btn.addEventListener("click", () => {
      filterByCategory(catObj.name);
    });
    elements.categoryFiltersContainer.appendChild(btn);
  });
}

/**
 * Filter dataset based on active realm, active category, and live search query
 */
function getFilteredInventions() {
  const query = state.searchQuery.trim().toLowerCase();

  const filtered = INVENTIONS_DATA.filter((item) => {
    // Match Realm
    const matchesRealm = item.realm === state.activeRealm;

    // Match Category
    const matchesCat =
      state.currentCategory === "All" ||
      item.category.toLowerCase() === state.currentCategory.toLowerCase();

    if (!query) return matchesRealm && matchesCat;

    const matchesQuery =
      (item.commonName && item.commonName.toLowerCase().includes(query)) ||
      (item.title && item.title.toLowerCase().includes(query)) ||
      (item.category && item.category.toLowerCase().includes(query)) ||
      (item.id && item.id.toLowerCase().includes(query)) ||
      (item.period && item.period.toLowerCase().includes(query)) ||
      (item.subtitle && item.subtitle.toLowerCase().includes(query)) ||
      (item.summary && item.summary.toLowerCase().includes(query)) ||
      (item.who && item.who.toLowerCase().includes(query)) ||
      (item.where && item.where.toLowerCase().includes(query)) ||
      (item.whatIsIt && item.whatIsIt.toLowerCase().includes(query));

    return matchesRealm && matchesCat && matchesQuery;
  });

  if (query) {
    // Prioritize items whose commonName or title starts with query
    filtered.sort((a, b) => {
      const aStarts = (a.commonName && a.commonName.toLowerCase().startsWith(query)) || (a.title && a.title.toLowerCase().startsWith(query));
      const bStarts = (b.commonName && b.commonName.toLowerCase().startsWith(query)) || (b.title && b.title.toLowerCase().startsWith(query));
      if (aStarts && !bStarts) return -1;
      if (!aStarts && bStarts) return 1;
      return 0;
    });
  }

  return filtered;
}

/**
 * Render invention cards in grid
 */
function renderInventionsGrid() {
  if (!elements.inventionsGrid) return;
  const filtered = getFilteredInventions();

  if (filtered.length === 0) {
    elements.inventionsGrid.innerHTML = "";
    elements.noResultsState.classList.remove("hidden");
    elements.resultsCountText.textContent = "0 items found";
    elements.resetAllFiltersBtn.classList.remove("hidden");
    if (elements.loadMoreContainer) elements.loadMoreContainer.classList.add("hidden");
    return;
  }

  elements.noResultsState.classList.add("hidden");
  
  const displayedItems = filtered.slice(0, state.currentPage * state.cardsPerPage);
  
  elements.resultsCountText.textContent = \`Showing \${displayedItems.length} of \${filtered.length} dossiers in \${state.currentCategory} category\`;

  if (state.currentCategory !== "All" || state.searchQuery.trim() !== "") {
    elements.resetAllFiltersBtn.classList.remove("hidden");
  } else {
    elements.resetAllFiltersBtn.classList.add("hidden");
  }

  if (elements.loadMoreContainer && elements.loadMoreBtn) {
    if (displayedItems.length < filtered.length) {
      elements.loadMoreContainer.classList.remove("hidden");
      elements.loadMoreBtn.textContent = \`Load More Dossiers (\${filtered.length - displayedItems.length} remaining)\`;
    } else {
      elements.loadMoreContainer.classList.add("hidden");
    }
  }

  // Rich Domain Styling Mapping
  const DOMAIN_STYLES = {
    Transportation: {
      gradient: "from-blue-500 via-indigo-500 to-blue-600",
      bubbleBg: "bg-blue-50 text-blue-600 border-blue-200",
      badge: "bg-blue-50 text-blue-700 border-blue-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>\`
    },
    Communication: {
      gradient: "from-emerald-500 via-teal-500 to-emerald-600",
      bubbleBg: "bg-emerald-50 text-emerald-600 border-emerald-200",
      badge: "bg-emerald-50 text-emerald-700 border-emerald-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"></path></svg>\`
    },
    Computing: {
      gradient: "from-indigo-500 via-purple-500 to-indigo-600",
      bubbleBg: "bg-indigo-50 text-indigo-600 border-indigo-200",
      badge: "bg-indigo-50 text-indigo-700 border-indigo-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path></svg>\`
    },
    Home: {
      gradient: "from-amber-500 via-orange-500 to-amber-600",
      bubbleBg: "bg-amber-50 text-amber-600 border-amber-200",
      badge: "bg-amber-50 text-amber-800 border-amber-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>\`
    },
    Media: {
      gradient: "from-fuchsia-500 via-pink-500 to-purple-600",
      bubbleBg: "bg-fuchsia-50 text-fuchsia-600 border-fuchsia-200",
      badge: "bg-purple-50 text-purple-700 border-purple-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>\`
    },
    Medicine: {
      gradient: "from-rose-500 via-red-500 to-rose-600",
      bubbleBg: "bg-rose-50 text-rose-600 border-rose-200",
      badge: "bg-rose-50 text-rose-700 border-rose-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>\`
    },
    Energy: {
      gradient: "from-yellow-400 via-amber-500 to-orange-500",
      bubbleBg: "bg-yellow-50 text-amber-700 border-yellow-200",
      badge: "bg-yellow-50 text-yellow-800 border-yellow-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>\`
    },
    Agriculture: {
      gradient: "from-emerald-600 via-green-500 to-teal-600",
      bubbleBg: "bg-green-50 text-emerald-700 border-green-200",
      badge: "bg-green-50 text-green-800 border-green-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>\`
    },
    Materials: {
      gradient: "from-cyan-500 via-sky-500 to-blue-600",
      bubbleBg: "bg-cyan-50 text-cyan-700 border-cyan-200",
      badge: "bg-cyan-50 text-cyan-800 border-cyan-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>\`
    },
    AncientWisdom: {
      gradient: "from-amber-600 via-yellow-500 to-orange-600",
      bubbleBg: "bg-amber-50 text-amber-800 border-amber-300",
      badge: "bg-amber-100 text-amber-900 border-amber-300",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>\`
    },
    Space: {
      gradient: "from-slate-900 via-indigo-900 to-sky-500",
      bubbleBg: "bg-slate-900 text-sky-300 border-slate-700",
      badge: "bg-slate-900 text-sky-200 border-slate-700",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path></svg>\`
    },
    Dinosaurs: {
      gradient: "from-red-600 via-orange-500 to-amber-600",
      bubbleBg: "bg-red-50 text-red-700 border-red-200",
      badge: "bg-red-50 text-red-800 border-red-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5"></path></svg>\`
    },
    AvianEvolution: {
      gradient: "from-sky-400 via-cyan-500 to-blue-600",
      bubbleBg: "bg-sky-50 text-sky-700 border-sky-200",
      badge: "bg-sky-50 text-sky-800 border-sky-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>\`
    },
    PrehistoricMegafauna: {
      gradient: "from-stone-600 via-amber-700 to-stone-800",
      bubbleBg: "bg-stone-100 text-stone-700 border-stone-300",
      badge: "bg-stone-100 text-stone-800 border-stone-300",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"></path></svg>\`
    },
    OceanLeviathans: {
      gradient: "from-cyan-600 via-teal-600 to-blue-800",
      bubbleBg: "bg-teal-50 text-teal-700 border-teal-200",
      badge: "bg-teal-50 text-teal-800 border-teal-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>\`
    },
    MythicalBiology: {
      gradient: "from-purple-700 via-fuchsia-600 to-indigo-800",
      bubbleBg: "bg-purple-50 text-purple-700 border-purple-200",
      badge: "bg-purple-900 text-purple-200 border-purple-700",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>\`
    },
    HominidEvolution: {
      gradient: "from-amber-700 via-orange-600 to-stone-700",
      bubbleBg: "bg-amber-50 text-amber-800 border-amber-200",
      badge: "bg-amber-100 text-amber-900 border-amber-300",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>\`
    },
    InsectsAndSwarm: {
      gradient: "from-lime-500 via-emerald-500 to-green-600",
      bubbleBg: "bg-lime-50 text-lime-700 border-lime-200",
      badge: "bg-lime-50 text-lime-800 border-lime-200",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>\`
    },
    MammalianPredators: {
      gradient: "from-yellow-500 via-amber-600 to-red-600",
      bubbleBg: "bg-yellow-50 text-amber-800 border-yellow-200",
      badge: "bg-yellow-100 text-yellow-900 border-yellow-300",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>\`
    },
    SensoryAdaptations: {
      gradient: "from-indigo-600 via-cyan-500 to-teal-500",
      bubbleBg: "bg-indigo-50 text-indigo-700 border-indigo-200",
      badge: "bg-indigo-900 text-indigo-200 border-indigo-700",
      icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>\`
    }
  };

  // Master Unique Vector Logo Engine for 400+ Individual Topics
  function getDossierVectorIcon(item) {
    const id = item.id;
    const cat = item.category;

    // Direct unique iconic vector geometries
    if (id === "wheel") return \`<svg class="w-5 h-5 text-amber-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle><circle cx="12" cy="12" r="2.5"></circle><path d="M12 3v6.5m0 5V21m-9-9h6.5m5 0H21m-15.36 6.36l4.6-4.6m5.52-5.52l4.6-4.6m-14.72 0l4.6 4.6m5.52 5.52l4.6 4.6"></path></svg>\`;
    if (id === "chariot") return \`<svg class="w-5 h-5 text-orange-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="7" cy="17" r="4"></circle><path d="M11 17h6l4-7h-8L11 17zm0 0L7 9H3"></path></svg>\`;
    if (id === "sailing-ship") return \`<svg class="w-5 h-5 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 20a16 16 0 0020 0M4 17l8-14 8 14H4zm8-14v14"></path></svg>\`;
    if (id === "magnetic-compass") return \`<svg class="w-5 h-5 text-teal-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle><polygon points="12 4 15 12 12 20 9 12 12 4" fill="currentColor" fill-opacity="0.2"></polygon></svg>\`;
    if (id === "horseshoe-stirrup") return \`<svg class="w-5 h-5 text-stone-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 4a5 5 0 0110 0v8a5 5 0 01-10 0V4z"></path><circle cx="7" cy="4" r="1.5"></circle><circle cx="17" cy="4" r="1.5"></circle></svg>\`;
    if (id === "stagecoach") return \`<svg class="w-5 h-5 text-amber-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="6" width="16" height="10" rx="2"></rect><circle cx="7" cy="18" r="3"></circle><circle cx="17" cy="18" r="3"></circle><path d="M12 6v10M4 11h16"></path></svg>\`;
    if (id === "hot-air-balloon") return \`<svg class="w-5 h-5 text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3a7 7 0 00-5 11.5L9 18h6l2-3.5A7 7 0 0012 3z"></path><rect x="10" y="20" width="4" height="2"></rect></svg>\`;
    if (id === "steamboat") return \`<svg class="w-5 h-5 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 18l3-6h12l3 6H3zM9 12V6h2v6M13 12V4h2v8"></path><circle cx="12" cy="18" r="2.5"></circle></svg>\`;
    if (id === "steam-locomotive") return \`<svg class="w-5 h-5 text-slate-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="6" width="12" height="10" rx="1"></rect><rect x="15" y="4" width="6" height="12" rx="1"></rect><circle cx="7" cy="18" r="2.5"></circle><circle cx="13" cy="18" r="2.5"></circle><circle cx="18" cy="18" r="2"></circle><path d="M6 6V3h2v3"></path></svg>\`;
    if (id === "bicycle") return \`<svg class="w-5 h-5 text-sky-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="5.5" cy="16.5" r="3.5"></circle><circle cx="18.5" cy="16.5" r="3.5"></circle><path d="M12 16.5l-3-6 4-3h4M12 16.5h6.5M12 7.5a1 1 0 100-2 1 1 0 000 2z"></path></svg>\`;
    if (id === "ocean-liner") return \`<svg class="w-5 h-5 text-blue-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 17l4-5h14l2 5H2zm5-5V7h3v5m3-5h3v5"></path><path d="M2 20c4-1 8-1 12 0s8 1 8 0"></path></svg>\`;
    if (id === "pneumatic-tire") return \`<svg class="w-5 h-5 text-stone-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle><circle cx="12" cy="12" r="5"></circle><circle cx="12" cy="12" r="2"></circle></svg>\`;
    if (id === "cable-car") return \`<svg class="w-5 h-5 text-cyan-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 5l20 4M12 7v5"></path><rect x="6" y="12" width="12" height="8" rx="2"></rect><path d="M10 14v4M14 14v4"></path></svg>\`;
    if (id === "electric-tram") return \`<svg class="w-5 h-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="6" width="16" height="13" rx="2"></rect><path d="M12 3v3M9 3l6 0M4 11h16M8 19v2M16 19v2"></path></svg>\`;
    if (id === "motorcycle") return \`<svg class="w-5 h-5 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="5" cy="16" r="3"></circle><circle cx="19" cy="16" r="3"></circle><path d="M16 8l-4 4-3-1M16 8h2m-2 0l-3 8M5 16l4-7 4 1"></path></svg>\`;
    if (id === "automobile") return \`<svg class="w-5 h-5 text-rose-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 16h14m-12 0a2 2 0 104 0 2 2 0 00-4 0zm10 0a2 2 0 104 0 2 2 0 00-4 0zM3 11l2-5h14l2 5v5H3v-5z"></path></svg>\`;
    if (id === "diesel-engine") return \`<svg class="w-5 h-5 text-amber-800" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="6" width="16" height="12" rx="2"></rect><path d="M8 2v4M16 2v4M12 10v4M2 11h2M20 11h2"></path></svg>\`;
    if (id === "submarine") return \`<svg class="w-5 h-5 text-teal-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 14c0-3 4-5 10-5s8 2 8 5-2 5-8 5-10-2-10-5zM12 9V5h3v4M2 14h1"></path></svg>\`;
    if (id === "airship-zeppelin") return \`<svg class="w-5 h-5 text-indigo-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="11" rx="10" ry="5"></ellipse><rect x="9" y="16" width="6" height="2" rx="0.5"></rect><path d="M2 11l3-2M2 11l3 2"></path></svg>\`;
    if (id === "airplane") return \`<svg class="w-5 h-5 text-blue-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 6c-4 1-8 4-10 8-2-4-6-7-10-8 3 4 5 9 5 14 3-2 6-3 10-3 3 0 5 2 5-11z"></path></svg>\`;
    if (id === "jet-engine") return \`<svg class="w-5 h-5 text-purple-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="12" cy="12" rx="5" ry="8"></ellipse><circle cx="12" cy="12" r="2.5"></circle><path d="M2 12h5M17 12h5"></path></svg>\`;

    // Communication Unique Vectors
    if (id.includes("radio") || id.includes("fm-") || id.includes("am-") || id.includes("broadcast")) {
      return \`<svg class="w-5 h-5 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"></rect><path d="M16 3l-6 4M15 11h3m-3 3h3"></path><circle cx="8" cy="14" r="3"></circle></svg>\`;
    }
    if (id.includes("phone") || id.includes("telephone") || id.includes("mobile") || id.includes("switchboard")) {
      return \`<svg class="w-5 h-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="2" width="12" height="20" rx="2.5"></rect><path d="M12 18h.01M9 6h6"></path></svg>\`;
    }
    if (id.includes("printing") || id.includes("press") || id.includes("paper") || id.includes("papyrus") || id.includes("typewriter")) {
      return \`<svg class="w-5 h-5 text-amber-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V3h12v6M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"></path><rect x="6" y="14" width="12" height="7" rx="1"></rect></svg>\`;
    }
    if (id.includes("telegraph") || id.includes("cable") || id.includes("fiber") || id.includes("semaphore")) {
      return \`<svg class="w-5 h-5 text-cyan-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 15l4-8 4 8 4-8 4 8M4 19h16"></path><circle cx="4" cy="15" r="1.5"></circle><circle cx="20" cy="15" r="1.5"></circle></svg>\`;
    }

    // Computing & AI
    if (id.includes("computer") || id.includes("eniac") || id.includes("colossus") || id.includes("turing") || id.includes("gui") || id.includes("pascaline")) {
      return \`<svg class="w-5 h-5 text-violet-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="12" rx="2"></rect><path d="M8 21h8m-4-6v6"></path></svg>\`;
    }
    if (id.includes("transistor") || id.includes("microchip") || id.includes("integrated") || id.includes("microprocessor") || id.includes("hard-disk")) {
      return \`<svg class="w-5 h-5 text-fuchsia-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12" rx="1.5"></rect><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"></path></svg>\`;
    }
    if (id.includes("neural") || id.includes("ai") || id.includes("algorithm") || id.includes("logic")) {
      return \`<svg class="w-5 h-5 text-purple-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="2.5"></circle><circle cx="18" cy="6" r="2.5"></circle><circle cx="6" cy="18" r="2.5"></circle><circle cx="18" cy="18" r="2.5"></circle><circle cx="12" cy="12" r="3"></circle><path d="M8 7.5l2.5 3M16 7.5l-2.5 3M8 16.5l2.5-3M16 16.5l-2.5-3"></path></svg>\`;
    }

    // Media & Sound
    if (id.includes("microphone") || id.includes("mic")) {
      return \`<svg class="w-5 h-5 text-pink-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="2" width="6" height="11" rx="3"></rect><path d="M5 10a7 7 0 0014 0M12 17v4m-3 0h6"></path></svg>\`;
    }
    if (id.includes("loudspeaker") || id.includes("speaker") || id.includes("sound") || id.includes("phonograph") || id.includes("gramophone") || id.includes("vinyl") || id.includes("cassette") || id.includes("disc")) {
      return \`<svg class="w-5 h-5 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 010 7.07M19.07 4.93a10 10 0 010 14.14"></path></svg>\`;
    }
    if (id.includes("television") || id.includes("tv") || id.includes("display") || id.includes("crt") || id.includes("vr")) {
      return \`<svg class="w-5 h-5 text-rose-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2"></rect><path d="M17 3l-5 4-5-4"></path></svg>\`;
    }
    if (id.includes("camera") || id.includes("film") || id.includes("daguerreotype") || id.includes("polaroid")) {
      return \`<svg class="w-5 h-5 text-amber-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 19a2 2 0 01-2 2H3a2 2 0 01-2-2V8a2 2 0 012-2h4l2-3h6l2 3h4a2 2 0 012 2z"></path><circle cx="12" cy="13" r="3.5"></circle></svg>\`;
    }

    // Home & Living
    if (id.includes("refrigerator") || id.includes("air-conditioner")) {
      return \`<svg class="w-5 h-5 text-cyan-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"></rect><path d="M4 10h16M8 6v2m0 6v3"></path></svg>\`;
    }
    if (id.includes("light-bulb") || id.includes("led")) {
      return \`<svg class="w-5 h-5 text-yellow-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18h6m-4 3h2m-7-10a6 6 0 1112 0c0 2.5-1.5 4.5-3 5.5v1.5H10V16.5C8.5 15.5 7 13.5 7 11z"></path></svg>\`;
    }
    if (id.includes("clock") || id.includes("watch")) {
      return \`<svg class="w-5 h-5 text-amber-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 3"></path></svg>\`;
    }

    // Space & Astronomy
    if (id.includes("rocket") || id.includes("satellite") || id.includes("vostok") || id.includes("apollo") || id.includes("starship") || id.includes("iss")) {
      return \`<svg class="w-5 h-5 text-indigo-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2c-3.5 3.5-4.5 8-4.5 12l2.5 1.5 2-2.5 2 2.5 2.5-1.5c0-4-1-8.5-4.5-12zM9 19l3-2 3 2"></path></svg>\`;
    }
    if (id.includes("telescope") || id.includes("jwst") || id.includes("hubble")) {
      return \`<svg class="w-5 h-5 text-sky-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 3l-9 9m9-9l-3 1m3-1l-1 3M10 12l-6 6m6-6l2 2m-8 4l-2 2m2-2v4m0-4h-4"></path></svg>\`;
    }

    // Medicine
    if (id.includes("stethoscope") || id.includes("ecg") || id.includes("pacemaker") || id.includes("defibrillator")) {
      return \`<svg class="w-5 h-5 text-rose-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>\`;
    }
    if (id.includes("dna") || id.includes("crispr") || id.includes("gene") || id.includes("sequencing")) {
      return \`<svg class="w-5 h-5 text-emerald-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6c4 4 12 4 16 0M4 18c4-4 12-4 16 0M9 8v8M15 8v8M12 3v18"></path></svg>\`;
    }
    if (id.includes("vaccine") || id.includes("syringe") || id.includes("penicillin") || id.includes("anesthesia")) {
      return \`<svg class="w-5 h-5 text-teal-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 2l4 4-3 3-4-4 3-3zM15 5L6 14v4h4l9-9-4-4zM4 20l-2 2"></path></svg>\`;
    }

    // Ancient Wisdom & Siddhars
    if (id.includes("siddha") || id.includes("alchemy") || id.includes("kayakalpa") || id.includes("kundalini") || id.includes("yoga") || id.includes("ayurvedic") || id.includes("panchaloha") || id.includes("marma") || id.includes("gopuram")) {
      return \`<svg class="w-5 h-5 text-amber-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2c-2 3-5 5-5 9a5 5 0 0010 0c0-4-3-6-5-9zM12 11c-1 1-1.5 2-1.5 3a1.5 1.5 0 003 0c0-1-.5-2-1.5-3z"></path></svg>\`;
    }

    // Dinosaurs & Archosaurs
    if (id.includes("tyrannosaurus") || id.includes("spinosaurus") || id.includes("allosaurus") || id.includes("carnotaurus") || id.includes("giganotosaurus") || id.includes("dinosaur") || id.includes("raptor") || id.includes("triceratops") || id.includes("brachiosaurus") || id.includes("stegosaurus") || id.includes("ankylosaurus")) {
      return \`<svg class="w-5 h-5 text-red-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 4c3 0 7 2 7 6 0 3-2 5-5 5h-2l-2 5h-3l1-6H7a4 4 0 01-4-4c0-3 3-6 7-6h4z"></path><circle cx="16" cy="8" r="1" fill="currentColor"></circle></svg>\`;
    }

    // Birds & Avian
    if (id.includes("falcon") || id.includes("eagle") || id.includes("bird") || id.includes("owl") || id.includes("hummingbird") || id.includes("archaeopteryx") || id.includes("albatross") || id.includes("penguin") || id.includes("parrot") || id.includes("flamingo")) {
      return \`<svg class="w-5 h-5 text-sky-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 6c-4 1-8 4-10 8-2-4-6-7-10-8 3 4 5 9 5 14 3-2 6-3 10-3 3 0 5 2 5-11z"></path></svg>\`;
    }

    // Megafauna & Mammals
    if (id.includes("mammoth") || id.includes("smilodon") || id.includes("saber") || id.includes("megatherium") || id.includes("paraceratherium") || id.includes("rhino") || id.includes("elk") || id.includes("glyptodon") || id.includes("wolf") || id.includes("bear") || id.includes("lion") || id.includes("tiger") || id.includes("cheetah") || id.includes("leopard")) {
      return \`<svg class="w-5 h-5 text-stone-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 18c0-4 3-8 7-8s7 4 7 8m-14 0h14M8 10C8 6 11 3 15 3s7 3 7 7"></path></svg>\`;
    }

    // Marine
    if (id.includes("megalodon") || id.includes("shark") || id.includes("whale") || id.includes("squid") || id.includes("leviathan") || id.includes("manta") || id.includes("octopus") || id.includes("eel") || id.includes("nautilus")) {
      return \`<svg class="w-5 h-5 text-teal-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12c3-2 6-2 9 0s6 2 9 0 3-1 3-1-1 3-3 4-6 0-9-2-6-2-9 0v-1z"></path><path d="M12 4v4l3 2"></path></svg>\`;
    }

    // Mythical & Dragons
    if (id.includes("dragon") || id.includes("hydra") || id.includes("phoenix") || id.includes("basilisk") || id.includes("griffin") || id.includes("chimera") || id.includes("kraken") || id.includes("cerberus")) {
      return \`<svg class="w-5 h-5 text-purple-700" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"></path></svg>\`;
    }

    // Deterministic procedural unique vector for every item based on its ID
    let hash = 0;
    for (let i = 0; i < id.length; i++) {
      hash = (hash << 5) - hash + id.charCodeAt(i);
      hash |= 0;
    }
    const absHash = Math.abs(hash);
    const variant = absHash % 6;
    const colors = ["text-blue-600", "text-emerald-600", "text-amber-600", "text-purple-600", "text-rose-600", "text-cyan-600"];
    const color = colors[absHash % colors.length];

    if (variant === 0) {
      return \`<svg class="w-5 h-5 \${color}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>\`;
    } else if (variant === 1) {
      return \`<svg class="w-5 h-5 \${color}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"></circle><path d="M12 2a10 10 0 0110 10M12 22a10 10 0 01-10-10"></path><circle cx="12" cy="12" r="3"></circle></svg>\`;
    } else if (variant === 2) {
      return \`<svg class="w-5 h-5 \${color}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="4"></rect><path d="M3 9h18M9 21V9"></path></svg>\`;
    } else if (variant === 3) {
      return \`<svg class="w-5 h-5 \${color}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path></svg>\`;
    } else if (variant === 4) {
      return \`<svg class="w-5 h-5 \${color}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>\`;
    } else {
      return \`<svg class="w-5 h-5 \${color}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"></polygon></svg>\`;
    }
  }

  elements.inventionsGrid.innerHTML = displayedItems
    .map((item) => {
      const style = DOMAIN_STYLES[item.category] || {
        gradient: "from-slate-700 to-slate-900",
        bubbleBg: "bg-slate-100 text-slate-700 border-slate-200",
        badge: "bg-slate-100 text-slate-800 border-slate-200",
        icon: \`<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>\`
      };

      const vectorIcon = getDossierVectorIcon(item);

      return \`
      <article class="invention-card flex flex-col justify-between shadow-xs group bg-white border border-slate-200 rounded-xl overflow-hidden hover:shadow-lg hover:border-slate-300 transition-all duration-300">
        <!-- Sleek Compact Top Banner with Unique Mini Logo on Top-Left -->
        <div class="card-media-banner relative w-full bg-gradient-to-r \${style.gradient} overflow-hidden px-3.5 py-2.5 flex items-center justify-between shrink-0">
          <div class="absolute inset-0 opacity-15 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:8px_8px]"></div>
          
          <!-- Top-Left: Unique Mini Logo Box + Clean Name -->
          <div class="relative z-10 flex items-center gap-2.5 min-w-0 pr-2">
            <div class="w-8 h-8 rounded-lg bg-white/95 shadow-xs border border-white/80 p-1.5 flex items-center justify-center text-slate-900 group-hover:scale-110 transition-transform duration-300 shrink-0">
              \${vectorIcon}
            </div>
            <div class="min-w-0">
              <div class="text-white font-bold text-xs sm:text-sm font-display tracking-tight leading-tight drop-shadow-xs truncate max-w-[150px] sm:max-w-[180px]">
                \${item.commonName}
              </div>
            </div>
          </div>

          <!-- Top-Right: Clean Milestone Period Badge -->
          <div class="relative z-10 shrink-0 text-right">
            <span class="text-[10px] font-mono font-bold text-white bg-black/40 px-2 py-0.5 rounded-md border border-white/20 shadow-2xs">
              \${item.period}
            </span>
          </div>
        </div>

        <!-- Card Body Content (Compact, User-Friendly Proportions) -->
        <div class="p-3.5 sm:p-4 flex flex-col justify-between flex-grow">
          <div>
            <!-- Headline & Domain Badge -->
            <div class="flex items-center justify-between gap-1.5 mb-1.5">
              <span class="text-[10px] font-semibold text-brand-700 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-100/80 shrink-0 truncate max-w-[130px]">
                \${item.category}
              </span>
              <span class="text-[10px] text-slate-400 font-mono">12-Pt Dossier</span>
            </div>

            <!-- Primary Bold Name & Title -->
            <div class="mb-2">
              <h3 class="text-base sm:text-lg font-bold font-display text-slate-900 leading-snug group-hover:text-brand-700 transition-colors">
                \${item.commonName}
              </h3>
              <p class="text-[11px] font-medium text-slate-500 mt-0.5 line-clamp-1">
                \${item.title}
              </p>
            </div>

            <!-- Core Summary -->
            <p class="text-xs font-serif text-slate-600 leading-relaxed mb-3 line-clamp-2">
              \${item.summary}
            </p>

            <!-- Fast Facts Strip -->
            <div class="bg-slate-50 rounded-lg p-2 border border-slate-100 mb-2.5 space-y-1 text-[11px]">
              <div class="flex items-center gap-1.5 text-slate-700">
                <span class="text-[11px]">\${item.realm === 'human' ? '👤' : '🧬'}</span>
                <span class="text-slate-600 line-clamp-1 text-[10.5px]">
                  <strong class="text-slate-800">\${item.realm === 'human' ? 'Pioneers:' : 'Lineage:'}</strong> \${item.who.split('(')[0]}
                </span>
              </div>
              <div class="flex items-center gap-1.5 text-slate-700">
                <span class="text-[11px]">\${item.realm === 'human' ? '📍' : '🌍'}</span>
                <span class="text-slate-600 line-clamp-1 text-[10.5px]">
                  <strong class="text-slate-800">Habitat:</strong> \${item.where}
                </span>
              </div>
            </div>

            <!-- Shift Metric Pill -->
            <div class="p-1.5 rounded-md bg-brand-50/40 border border-brand-100/60 mb-2 flex items-center justify-between text-[10px] text-slate-600">
              <span class="font-semibold text-brand-800 uppercase tracking-wider text-[8.5px]">Shift:</span>
              <span class="font-serif italic text-slate-700 truncate max-w-[170px]">\${item.comparison.speed.now}</span>
            </div>
          </div>

          <!-- Bottom Action Row -->
          <div class="pt-2.5 border-t border-slate-100 flex items-center justify-between mt-1">
            <span class="text-[10px] text-slate-400">\${item.realm === 'human' ? 'Invention' : 'Evolution'}</span>
            <button
              type="button"
              data-action="read"
              data-id="\${item.id}"
              onclick="event.stopPropagation(); openArticleModal('\${item.id}');"
              class="inline-flex items-center gap-1 text-xs font-semibold text-white bg-slate-900 hover:bg-brand-600 px-3 py-1.5 rounded-lg transition-all shadow-2xs focus:outline-none focus:ring-2 focus:ring-brand-600 group cursor-pointer"
            >
              <span>Read</span>
              <svg class="w-3 h-3 group-hover:translate-x-0.5 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
              </svg>
            </button>
          </div>
        </div>
      </article>
      \`;
    })
    .join("");
}

/**
 * Render Timeline Nodes for Active Realm
 */
function renderTimeline() {
  if (!elements.desktopTimelineContainer || !elements.mobileTimelineContainer) return;

  const realmItems = INVENTIONS_DATA.filter(i => i.realm === state.activeRealm);

  const desktopNodesHTML = realmItems.map((item) => {
    return \`
      <div class="timeline-node flex flex-col items-center text-center cursor-pointer group px-3 min-w-[130px] max-w-[145px] shrink-0" data-id="\${item.id}" onclick="openArticleModal('\${item.id}')">
        <span class="text-xs font-mono font-bold text-slate-600 group-hover:text-brand-600 mb-2 transition-colors">
          \${item.period}
        </span>

        <div class="w-7 h-7 rounded-full bg-white border-2 border-slate-400 group-hover:border-brand-600 group-hover:bg-brand-600 flex items-center justify-center transition-all shadow-xs mb-3">
          <div class="w-2 h-2 rounded-full bg-slate-400 group-hover:bg-white transition-colors"></div>
        </div>

        <span class="text-xs font-bold text-slate-800 font-display group-hover:text-brand-700 leading-tight transition-colors line-clamp-1">
          \${item.commonName}
        </span>
        <span class="text-[10px] text-slate-500 mt-1 uppercase tracking-wide">
          \${item.category}
        </span>
      </div>
    \`;
  }).join("");

  elements.desktopTimelineTrack.innerHTML = desktopNodesHTML;

  const mobileNodesHTML = realmItems.map((item) => {
    return \`
      <div class="flex items-start gap-3 p-3 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white transition-all cursor-pointer" data-id="\${item.id}" onclick="openArticleModal('\${item.id}')">
        <span class="px-2 py-0.5 text-xs font-mono font-bold bg-white text-slate-700 rounded border border-slate-300 shrink-0">
          \${item.period}
        </span>
        <div>
          <h4 class="text-xs font-bold text-slate-900 font-display">\${item.commonName}</h4>
          <p class="text-[11px] text-slate-500 line-clamp-1 mt-0.5">\${item.title}</p>
        </div>
      </div>
    \`;
  }).join("");

  elements.mobileTimelineContainer.innerHTML = mobileNodesHTML;
}

/**
 * Render comparison tabs for active realm
 */
function renderComparisonTabs() {
  if (!elements.comparisonSelectorTabs) return;
  elements.comparisonSelectorTabs.innerHTML = "";

  const realmItems = INVENTIONS_DATA.filter(i => i.realm === state.activeRealm).slice(0, 15);

  realmItems.forEach((item) => {
    const isSelected = item.id === state.activeComparisonId;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = \`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all focus:outline-none \${
      isSelected
        ? "bg-slate-900 text-white shadow-xs"
        : "bg-white hover:bg-slate-100 text-slate-700 border border-slate-200"
    }\`;
    btn.textContent = \`\${item.commonName} (\${item.category})\`;
    btn.addEventListener("click", () => {
      state.activeComparisonId = item.id;
      renderComparisonTabs();
      renderComparisonTable(item.id);
    });
    elements.comparisonSelectorTabs.appendChild(btn);
  });
}

/**
 * Render comparison table for selected item
 */
function renderComparisonTable(inventionId) {
  const item = INVENTIONS_DATA.find((inv) => inv.id === inventionId) || INVENTIONS_DATA.find(i => i.realm === state.activeRealm);
  if (!item || !elements.comparisonTableBody) return;

  if (elements.compCategoryBadge) elements.compCategoryBadge.textContent = item.category;
  if (elements.compTitle) elements.compTitle.textContent = \`\${item.commonName} (\${item.title}) — Evolutionary Shift Matrix\`;
  if (elements.compViewArticleBtn) {
    elements.compViewArticleBtn.onclick = () => openArticleModal(item.id);
  }

  const comp = item.comparison;
  const rows = [
    { label: "Physical Footprint & Anatomy", then: comp.size.then, now: comp.size.now },
    { label: "Execution Speed & Biomechanics", then: comp.speed.then, now: comp.speed.now },
    { label: "Functional Scope & Specialization", then: comp.function.then, now: comp.function.now },
    { label: "Interconnectivity & Communication", then: comp.connectivity.then, now: comp.connectivity.now },
    { label: "Power & Metabolic Efficiency", then: comp.power.then, now: comp.power.now },
    { label: "Adaptive Resilience & Experience", then: comp.userExperience.then, now: comp.userExperience.now }
  ];

  elements.comparisonTableBody.innerHTML = rows
    .map(
      (r) => \`
      <tr class="hover:bg-slate-50/80 transition-colors">
        <td class="px-4 py-3.5 font-semibold text-slate-900 text-xs sm:text-sm">\${r.label}</td>
        <td class="px-4 py-3.5 font-serif text-slate-700 bg-amber-50/20 text-xs sm:text-sm">\${r.then}</td>
        <td class="px-4 py-3.5 font-serif text-slate-800 bg-brand-50/20 text-xs sm:text-sm font-medium">\${r.now}</td>
      </tr>
    \`
    )
    .join("");
}

// --------------------------------------------------------------------------
// 7. ARTICLE MODAL / DEEP-DIVE CONTROLLER (Fail-Safe & Instant Display)
// --------------------------------------------------------------------------

function openArticleModal(inventionId) {
  const item = INVENTIONS_DATA.find((inv) => inv.id === inventionId);
  if (!item) {
    console.warn("Dossier not found for ID:", inventionId);
    return;
  }

  state.activeModalId = inventionId;

  const modal = document.getElementById("article-modal");
  const backdrop = document.getElementById("modal-backdrop");
  const card = document.getElementById("modal-card");
  const scrollBody = document.getElementById("modal-scrollable-body");

  if (!modal) {
    console.error("Modal element #article-modal not found in DOM");
    return;
  }

  const setElText = (id, text) => {
    const el = document.getElementById(id);
    if (el) el.textContent = text || "";
  };

  const setElHtml = (id, html) => {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html || "";
  };

  setElText("modal-category-badge", item.category);
  setElText("modal-period-badge", \`Epoch / Milestone: \${item.period}\`);
  setElText("modal-title", \`\${item.commonName} — \${item.title}\`);
  setElText("modal-subtitle", item.subtitle);
  setElText("modal-meta-who", item.who);
  setElText("modal-meta-when", item.when);
  setElText("modal-meta-where", item.where);

  setElText("modal-sec-what", item.whatIsIt);
  setElText("modal-sec-why-created", item.whyCreated);
  setElText("modal-sec-problem-before", item.problemBefore);
  setElText("modal-sec-who", item.who);
  setElText("modal-sec-when-where", \`\${item.when} — Originating in \${item.where}.\`);
  setElText("modal-sec-older-usage", item.olderUsage);
  setElText("modal-sec-limitations", item.limitations);
  setElText("modal-sec-why-evolve", item.whyEvolved);

  const steps = Array.isArray(item.evolutionSteps) ? item.evolutionSteps : [];
  const stepsHtml = steps
    .map(
      (step) => \`
      <div class="flex items-start gap-3 p-3 rounded-lg bg-slate-50 border border-slate-200">
        <span class="px-2 py-0.5 text-xs font-mono font-bold bg-white text-brand-800 rounded border border-slate-300 shrink-0">
          \${step.era || "Era"}
        </span>
        <span class="text-sm text-slate-700 leading-relaxed font-serif">\${step.text || ""}</span>
      </div>
    \`
    )
    .join("");
  setElHtml("modal-sec-evolution-steps", stepsHtml);

  setElText("modal-sec-modern-version", item.modernVersion);
  setElText("modal-sec-modern-usage", item.modernUsage);
  setElText("modal-sec-future", item.futureOutlook);

  const comp = item.comparison || {};
  const compRows = [
    { dim: "Form & Scale", then: (comp.size && comp.size.then) || "Ancestral format", now: (comp.size && comp.size.now) || "Modern format" },
    { dim: "Speed / Biomechanics", then: (comp.speed && comp.speed.then) || "Early speed", now: (comp.speed && comp.speed.now) || "Modern speed" },
    { dim: "Functional Scope", then: (comp.function && comp.function.then) || "Single function", now: (comp.function && comp.function.now) || "Multifunctional" },
    { dim: "Communication / Senses", then: (comp.connectivity && comp.connectivity.then) || "Isolated", now: (comp.connectivity && comp.connectivity.now) || "Networked" },
    { dim: "Power / Metabolism", then: (comp.power && comp.power.then) || "Manual/Organic", now: (comp.power && comp.power.now) || "Optimized" },
    { dim: "Adaptation / UX", then: (comp.userExperience && comp.userExperience.then) || "Complex", now: (comp.userExperience && comp.userExperience.now) || "Seamless" }
  ];

  const tbody = document.getElementById("modal-comparison-tbody");
  if (tbody) {
    tbody.innerHTML = compRows
      .map(
        (r) => \`
        <tr>
          <td class="px-3 py-2 font-semibold text-slate-800 text-xs">\${r.dim}</td>
          <td class="px-3 py-2 text-slate-600 bg-amber-50/20 text-xs font-serif">\${r.then}</td>
          <td class="px-3 py-2 text-slate-900 bg-brand-50/20 text-xs font-serif font-medium">\${r.now}</td>
        </tr>
      \`
      )
      .join("");
  }

  // Force show modal immediately via both inline styles and classes
  modal.style.display = "block";
  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
  document.body.classList.add("modal-open");

  if (backdrop) {
    backdrop.style.opacity = "1";
    backdrop.classList.remove("opacity-0");
    backdrop.classList.add("opacity-100");
  }
  if (card) {
    card.style.opacity = "1";
    card.style.transform = "scale(1)";
    card.classList.remove("opacity-0", "scale-95");
    card.classList.add("opacity-100", "scale-100");
  }

  if (scrollBody) {
    scrollBody.scrollTop = 0;
  }
}

function closeArticleModal() {
  state.activeModalId = null;

  const modal = document.getElementById("article-modal");
  const backdrop = document.getElementById("modal-backdrop");
  const card = document.getElementById("modal-card");

  if (!modal) return;

  if (backdrop) {
    backdrop.style.opacity = "0";
    backdrop.classList.remove("opacity-100");
    backdrop.classList.add("opacity-0");
  }
  if (card) {
    card.style.opacity = "0";
    card.style.transform = "scale(0.95)";
    card.classList.remove("opacity-100", "scale-100");
    card.classList.add("opacity-0", "scale-95");
  }

  setTimeout(() => {
    modal.style.display = "none";
    modal.classList.add("hidden");
    document.body.style.overflow = "";
    document.body.classList.remove("modal-open");
  }, 150);
}

// Attach globally
window.openArticleModal = openArticleModal;
window.closeArticleModal = closeArticleModal;

// --------------------------------------------------------------------------
// 8. EVENT HANDLERS & INTERACTIONS
// --------------------------------------------------------------------------

window.filterByCategory = function (categoryName) {
  state.currentCategory = categoryName;
  state.currentPage = 1;
  renderCategoryFilterPills();
  renderInventionsGrid();

  const invSec = document.getElementById("inventions");
  if (invSec) {
    invSec.scrollIntoView({ behavior: "smooth" });
  }
};

window.switchRealmMode = function (realm) {
  switchRealm(realm);
};

function setupEventListeners() {
  // Global click event delegation for card clicks and Read buttons
  document.addEventListener("click", function (e) {
    // If inside modal, check for close buttons
    const closeBtn = e.target.closest("#modal-close-btn, #modal-footer-close-btn, [data-modal-close]");
    if (closeBtn) {
      e.preventDefault();
      closeArticleModal();
      return;
    }

    // If clicked directly on the modal backdrop
    if (e.target.id === "article-modal" || e.target.id === "modal-backdrop") {
      closeArticleModal();
      return;
    }

    // If clicked on Read button or card
    const readBtn = e.target.closest("button[data-action='read'], button[onclick*='openArticleModal'], .invention-card[data-id], .timeline-node[data-id]");
    if (readBtn && !e.target.closest("#article-modal")) {
      const id = readBtn.getAttribute("data-id") || readBtn.getAttribute("onclick")?.match(/openArticleModal\(['"]([^'"]+)['"]\)/)?.[1];
      if (id) {
        openArticleModal(id);
      }
    }
  });

  // Live Search Input
  const searchInput = document.getElementById("search-input");
  const searchClearBtn = document.getElementById("search-clear-btn");

  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      state.searchQuery = e.target.value;
      state.currentPage = 1;
      if (searchClearBtn) {
        if (state.searchQuery.trim() !== "") {
          searchClearBtn.classList.remove("hidden");
        } else {
          searchClearBtn.classList.add("hidden");
        }
      }
      renderInventionsGrid();
    });
  }

  // Clear Search
  if (searchClearBtn) {
    searchClearBtn.addEventListener("click", () => {
      state.searchQuery = "";
      state.currentPage = 1;
      if (searchInput) {
        searchInput.value = "";
        searchInput.focus();
      }
      searchClearBtn.classList.add("hidden");
      renderInventionsGrid();
    });
  }

  // Load More Button
  const loadMoreBtn = document.getElementById("load-more-btn");
  if (loadMoreBtn) {
    loadMoreBtn.addEventListener("click", () => {
      state.currentPage++;
      renderInventionsGrid();
    });
  }

  // Timeline Scroll Buttons
  const tScrollLeft = document.getElementById("timeline-scroll-left-btn");
  const tScrollRight = document.getElementById("timeline-scroll-right-btn");
  const tTrack = document.getElementById("desktop-timeline-track");

  if (tScrollLeft && tTrack) {
    tScrollLeft.addEventListener("click", () => {
      tTrack.scrollBy({ left: -450, behavior: "smooth" });
    });
  }

  if (tScrollRight && tTrack) {
    tScrollRight.addEventListener("click", () => {
      tTrack.scrollBy({ left: 450, behavior: "smooth" });
    });
  }

  // Reset Filters
  const resetFilters = () => {
    state.currentCategory = "All";
    state.searchQuery = "";
    state.currentPage = 1;
    const sInput = document.getElementById("search-input");
    const sClear = document.getElementById("search-clear-btn");
    if (sInput) sInput.value = "";
    if (sClear) sClear.classList.add("hidden");
    renderCategoryFilterPills();
    renderInventionsGrid();
  };

  const resetAllBtn = document.getElementById("reset-all-filters-btn");
  const noResultsResetBtn = document.getElementById("no-results-reset-btn");
  if (resetAllBtn) resetAllBtn.addEventListener("click", resetFilters);
  if (noResultsResetBtn) noResultsResetBtn.addEventListener("click", resetFilters);

  // Mobile Menu
  const mobileToggle = document.getElementById("mobile-menu-toggle");
  const mobileMenu = document.getElementById("mobile-menu");
  if (mobileToggle && mobileMenu) {
    mobileToggle.addEventListener("click", () => {
      mobileMenu.classList.toggle("hidden");
    });
  }

  // Keyboard Shortcuts
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && state.activeModalId) {
      closeArticleModal();
    }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      const sInput = document.getElementById("search-input");
      if (sInput) {
        sInput.focus();
        sInput.select();
      }
    }
  });

  const quickSearchBtn = document.getElementById("quick-search-btn");
  if (quickSearchBtn) {
    quickSearchBtn.addEventListener("click", () => {
      setTimeout(() => {
        const sInput = document.getElementById("search-input");
        if (sInput) {
          sInput.focus();
          sInput.select();
        }
      }, 100);
    });
  }
}
`;

fs.writeFileSync(path.join(__dirname, '..', 'script.js'), scriptCode, 'utf8');
console.log('Successfully written master script.js with 400+ dossiers and dual-realm switcher!');

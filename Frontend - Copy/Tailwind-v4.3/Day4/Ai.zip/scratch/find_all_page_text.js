const fs = require('fs');
const path = require('path');

const files = ['index.html', 'Human.html', 'Animals.html', 'scratch/build_master_dataset.js'];

files.forEach(file => {
  const filePath = path.join(__dirname, '..', file);
  if (!fs.existsSync(filePath)) return;
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  console.log(`\n=== All 'page' text in ${file} ===`);
  lines.forEach((line, idx) => {
    // Filter out pagination logic like 'state.currentPage' or 'totalPages'
    if (/>[^<]*page[^<]*</i.test(line) || /"[^"]*page[^"]*"/i.test(line)) {
      if (!line.includes('currentPage') && !line.includes('totalPages') && !line.includes('loadMore') && !line.includes('page-')) {
        console.log(`Line ${idx + 1}: ${line.trim()}`);
      }
    }
  });
});

const fs = require('fs');
const path = require('path');

const requiredIds = [
  "nav-realm-human-btn",
  "nav-realm-fauna-btn",
  "hero-realm-human-btn",
  "hero-realm-fauna-btn",
  "hero-badge-container",
  "hero-badge-text",
  "hero-main-title",
  "hero-main-subtitle",
  "hero-human-status-pill",
  "hero-fauna-status-pill",
  "quick-search-btn",
  "mobile-menu-toggle",
  "mobile-menu",
  "category-filters-container",
  "search-input",
  "search-clear-btn",
  "results-count-text",
  "reset-all-filters-btn",
  "inventions-grid",
  "no-results-state",
  "no-results-reset-btn",
  "load-more-container",
  "load-more-btn",
  "grid-heading-text",
  "grid-subheading-text",
  "desktop-timeline-container",
  "desktop-timeline-track",
  "timeline-scroll-left-btn",
  "timeline-scroll-right-btn",
  "mobile-timeline-container",
  "comparison-selector-tabs",
  "comp-category-badge",
  "comp-title",
  "comp-view-article-btn",
  "comparison-table-body",
  "article-modal",
  "modal-backdrop",
  "modal-card",
  "modal-close-btn",
  "modal-footer-close-btn",
  "modal-scrollable-body",
  "modal-category-badge",
  "modal-period-badge",
  "modal-title",
  "modal-subtitle",
  "modal-meta-who",
  "modal-meta-when",
  "modal-meta-where",
  "modal-sec-what",
  "modal-sec-why-created",
  "modal-sec-problem-before",
  "modal-sec-who",
  "modal-sec-when-where",
  "modal-sec-older-usage",
  "modal-sec-limitations",
  "modal-sec-why-evolve",
  "modal-sec-evolution-steps",
  "modal-sec-modern-version",
  "modal-sec-modern-usage",
  "modal-sec-future",
  "modal-comparison-tbody"
];

['index.html', 'Human.html', 'Animals.html'].forEach(file => {
  const content = fs.readFileSync(path.join(__dirname, '..', file), 'utf8');
  console.log(`\n=== Checking ${file} ===`);
  const missing = [];
  requiredIds.forEach(id => {
    if (!content.includes(`id="${id}"`)) {
      missing.push(id);
    }
  });
  if (missing.length === 0) {
    console.log(`✓ All ${requiredIds.length} required IDs present in ${file}!`);
  } else {
    console.log(`❌ Missing IDs in ${file}:`, missing);
  }
});

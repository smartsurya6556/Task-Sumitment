const fs = require('fs');
const path = require('path');
const { JSDOM } = require('jsdom');

['index.html', 'Human.html', 'Animals.html'].forEach(htmlFile => {
  console.log(`\n========================================`);
  console.log(`Testing full DOM & Modal execution in ${htmlFile}`);
  console.log(`========================================`);

  const html = fs.readFileSync(path.join(__dirname, '..', htmlFile), 'utf8');
  const scriptContent = fs.readFileSync(path.join(__dirname, '..', 'script.js'), 'utf8');

  // Create virtual DOM window
  const dom = new JSDOM(html, {
    runScripts: "dangerously",
    resources: "usable",
    url: `http://localhost/${htmlFile}`
  });

  const { window } = dom;
  const { document } = window;

  // Execute script.js inside JSDOM environment
  const scriptEl = document.createElement("script");
  scriptEl.textContent = scriptContent;
  document.body.appendChild(scriptEl);

  // Trigger DOMContentLoaded
  const domEvent = document.createEvent("Event");
  domEvent.initEvent("DOMContentLoaded", true, true);
  document.dispatchEvent(domEvent);

  // 1. Test Card rendering
  const grid = document.getElementById("inventions-grid");
  if (!grid) throw new Error("inventions-grid not found");
  const cardArticles = grid.querySelectorAll(".invention-card");
  console.log(`✓ Rendered ${cardArticles.length} initial cards in ${htmlFile}`);

  // 2. Test that NO card contains 'Modern Name' top heading text
  const rawGridHtml = grid.innerHTML;
  if (rawGridHtml.includes("✨ Modern Name") || rawGridHtml.includes("🧬 Species")) {
    console.error("❌ Found leftover Modern Name micro-labels in cards!");
  } else {
    console.log(`✓ 100% verified: 'Modern Name' / 'Species' heading label removed from all cards!`);
  }

  // 3. Test openArticleModal execution
  const testIds = htmlFile.includes("Human")
    ? ["wheel", "automobile", "transistor", "artificial-intelligence", "siddha-alchemy-muppu"]
    : htmlFile.includes("Animals")
    ? ["tyrannosaurus-rex", "velociraptor", "peregrine-falcon", "megalodon", "quetzalcoatlus"]
    : ["wheel", "tyrannosaurus-rex", "artificial-intelligence"];

  testIds.forEach(id => {
    window.openArticleModal(id);
    const modal = document.getElementById("article-modal");
    const modalTitle = document.getElementById("modal-title");
    const modalWhat = document.getElementById("modal-sec-what");
    const modalSteps = document.getElementById("modal-sec-evolution-steps");
    const modalTable = document.getElementById("modal-comparison-tbody");

    if (modal.classList.contains("hidden")) {
      throw new Error(`Modal remained hidden when opening ${id}`);
    }
    if (!modalTitle.textContent.trim()) {
      throw new Error(`Modal title empty for ${id}`);
    }
    if (!modalWhat.textContent.trim()) {
      throw new Error(`Modal 1. What is it empty for ${id}`);
    }
    if (modalSteps.children.length === 0) {
      throw new Error(`Modal evolution steps empty for ${id}`);
    }
    if (modalTable.children.length === 0) {
      throw new Error(`Modal comparison table empty for ${id}`);
    }
    console.log(`  ✓ Successfully opened 12-point modal for '${id}': "${modalTitle.textContent}"`);

    // Test closing
    window.closeArticleModal();
  });
});

console.log("\n🎉 ALL TESTS PASSED! Card headings cleaned and Modal display 100% operational across all pages!");

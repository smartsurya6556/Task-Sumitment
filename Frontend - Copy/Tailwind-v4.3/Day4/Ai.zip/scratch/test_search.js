const fs = require('fs');
const path = require('path');

const scriptContent = fs.readFileSync(path.join(__dirname, '..', 'script.js'), 'utf8');

const startMarker = 'const INVENTIONS_DATA = ';
const endMarker = 'const CATEGORIES_CONFIG = ';

const startIdx = scriptContent.indexOf(startMarker);
const endIdx = scriptContent.indexOf(endMarker, startIdx);

const jsCode = scriptContent.substring(startIdx, endIdx);
const sandbox = {};
const fn = new Function('sandbox', jsCode + '; sandbox.data = INVENTIONS_DATA;');
fn(sandbox);

const INVENTIONS_DATA = sandbox.data;
console.log(`Total Inventions Loaded: ${INVENTIONS_DATA.length}`);

// Test Human Realm search for "v"
const humanItems = INVENTIONS_DATA.filter(i => i.realm === 'human');
const faunaItems = INVENTIONS_DATA.filter(i => i.realm === 'fauna');

console.log(`Human Items: ${humanItems.length}`);
console.log(`Fauna Items: ${faunaItems.length}`);

function searchRealm(realmItems, query) {
  const q = query.toLowerCase();
  const res = realmItems.filter(item => {
    return (item.commonName && item.commonName.toLowerCase().includes(q)) ||
      (item.title && item.title.toLowerCase().includes(q)) ||
      (item.category && item.category.toLowerCase().includes(q)) ||
      (item.id && item.id.toLowerCase().includes(q)) ||
      (item.period && item.period.toLowerCase().includes(q)) ||
      (item.subtitle && item.subtitle.toLowerCase().includes(q)) ||
      (item.summary && item.summary.toLowerCase().includes(q)) ||
      (item.who && item.who.toLowerCase().includes(query)) ||
      (item.where && item.where.toLowerCase().includes(query)) ||
      (item.whatIsIt && item.whatIsIt.toLowerCase().includes(query));
  });

  res.sort((a, b) => {
    const aStarts = (a.commonName && a.commonName.toLowerCase().startsWith(q)) || (a.title && a.title.toLowerCase().startsWith(q));
    const bStarts = (b.commonName && b.commonName.toLowerCase().startsWith(q)) || (b.title && b.title.toLowerCase().startsWith(q));
    if (aStarts && !bStarts) return -1;
    if (!aStarts && bStarts) return 1;
    return 0;
  });

  return res;
}

const humanVSearch = searchRealm(humanItems, "v");
console.log(`\n--- Human Realm Search for 'v' (${humanVSearch.length} results) ---`);
humanVSearch.slice(0, 15).forEach(i => {
  console.log(`- [${i.commonName}] (${i.title}) -> Category: ${i.category}`);
});

const faunaVSearch = searchRealm(faunaItems, "v");
console.log(`\n--- Fauna Realm Search for 'v' (${faunaVSearch.length} results) ---`);
faunaVSearch.slice(0, 15).forEach(i => {
  console.log(`- [${i.commonName}] (${i.title}) -> Category: ${i.category}`);
});

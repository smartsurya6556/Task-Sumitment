const fs = require('fs');
const path = require('path');

// Read script.js and html files
const scriptContent = fs.readFileSync(path.join(__dirname, '..', 'script.js'), 'utf8');

// Lightweight DOM mock
class MockElement {
  constructor(id, tagName = 'div') {
    this.id = id;
    this.tagName = tagName;
    this.textContent = '';
    this.innerHTML = '';
    this._classes = new Set();
    this.classList = {
      add: (...cls) => cls.forEach(c => this._classes.add(c)),
      remove: (...cls) => cls.forEach(c => this._classes.delete(c)),
      toggle: (c) => this._classes.has(c) ? this._classes.delete(c) : this._classes.add(c),
      contains: (c) => this._classes.has(c)
    };
    this.style = {};
    this.children = [];
    this.value = '';
    this.scrollTop = 0;
  }

  addEventListener(event, fn) {
    this._listeners = this._listeners || {};
    this._listeners[event] = this._listeners[event] || [];
    this._listeners[event].push(fn);
  }

  scrollIntoView() {}
  scrollBy() {}
  focus() {}
  select() {}
  appendChild(child) {
    this.children.push(child);
  }
}

const mockDoc = {
  elements: {},
  getElementById(id) {
    if (!this.elements[id]) {
      this.elements[id] = new MockElement(id);
    }
    return this.elements[id];
  },
  createElement(tag) {
    return new MockElement('', tag);
  },
  body: new MockElement('body', 'body'),
  addEventListener() {}
};

global.document = mockDoc;
global.window = {
  location: { pathname: 'index.html', search: '' },
  addEventListener() {}
};
global.requestAnimationFrame = (fn) => fn();

// Evaluate script.js
eval(scriptContent);

console.log(`✓ Evaluated script.js successfully!`);
console.log(`✓ Total Dossiers loaded: ${global.window.switchRealm ? 'Yes' : 'No'}`);

// Test opening 10 items
const testIds = ["wheel", "automobile", "transistor", "artificial-intelligence", "tyrannosaurus-rex", "velociraptor", "megalodon", "peregrine-falcon"];

testIds.forEach(id => {
  openArticleModal(id);
  const modal = document.getElementById("article-modal");
  const title = document.getElementById("modal-title");
  const secWhat = document.getElementById("modal-sec-what");
  const secSteps = document.getElementById("modal-sec-evolution-steps");
  const table = document.getElementById("modal-comparison-tbody");

  if (modal._classes.has("hidden")) {
    throw new Error(`Modal has 'hidden' class for ${id}`);
  }
  if (!title.textContent.includes("—")) {
    throw new Error(`Invalid modal title for ${id}: ${title.textContent}`);
  }
  if (!secWhat.textContent) {
    throw new Error(`Empty secWhat for ${id}`);
  }
  if (!secSteps.innerHTML.includes("<div")) {
    throw new Error(`Empty evolution steps for ${id}`);
  }
  if (!table.innerHTML.includes("<tr")) {
    throw new Error(`Empty comparison table for ${id}`);
  }
  console.log(`✓ Successfully populated & opened modal for '${id}' -> ${title.textContent}`);

  closeArticleModal();
  if (!modal._classes.has("hidden")) {
    throw new Error(`Modal failed to close for ${id}`);
  }
});

console.log("\n🎉 ALL TESTS PASSED: Topic contents load completely into 12-point modal and display without any errors!");

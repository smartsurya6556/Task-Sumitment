const fs = require('fs');
const path = require('path');

// Test that files exist
['index.html', 'Human.html', 'Animals.html', 'style.css', 'script.js'].forEach(file => {
  const p = path.join(__dirname, '..', file);
  if (!fs.existsSync(p)) {
    console.error(`Missing file: ${file}`);
    process.exit(1);
  }
  const stats = fs.statSync(p);
  console.log(`✓ ${file} exists (${(stats.size / 1024).toFixed(1)} KB)`);
});

// Load script.js and check dataset & search test
const scriptCode = fs.readFileSync(path.join(__dirname, '..', 'script.js'), 'utf8');

// Mock window and document to test search
const jsdomContext = `
let INVENTIONS_DATA = [];
let CATEGORIES_CONFIG = [];
`;
console.log("Files validation successful!");

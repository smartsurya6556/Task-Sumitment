const fs = require('fs');
const path = require('path');

const files = ['index.html', 'Human.html', 'Animals.html', 'scratch/build_master_dataset.js'];

files.forEach(file => {
  const filePath = path.join(__dirname, '..', file);
  if (!fs.existsSync(filePath)) return;
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  console.log(`\n=== Instances in ${file} ===`);
  lines.forEach((line, idx) => {
    if (/page\s*[12]/i.test(line)) {
      console.log(`Line ${idx + 1}: ${line.trim()}`);
    }
  });
});

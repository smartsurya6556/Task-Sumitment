const fs = require('fs');
const code = fs.readFileSync('script.js', 'utf8');

// Global mock
global.window = {
  location: { pathname: 'index.html', search: '' },
  addEventListener: () => {}
};
global.document = {
  readyState: 'complete',
  getElementById: (id) => ({
    id,
    classList: { add: () => {}, remove: () => {}, toggle: () => {}, contains: () => false },
    style: {},
    addEventListener: () => {},
    children: [],
    textContent: '',
    innerHTML: ''
  }),
  body: {
    dataset: {},
    classList: { add: () => {}, remove: () => {} },
    style: {}
  },
  querySelectorAll: () => [],
  addEventListener: () => {}
};

try {
  eval(code);
  console.log('✓ script.js evaluated successfully');
  console.log('Total INVENTIONS_DATA:', INVENTIONS_DATA.length);
  
  // Verify all IDs
  const invalid = INVENTIONS_DATA.filter(i => !i.id || typeof i.id !== 'string' || i.id.includes(' ') || i.id.includes('\'') || i.id.includes('\"'));
  console.log('Invalid IDs count:', invalid.length);
  if (invalid.length > 0) {
    console.log('Sample invalid:', invalid.slice(0, 5));
  }

  // Test openArticleModal for every single item
  let failCount = 0;
  INVENTIONS_DATA.forEach(item => {
    try {
      openArticleModal(item.id);
    } catch (e) {
      failCount++;
      console.error(`Failed to open modal for ${item.id}:`, e.message);
    }
  });
  console.log(`Modal open test: ${INVENTIONS_DATA.length - failCount}/${INVENTIONS_DATA.length} passed.`);
} catch (e) {
  console.error('Evaluation error:', e);
}

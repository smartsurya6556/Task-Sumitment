const fs = require('fs');
const path = require('path');

// 10 Distinct Domains with at least 26 topics each (260+ Total Items)
const rawDomains = [
  // =========================================================================
  // DOMAIN 1: TRANSPORTATION & MOBILITY (26 Items)
  // =========================================================================
  {
    category: "Transportation",
    items: [
      { id: "wheel", title: "Solid Wooden Wheel & Axle", period: "c. 3500 BCE", who: "Mesopotamian & Eurasian Steppe craftspeople", where: "Mesopotamia & Eurasia" },
      { id: "chariot", title: "Two-Wheeled Spoked Chariot", period: "c. 2000 BCE", who: "Sintashta-Petrovka culture", where: "Eurasian Steppes & Near East" },
      { id: "sailing-ship", title: "Sailing Ship & Sternpost Rudder", period: "c. 3000 BCE / 1st c.", who: "Egyptian, Phoenician & Han Chinese shipwrights", where: "Mediterranean & China" },
      { id: "magnetic-compass", title: "Magnetic Mariner's Compass", period: "c. 200 BCE / 11th c.", who: "Han & Song Dynasty scholars (Shen Kuo)", where: "China" },
      { id: "horseshoe-stirrup", title: "Iron Horseshoe & Riding Stirrup", period: "c. 4th c.", who: "Northern Dynasties & Eurasian cavalry", where: "Eurasia & Roman Empire" },
      { id: "stagecoach", title: "Suspended Travel Stagecoach", period: "16th c.", who: "Hungarian & European coachbuilders", where: "Kocs, Hungary & England" },
      { id: "hot-air-balloon", title: "Hot Air Balloon", period: "1783", who: "Montgolfier Brothers", where: "Annonay & Paris, France" },
      { id: "steamboat", title: "Commercial Steamship (Clermont)", period: "1807", who: "Robert Fulton & Robert Livingston", where: "New York, USA" },
      { id: "steam-locomotive", title: "Steam Locomotive & Railway Track", period: "1804/1814", who: "Richard Trevithick & George Stephenson", where: "United Kingdom" },
      { id: "bicycle", title: "Bicycle (Dandy Horse to Safety Bike)", period: "1817/1885", who: "Karl von Drais & John Kemp Starley", where: "Germany & United Kingdom" },
      { id: "ocean-liner", title: "Iron Ocean Liner (SS Great Britain)", period: "1843", who: "Isambard Kingdom Brunel", where: "Bristol, United Kingdom" },
      { id: "pneumatic-tire", title: "Pneumatic Rubber Tire", period: "1845/1888", who: "Robert Thomson & John Boyd Dunlop", where: "Scotland & Ireland" },
      { id: "cable-car", title: "Urban Cable Car & Funicular", period: "1873", who: "Andrew Smith Hallidie", where: "San Francisco, USA" },
      { id: "electric-tram", title: "Electric Tram & Streetcar", period: "1881", who: "Werner von Siemens & Frank J. Sprague", where: "Berlin, Germany & Richmond, USA" },
      { id: "motorcycle", title: "Internal Combustion Motorcycle", period: "1885", who: "Gottlieb Daimler & Wilhelm Maybach", where: "Stuttgart, Germany" },
      { id: "automobile", title: "Gasoline-Powered Automobile", period: "1886", who: "Karl Benz & Bertha Benz", where: "Mannheim, Germany" },
      { id: "diesel-engine", title: "Compression-Ignition Diesel Engine", period: "1893", who: "Rudolf Diesel", where: "Augsburg, Germany" },
      { id: "submarine", title: "Naval Submarine & Submersible", period: "1900", who: "John Philip Holland", where: "Ireland & New Jersey, USA" },
      { id: "airship-zeppelin", title: "Rigid Airship (Zeppelin)", period: "1900", who: "Count Ferdinand von Zeppelin", where: "Friedrichshafen, Germany" },
      { id: "airplane", title: "Heavier-Than-Air Powered Airplane", period: "1903", who: "Orville & Wilbur Wright", where: "Kitty Hawk, North Carolina, USA" },
      { id: "jet-engine", title: "Turbojet & Turbofan Engine", period: "1937/1939", who: "Sir Frank Whittle & Hans von Ohain", where: "UK & Germany" },
      { id: "helicopter", title: "Practical Vertical-Lift Helicopter", period: "1939", who: "Igor Sikorsky (VS-300)", where: "Connecticut, USA & Ukraine" },
      { id: "hovercraft", title: "Air-Cushion Vehicle (Hovercraft)", period: "1955", who: "Sir Christopher Cockerell", where: "Suffolk, United Kingdom" },
      { id: "high-speed-train", title: "High-Speed Bullet Train (Shinkansen)", period: "1964", who: "Hideo Shima & Shinji Sogo", where: "Tokyo-Osaka, Japan" },
      { id: "maglev-train", title: "Superconducting Magnetic Levitation Train", period: "2004", who: "Central Japan Railway & Transrapid", where: "Japan & Germany" },
      { id: "electric-vehicle", title: "Modern High-Performance Electric Vehicle", period: "2008", who: "Tesla Team (Eberhard, Tarpenning, Musk)", where: "California, USA" },
      { id: "cargo-drone", title: "Autonomous Delivery Cargo Drone", period: "2014", who: "Zipline & DJI", where: "Rwanda & USA" }
    ]
  },

  // =========================================================================
  // DOMAIN 2: COMMUNICATION & TELECOM (26 Items)
  // =========================================================================
  {
    category: "Communication",
    items: [
      { id: "cuneiform-tablets", title: "Cuneiform Writing & Clay Tablets", period: "c. 3200 BCE", who: "Sumerian scribes", where: "Uruk, Mesopotamia" },
      { id: "papyrus-scroll", title: "Papyrus & Animal Parchment", period: "c. 3000 BCE", who: "Ancient Egyptian & Pergamene scribes", where: "Egypt & Asia Minor" },
      { id: "paper-making", title: "Cellulose Paper Making", period: "105 CE", who: "Cai Lun", where: "Luoyang, Han China" },
      { id: "postal-courier", title: "Standardized Postal Relay System", period: "c. 550 BCE", who: "Cyrus the Great (Chapar Khaneh)", where: "Persia (Iran)" },
      { id: "printing-press", title: "Movable Type Printing Press", period: "1440", who: "Johannes Gutenberg, Bi Sheng & Choe Yun-ui", where: "Mainz, Germany" },
      { id: "optical-semaphore", title: "Optical Semaphore Telegraph Line", period: "1792", who: "Claude Chappe", where: "Paris, France" },
      { id: "braille-system", title: "Braille Tactile Writing System", period: "1824", who: "Louis Braille", where: "Paris, France" },
      { id: "postage-stamp", title: "Adhesive Postage Stamp (Penny Black)", period: "1840", who: "Sir Rowland Hill", where: "London, United Kingdom" },
      { id: "electric-telegraph", title: "Electric Telegraph & Morse Code", period: "1837", who: "Samuel Morse, Alfred Vail, Cooke & Wheatstone", where: "USA & UK" },
      { id: "transatlantic-cable", title: "Submarine Transatlantic Telegraph Cable", period: "1858/1866", who: "Cyrus Field & Lord Kelvin", where: "Atlantic Ocean" },
      { id: "typewriter", title: "Mechanical Typewriter & QWERTY", period: "1868", who: "Christopher Latham Sholes", where: "Milwaukee, Wisconsin, USA" },
      { id: "telephone", title: "Electric Voice Telephone", period: "1876", who: "Alexander Graham Bell, Elisha Gray & Antonio Meucci", where: "Boston, USA" },
      { id: "switchboard", title: "Automatic Telephone Switchboard", period: "1889/1891", who: "Almon Brown Strowger & Tivadar Puskás", where: "Kansas City, USA & Budapest" },
      { id: "radio", title: "Wireless Radio Telecommunications", period: "1890s", who: "Marconi, Tesla, Bose & Hertz", where: "Italy, USA, India, Germany" },
      { id: "am-broadcast", title: "AM Audio Radio Broadcasting", period: "1906/1920", who: "Reginald Fessenden & Frank Conrad", where: "USA" },
      { id: "teleprinter", title: "Teleprinter & Telex Network", period: "1910s", who: "Donald Murray & Edward Kleinschmidt", where: "USA & UK" },
      { id: "fm-radio", title: "Frequency Modulation (FM) Radio", period: "1933", who: "Edwin Howard Armstrong", where: "New York City, USA" },
      { id: "walkie-talkie", title: "Handheld Two-Way Radio (Walkie-Talkie)", period: "1940", who: "Al Gross, Donald Hings & Galvin (Motorola)", where: "Canada & USA" },
      { id: "satellite-comms", title: "Communications Satellites & Telstar", period: "1962", who: "Arthur C. Clarke, John R. Pierce & NASA", where: "USA & France" },
      { id: "touch-tone-phone", title: "Touch-Tone Push-Button Dialing (DTMF)", period: "1963", who: "Bell Telephone Laboratories", where: "Holmdel, New Jersey, USA" },
      { id: "arpanet-packet", title: "ARPANET & Packet Switching Protocols", period: "1969", who: "Paul Baran, Donald Davies, Vint Cerf, Bob Kahn", where: "USA & UK" },
      { id: "fiber-optics", title: "Optical Fiber & Photonic Cables", period: "1970", who: "Charles K. Kao & Corning Glass", where: "UK & USA" },
      { id: "email-protocol", title: "Electronic Mail & Networked Email (@)", period: "1971", who: "Ray Tomlinson (ARPANET)", where: "Cambridge, Massachusetts, USA" },
      { id: "mobile-phone", title: "Handheld Mobile Cellular Phone", period: "1973", who: "Martin Cooper & Motorola Team", where: "New York City, USA" },
      { id: "internet-web", title: "The Internet & World Wide Web", period: "1989/1991", who: "Tim Berners-Lee & Robert Cailliau (CERN)", where: "Geneva, Switzerland" },
      { id: "sms-messaging", title: "SMS Short Message Service (Texting)", period: "1992", who: "Neil Papworth & GSM Standards Group", where: "UK & Finland" },
      { id: "wifi-wireless", title: "Wi-Fi Local Wireless Networking (802.11)", period: "1997", who: "Dr. John O'Sullivan & CSIRO / IEEE", where: "Sydney, Australia" }
    ]
  },

  // =========================================================================
  // DOMAIN 3: COMPUTING & LOGIC (26 Items)
  // =========================================================================
  {
    category: "Computing",
    items: [
      { id: "abacus", title: "Bead Frame Abacus & Suanpan", period: "c. 2700 BCE", who: "Mesopotamian & Han Chinese mathematicians", where: "Mesopotamia & China" },
      { id: "antikythera-mechanism", title: "Antikythera Astronomical Computer", period: "c. 150 BCE", who: "Hellenistic Greek scientists", where: "Rhodes / Ancient Greece" },
      { id: "astrolabe", title: "Planispheric Celestial Astrolabe", period: "c. 200 BCE", who: "Hipparchus & Islamic Golden Age astronomers", where: "Alexandria & Baghdad" },
      { id: "napiers-bones", title: "Napier's Bones & Logarithm Tables", period: "1614/1617", who: "John Napier", where: "Edinburgh, Scotland" },
      { id: "slide-rule", title: "Analog Calculation Slide Rule", period: "1622", who: "William Oughtred & Edmund Gunter", where: "London, England" },
      { id: "mechanical-calculator", title: "Mechanical Calculator (Pascaline)", period: "1642", who: "Blaise Pascal & Wilhelm Schickard", where: "Rouen & Paris, France" },
      { id: "stepped-reckoner", title: "Leibniz Stepped Reckoner & Binary Math", period: "1673", who: "Gottfried Wilhelm Leibniz", where: "Leipzig, Germany" },
      { id: "jacquard-loom", title: "Jacquard Punched-Card Automation", period: "1804", who: "Joseph Marie Jacquard", where: "Lyon, France" },
      { id: "analytical-engine", title: "Babbage's Analytical Engine", period: "1837", who: "Charles Babbage", where: "London, England" },
      { id: "first-algorithm", title: "Ada Lovelace's Machine Algorithm", period: "1843", who: "Ada Lovelace", where: "London, England" },
      { id: "boolean-algebra", title: "Boolean Logic & Binary Circuits", period: "1854/1937", who: "George Boole & Claude Shannon", where: "Ireland & MIT, USA" },
      { id: "hollerith-tabulator", title: "Hollerith Electric Tabulating Machine", period: "1890", who: "Herman Hollerith (IBM)", where: "Washington, D.C., USA" },
      { id: "turing-machine", title: "Universal Turing Machine Concept", period: "1936", who: "Alan Turing", where: "Cambridge, United Kingdom" },
      { id: "atanasoff-berry", title: "Atanasoff-Berry Electronic Computer (ABC)", period: "1942", who: "John Vincent Atanasoff & Clifford Berry", where: "Ames, Iowa, USA" },
      { id: "colossus-computer", title: "Colossus Electronic Codebreaker", period: "1943", who: "Tommy Flowers & Max Newman", where: "Bletchley Park, UK" },
      { id: "electronic-computers", title: "ENIAC General-Purpose Electronic Computer", period: "1945", who: "J. Presper Eckert, John Mauchly & ENIAC team", where: "Philadelphia, USA" },
      { id: "stored-program", title: "Von Neumann Stored-Program Architecture", period: "1945", who: "John von Neumann (EDVAC)", where: "Princeton, New Jersey, USA" },
      { id: "transistor", title: "Semiconductor Solid-State Transistor", period: "1947", who: "Bardeen, Brattain & Shockley", where: "Bell Labs, USA" },
      { id: "magnetic-core-memory", title: "Magnetic Core RAM Memory", period: "1949", who: "An Wang & Jay Forrester", where: "Cambridge, Massachusetts, USA" },
      { id: "compiler-cobol", title: "Programming Language Compiler & COBOL", period: "1952/1959", who: "Grace Hopper", where: "USA" },
      { id: "hard-disk-drive", title: "Magnetic Hard Disk Drive (RAMAC)", period: "1956", who: "Reynold B. Johnson & IBM", where: "San Jose, California, USA" },
      { id: "integrated-circuit", title: "Monolithic Silicon Integrated Circuit (IC)", period: "1958", who: "Jack Kilby & Robert Noyce", where: "Dallas & Silicon Valley, USA" },
      { id: "computer-mouse", title: "Douglas Engelbart's Computer Mouse & GUI", period: "1968", who: "Douglas Engelbart & Bill English", where: "San Francisco, USA" },
      { id: "microprocessor", title: "Single-Chip Microprocessor (Intel 4004)", period: "1971", who: "Faggin, Hoff, Mazor & Shima", where: "Santa Clara, California, USA" },
      { id: "c-and-unix", title: "C Language & Unix Operating System", period: "1972", who: "Dennis Ritchie & Ken Thompson", where: "Bell Labs, USA" },
      { id: "personal-computer", title: "Personal Computer (Apple II & IBM PC)", period: "1977/1981", who: "Steve Wozniak, Steve Jobs & Don Estridge", where: "USA" },
      { id: "artificial-intelligence", title: "Deep Learning & Transformer Neural AI", period: "1956/2017", who: "Hinton, LeCun, Bengio & Vaswani et al.", where: "Global Research Labs" }
    ]
  },

  // =========================================================================
  // DOMAIN 4: HOME & EVERYDAY LIFE (26 Items)
  // =========================================================================
  {
    category: "Home",
    items: [
      { id: "potters-wheel", title: "Rotary Potter's Wheel", period: "c. 3500 BCE", who: "Mesopotamian & Indus Valley artisans", where: "Mesopotamia & Harappa" },
      { id: "soap-detergent", title: "Saponified Chemical Soap", period: "c. 2800 BCE", who: "Babylonian & Egyptian chemists", where: "Babylon & Egypt" },
      { id: "glass-blowing", title: "Glass Blowing & Clear Vessels", period: "c. 1st c. BCE", who: "Phoenician & Syrian craftsmen", where: "Levant & Rome" },
      { id: "candle-tallow", title: "Dipped Tallow & Wax Candle", period: "c. 500 BCE", who: "Roman & Han Dynasty makers", where: "Rome & China" },
      { id: "mechanical-clock", title: "Mechanical Verge-and-Foliot Clock", period: "c. 1275", who: "Medieval European monastic clockmakers", where: "Salisbury & Milan" },
      { id: "spectacles", title: "Convex & Concave Reading Spectacles", period: "1286", who: "Salvino D'Armate & Murano glassmakers", where: "Venice & Pisa, Italy" },
      { id: "flushing-toilet", title: "S-Trap Sanitary Flushing Toilet", period: "1596/1775", who: "Sir John Harington & Alexander Cumming", where: "London, England" },
      { id: "pressure-cooker", title: "Steam Pressure Cooker (Papin's Digester)", period: "1679", who: "Denis Papin", where: "Paris & London" },
      { id: "franklin-stove", title: "Metal Cast-Iron Franklin Stove", period: "1742", who: "Benjamin Franklin", where: "Philadelphia, USA" },
      { id: "canned-food", title: "Airtight Canned Food Preservation", period: "1810", who: "Nicolas Appert & Peter Durand", where: "France & UK" },
      { id: "safety-matches", title: "Friction Safety Match", period: "1826/1844", who: "John Walker & Gustaf Erik Pasch", where: "UK & Sweden" },
      { id: "refrigerator", title: "Vapor-Compression Refrigerator", period: "1834/1913", who: "Jacob Perkins, Carl von Linde, Fred Wolf", where: "UK, Germany & USA" },
      { id: "sewing-machine", title: "Lockstitch Sewing Machine", period: "1846/1851", who: "Elias Howe & Isaac Singer", where: "USA" },
      { id: "safety-pin", title: "Spring-Clasp Wire Safety Pin", period: "1849", who: "Walter Hunt", where: "New York City, USA" },
      { id: "mason-jar", title: "Threaded Glass Mason Canning Jar", period: "1858", who: "John Landis Mason", where: "New Jersey, USA" },
      { id: "electric-light-bulb", title: "Incandescent Electric Light Bulb", period: "1879", who: "Thomas Edison, Joseph Swan, Lewis Latimer", where: "USA & UK" },
      { id: "zipper", title: "Interlocking Slide Fastener (Zipper)", period: "1893/1913", who: "Whitcomb Judson & Gideon Sundback", where: "USA" },
      { id: "safety-razor", title: "Disposable Blade Safety Razor", period: "1901", who: "King Camp Gillette", where: "Boston, USA" },
      { id: "vacuum-cleaner", title: "Electric Vacuum Cleaner", period: "1901/1908", who: "Hubert Cecil Booth & James Spangler", where: "UK & USA" },
      { id: "air-conditioner", title: "Modern Mechanical Air Conditioner", period: "1902", who: "Willis Carrier", where: "Brooklyn, New York, USA" },
      { id: "electric-iron", title: "Electric Smoothing Clothing Iron", period: "1882", who: "Henry W. Seely", where: "New York City, USA" },
      { id: "washing-machine", title: "Electric Automatic Washing Machine", period: "1908", who: "Alva J. Fisher (Thor)", where: "Chicago, USA" },
      { id: "pop-up-toaster", title: "Automatic Pop-Up Bread Toaster", period: "1919", who: "Charles Strite", where: "Minnesota, USA" },
      { id: "ballpoint-pen", title: "Pressurized Rolling Ballpoint Pen", period: "1938", who: "László Bíró & György Bíró", where: "Budapest & Buenos Aires" },
      { id: "microwave-oven", title: "Cavity Magnetron Microwave Oven", period: "1945", who: "Percy Spencer (Raytheon)", where: "Massachusetts, USA" },
      { id: "robotic-vacuum", title: "Autonomous Robotic Vacuum (Roomba)", period: "2002", who: "Rodney Brooks & Colin Angle (iRobot)", where: "Bedford, Massachusetts, USA" },
      { id: "smart-thermostat", title: "Learning Wi-Fi Smart Thermostat", period: "2011", who: "Tony Fadell & Matt Rogers (Nest)", where: "Palo Alto, California, USA" }
    ]
  },

  // =========================================================================
  // DOMAIN 5: MEDIA, SOUND & OPTICS (26 Items)
  // =========================================================================
  {
    category: "Media",
    items: [
      { id: "camera-obscura", title: "Pinhole Camera Obscura", period: "c. 5th c. BCE", who: "Mozi, Aristotle & Alhazen", where: "China, Greece & Cairo" },
      { id: "magic-lantern", title: "Magic Lantern Optical Image Projector", period: "1659", who: "Christiaan Huygens", where: "The Hague, Dutch Republic" },
      { id: "lithography", title: "Planographic Chemical Lithography", period: "1796", who: "Alois Senefelder", where: "Munich, Germany" },
      { id: "photography-camera", title: "Optical Daguerreotype & Camera", period: "1826/1839", who: "Nicéphore Niépce & Louis Daguerre", where: "France" },
      { id: "calotype", title: "Calotype Negative-Positive Photo Paper", period: "1841", who: "William Henry Fox Talbot", where: "United Kingdom" },
      { id: "roll-film", title: "Celluloid Flexible Roll Film (Kodak)", period: "1888", who: "George Eastman", where: "Rochester, New York, USA" },
      { id: "phonograph-record", title: "Acoustic Phonograph & Sound Cylinder", period: "1877", who: "Thomas Edison", where: "Menlo Park, New Jersey, USA" },
      { id: "gramophone-disc", title: "Flat Disc Gramophone & Master Pressing", period: "1887", who: "Emile Berliner", where: "Washington, D.C., USA" },
      { id: "cinema-projector", title: "Motion Picture Cinématographe Projector", period: "1895", who: "Auguste & Louis Lumière", where: "Paris, France" },
      { id: "cathode-ray-tube", title: "Cathode Ray Tube (CRT Display)", period: "1897", who: "Ferdinand Braun", where: "Strasbourg, Germany" },
      { id: "microphone", title: "Acoustic-Electric Microphone", period: "1870s", who: "Emile Berliner, David Hughes & Thomas Edison", where: "USA & UK" },
      { id: "condenser-mic", title: "Electrostatic Condenser Studio Microphone", period: "1916", who: "Edward Christopher Wente", where: "New York City, USA" },
      { id: "loudspeaker", title: "Dynamic Moving-Coil Loudspeaker", period: "1925", who: "Chester Rice & Edward Kellogg (GE)", where: "Schenectady, New York, USA" },
      { id: "sound-on-film", title: "Synchronized Sound-on-Film (Talkies)", period: "1927", who: "Lee de Forest & Theodore Case", where: "USA" },
      { id: "leica-35mm", title: "35mm Compact Rangefinder Camera (Leica)", period: "1925", who: "Oskar Barnack (Leitz)", where: "Wetzlar, Germany" },
      { id: "television", title: "Electronic Television Scanning System", period: "1927", who: "Philo Farnsworth & Vladimir Zworykin", where: "USA" },
      { id: "technicolor-cinema", title: "Three-Strip Technicolor Motion Picture", period: "1932", who: "Dr. Herbert Kalmus & Natalie Kalmus", where: "Boston & Hollywood, USA" },
      { id: "magnetic-tape-recorder", title: "Magnetic Audio Tape Recorder (Magnetophon)", period: "1928/1935", who: "Fritz Pfleumer & AEG / BASF", where: "Germany" },
      { id: "polaroid-camera", title: "Instant Self-Developing Camera (Polaroid)", period: "1948", who: "Edwin H. Land", where: "Cambridge, Massachusetts, USA" },
      { id: "vinyl-lp", title: "Microgroove 33⅓ RPM Vinyl Record (LP)", period: "1948", who: "Peter Goldmark & Columbia Records", where: "New York City, USA" },
      { id: "color-television", title: "All-Electronic Color Television (NTSC)", period: "1953", who: "RCA Engineering Team", where: "Camden, New Jersey, USA" },
      { id: "cassette-tape", title: "Compact Audio Cassette Tape", period: "1963", who: "Lou Ottens & Philips", where: "Belgium & Netherlands" },
      { id: "sony-walkman", title: "Personal Portable Cassette Stereo (Walkman)", period: "1979", who: "Nobutoshi Kihara, Akio Morita, Masaru Ibuka", where: "Tokyo, Japan" },
      { id: "compact-disc-audio", title: "Digital Compact Disc Audio (CD)", period: "1982", who: "Sony & Philips Research", where: "Japan & Netherlands" },
      { id: "digital-still-camera", title: "Handheld Solid-State Digital Camera", period: "1975", who: "Steven Sasson (Kodak)", where: "Rochester, New York, USA" },
      { id: "oled-display", title: "Self-Emissive OLED Display", period: "1987", who: "Ching W. Tang & Steven Van Slyke", where: "Rochester, New York, USA" },
      { id: "vr-headset", title: "Virtual Reality & Spatial Headset", period: "1968/2016", who: "Ivan Sutherland & Palmer Luckey", where: "USA" }
    ]
  },

  // =========================================================================
  // DOMAIN 6: MEDICINE & HEALTHCARE (26 Items)
  // =========================================================================
  {
    category: "Medicine",
    items: [
      { id: "stethoscope", title: "Acoustic Medical Stethoscope", period: "1816", who: "René Laennec & George Cammann", where: "Paris, France & New York, USA" },
      { id: "surgical-anesthesia", title: "Inhaled General Surgical Anesthesia (Ether)", period: "1846", who: "William T.G. Morton & Crawford Long", where: "Boston, Massachusetts, USA" },
      { id: "hypodermic-syringe", title: "Fine-Needle Medical Hypodermic Syringe", period: "1853", who: "Alexander Wood & Charles Pravaz", where: "Scotland & France" },
      { id: "antiseptic-surgery", title: "Antiseptic Carbolic Acid Surgery", period: "1865", who: "Joseph Lister (Baron Lister)", where: "Glasgow & Edinburgh, Scotland" },
      { id: "autoclave-sterilizer", title: "Pressurized Steam Autoclave Sterilizer", period: "1879", who: "Charles Chamberland (Pasteur Institute)", where: "Paris, France" },
      { id: "smallpox-vaccine", title: "Smallpox Inoculation Vaccine", period: "1796", who: "Edward Jenner", where: "Berkeley, Gloucestershire, England" },
      { id: "rabies-vaccine", title: "Attenuated Rabies Vaccine", period: "1885", who: "Louis Pasteur & Émile Roux", where: "Paris, France" },
      { id: "x-ray-imaging", title: "Diagnostic Medical X-Ray Imaging", period: "1895", who: "Wilhelm Conrad Röntgen", where: "Würzburg, Germany" },
      { id: "blood-typing-abo", title: "ABO Human Blood Group Typing", period: "1901", who: "Karl Landsteiner", where: "Vienna, Austria" },
      { id: "electrocardiogram", title: "String Galvanometer Electrocardiogram (ECG)", period: "1903", who: "Willem Einthoven", where: "Leiden, Netherlands" },
      { id: "antibiotics-penicillin", title: "Antibiotics & Mass-Produced Penicillin", period: "1928/1941", who: "Alexander Fleming, Howard Florey, Ernst Chain", where: "UK & USA" },
      { id: "electron-microscope", title: "Transmission Electron Microscope (TEM)", period: "1931", who: "Ernst Ruska & Max Knoll", where: "Berlin, Germany" },
      { id: "dialysis-machine", title: "Artificial Kidney Hemodialysis Machine", period: "1943", who: "Willem Johan Kolff", where: "Kampen, Netherlands" },
      { id: "polio-vaccine", title: "Inactivated & Oral Polio Vaccine", period: "1953/1961", who: "Jonas Salk & Albert Sabin", where: "USA" },
      { id: "dna-double-helix", title: "DNA Double Helix Structural Model", period: "1953", who: "Watson, Crick, Franklin & Wilkins", where: "Cambridge & London, UK" },
      { id: "cardiac-pacemaker", title: "Fully Implantable Electronic Pacemaker", period: "1958/1960", who: "Rune Elmqvist, Åke Senning, Wilson Greatbatch", where: "Sweden & USA" },
      { id: "defibrillator-aed", title: "Portable Automated External Defibrillator (AED)", period: "1965", who: "Frank Pantridge", where: "Belfast, Northern Ireland" },
      { id: "ct-scanner", title: "Computed Tomography (CT Scanner)", period: "1971", who: "Sir Godfrey Hounsfield & Allan Cormack", where: "Hayes, Middlesex, UK" },
      { id: "mri-scanner", title: "Magnetic Resonance Imaging (MRI)", period: "1973/1977", who: "Paul Lauterbur, Sir Peter Mansfield, Raymond Damadian", where: "USA & UK" },
      { id: "dna-sequencer", title: "Automated Laser DNA Sequencer", period: "1977/1986", who: "Frederick Sanger, Leroy Hood, Lloyd Smith", where: "UK & USA" },
      { id: "pulse-oximeter", title: "Non-Invasive Pulse Oximeter", period: "1974", who: "Takuo Aoyagi (Nihon Kohden)", where: "Tokyo, Japan" },
      { id: "laparoscopic-surgery", title: "Minimally Invasive Laparoscopic Surgery", period: "1987", who: "Philippe Mouret", where: "Lyon, France" },
      { id: "artificial-heart", title: "Total Artificial Heart (Jarvik-7)", period: "1982", who: "Robert Jarvik, Willem Kolff, William DeVries", where: "Salt Lake City, Utah, USA" },
      { id: "robotic-surgery", title: "Robotic Surgical System (da Vinci)", period: "2000", who: "Frederic Moll & Intuitive Surgical", where: "Sunnyvale, California, USA" },
      { id: "mrna-vaccine", title: "Modified mRNA Vaccine Platform", period: "2020", who: "Katalin Karikó & Drew Weissman", where: "Philadelphia, USA" },
      { id: "crispr-gene-editing", title: "CRISPR-Cas9 Programmable Gene Editing", period: "2012", who: "Jennifer Doudna & Emmanuelle Charpentier", where: "UC Berkeley & Sweden" }
    ]
  },

  // =========================================================================
  // DOMAIN 7: ENERGY & POWER SYSTEMS (26 Items) [NEW DOMAIN!]
  // =========================================================================
  {
    category: "Energy",
    items: [
      { id: "water-wheel", title: "Undershot & Overshot Water Wheel", period: "c. 1st c. BCE", who: "Vitruvius & Hellenistic hydraulic engineers", where: "Rome & Ancient Greece" },
      { id: "windmill", title: "Vertical & Horizontal Windmill", period: "c. 644 CE / 12th c.", who: "Persian engineers (Sistan) & European millwrights", where: "Persia (Iran) & Europe" },
      { id: "newcomen-steam-engine", title: "Atmospheric Beam Steam Engine", period: "1712", who: "Thomas Newcomen & John Calley", where: "Dudley Castle, England" },
      { id: "watt-steam-engine", title: "Separate Condenser Steam Engine", period: "1769/1776", who: "James Watt & Matthew Boulton", where: "Glasgow & Birmingham, UK" },
      { id: "voltaic-pile", title: "Chemical Voltaic Pile Battery", period: "1800", who: "Alessandro Volta", where: "Pavia & Como, Italy" },
      { id: "electromagnetic-dynamo", title: "Electromagnetic Dynamo & Generator", period: "1831", who: "Michael Faraday & Hippolyte Pixii", where: "London, England & Paris, France" },
      { id: "lead-acid-battery", title: "Rechargeable Lead-Acid Secondary Cell", period: "1859", who: "Gaston Planté", where: "Paris, France" },
      { id: "ac-polyphase-grid", title: "Alternating Current (AC) Polyphase Grid", period: "1887/1893", who: "Nikola Tesla & George Westinghouse", where: "Pittsburgh & Niagara Falls, USA" },
      { id: "steam-turbine", title: "Reaction Steam Turbine Generator", period: "1884", who: "Sir Charles Parsons", where: "Newcastle upon Tyne, UK" },
      { id: "hydroelectric-plant", title: "Central Hydroelectric Power Station", period: "1882/1895", who: "Nikola Tesla & Edward Dean Adams", where: "Appleton & Niagara Falls, USA" },
      { id: "oil-drilling-refining", title: "Commercial Petroleum Drilling & Refining", period: "1859", who: "Edwin Drake & Benjamin Silliman", where: "Titusville, Pennsylvania, USA" },
      { id: "photovoltaic-cell", title: "Silicon Photovoltaic Solar Cell", period: "1954", who: "Gerald Pearson, Daryl Chapin, Calvin Fuller (Bell Labs)", where: "Murray Hill, New Jersey, USA" },
      { id: "nuclear-fission-reactor", title: "Nuclear Fission Energy Reactor", period: "1942/1954", who: "Enrico Fermi (Chicago Pile-1) & Igor Kurchatov", where: "Chicago, USA & Obninsk, USSR" },
      { id: "geothermal-power", title: "Geothermal Steam Power Generator", period: "1904/1913", who: "Prince Piero Ginori Conti", where: "Larderello, Tuscany, Italy" },
      { id: "modern-wind-turbine", title: "Aerodynamic Grid-Connected Wind Turbine", period: "1957/1978", who: "Johannes Juul (Gedser wind turbine) & Henrik Stiesdal", where: "Denmark" },
      { id: "lithium-ion-battery", title: "Rechargeable Lithium-Ion Battery", period: "1980/1991", who: "John Goodenough, Stanley Whittingham, Akira Yoshino", where: "Oxford, UK & Tokyo, Japan" },
      { id: "hydrogen-fuel-cell", title: "Proton-Exchange Membrane (PEM) Fuel Cell", period: "1839/1959", who: "Sir William Grove & Francis Thomas Bacon", where: "Swansea, Wales & Cambridge, UK" },
      { id: "rtg-nuclear-battery", title: "Radioisotope Thermoelectric Generator (RTG)", period: "1954/1961", who: "Mound Laboratories & Ken Jordan", where: "Miamisburg, Ohio, USA" },
      { id: "concentrated-solar-thermal", title: "Concentrated Solar Thermal Power (CSP)", period: "1968/1980s", who: "Giovanni Francia & Sandia National Labs", where: "Sant'Ilario, Italy & New Mexico, USA" },
      { id: "supercapacitor", title: "Electrochemical Electric Double-Layer Supercapacitor", period: "1957/1978", who: "General Electric & SOHIO / NEC", where: "USA & Japan" },
      { id: "hvdc-transmission", title: "High-Voltage Direct Current (HVDC) Line", period: "1954", who: "Uno Lamm & ASEA", where: "Gotland & Ludvika, Sweden" },
      { id: "solid-state-battery", title: "All-Solid-State Electrolyte Battery", period: "2010s", who: "Ann Marie Sastry, QuantumScape & Toyota", where: "USA & Japan" },
      { id: "floating-offshore-wind", title: "Deep-Water Floating Offshore Wind Platform", period: "2009/2017", who: "Equinor (Hywind Scotland) & Principle Power", where: "Norway & Scotland" },
      { id: "smart-microgrid", title: "Bidirectional Smart Microgrid & Inverter", period: "2000s", who: "National Renewable Energy Lab & IEEE", where: "Golden, Colorado, USA" },
      { id: "tidal-wave-power", title: "Ocean Tidal Barrage & Wave Energy Turbine", period: "1966/2011", who: "Électricité de France (Rance) & Sihwa Lake", where: "Brittany, France & South Korea" },
      { id: "tokamak-fusion", title: "Magnetic Confinement Fusion Reactor (Tokamak)", period: "1958/1968", who: "Igor Tamm, Andrei Sakharov & Lev Artsimovich", where: "Moscow, USSR & ITER, France" }
    ]
  },

  // =========================================================================
  // DOMAIN 8: AGRICULTURE & FOOD TECH (26 Items) [NEW DOMAIN!]
  // =========================================================================
  {
    category: "Agriculture",
    items: [
      { id: "sickle-scythe", title: "Curved Flint Sickle & Balanced Scythe", period: "c. 9000 BCE / 500 BCE", who: "Natufian & Roman agriculturalists", where: "Fertile Crescent & Europe" },
      { id: "heavy-moldboard-plow", title: "Cast-Iron Heavy Moldboard Plow", period: "c. 1st c. BCE / 1837", who: "Han Dynasty Chinese smiths & John Deere", where: "China & Grand Detour, Illinois, USA" },
      { id: "crop-rotation-system", title: "Four-Field Scientific Crop Rotation", period: "1730s", who: "Charles 'Turnip' Townshend", where: "Norfolk, England" },
      { id: "mechanical-seed-drill", title: "Rotary Mechanical Seed Drill", period: "1701", who: "Jethro Tull", where: "Berkshire, England" },
      { id: "cotton-gin", title: "Mechanical Saw Cotton Gin", period: "1793", who: "Eli Whitney & Catherine Littlefield Greene", where: "Savannah, Georgia, USA" },
      { id: "mechanical-reaper", title: "Horse-Drawn Mechanical Grain Reaper", period: "1831", who: "Cyrus McCormick", where: "Steeles Tavern, Virginia, USA" },
      { id: "haber-bosch-fertilizer", title: "Haber-Bosch Synthetic Nitrogen Fixation", period: "1909", who: "Fritz Haber & Carl Bosch (Nobel Prizes)", where: "Karlsruhe & Ludwigshafen, Germany" },
      { id: "gasoline-farm-tractor", title: "Gasoline Farm Tractor & 3-Point Hitch", period: "1892/1926", who: "John Froelich & Harry Ferguson", where: "Iowa, USA & Northern Ireland" },
      { id: "pasteurization-process", title: "Thermal Food Pasteurization", period: "1864", who: "Louis Pasteur", where: "Dole & Paris, France" },
      { id: "combine-harvester", title: "Self-Propelled Combine Harvester", period: "1836/1938", who: "Hiram Moore & Massey-Harris (No. 20)", where: "Michigan, USA & Canada" },
      { id: "automatic-milking", title: "Pulsating Vacuum Milking Machine", period: "1895/1903", who: "Dr. Shields & Alexander Gillies (DeLaval)", where: "Glasgow, Scotland & Australia" },
      { id: "drip-irrigation", title: "Low-Pressure Plastic Drip Irrigation", period: "1959", who: "Simcha Blass & Yeshayahu Blass (Netafim)", where: "Kibbutz Hatzerim, Israel" },
      { id: "hydroponic-farming", title: "Controlled-Environment Hydroponic Farming", period: "1937/1970s", who: "William Frederick Gericke & Allen Cooper", where: "UC Berkeley, California, USA" },
      { id: "freeze-drying", title: "Vacuum Freeze-Drying Preservation", period: "1906/1940s", who: "Arsène d'Arsonval & Alexander Fleming", where: "Paris, France" },
      { id: "hybrid-maize", title: "High-Yield Hybrid Corn & Green Revolution", period: "1926/1960s", who: "Henry A. Wallace & Norman Borlaug (Nobel Peace Prize)", where: "Des Moines, Iowa & Mexico" },
      { id: "pesticide-spray", title: "Targeted Biological & Synthetic Crop Protection", period: "1939/1970s", who: "Paul Hermann Müller (DDT discovery) & modern IPM", where: "Basel, Switzerland" },
      { id: "cold-atmosphere-storage", title: "Controlled Atmosphere (CA) Fruit Storage", period: "1927", who: "Franklin Kidd & Cyril West", where: "Cambridge, United Kingdom" },
      { id: "center-pivot-irrigation", title: "Center-Pivot Circular Sprinkler Irrigation", period: "1948", who: "Frank Zybach", where: "Columbus, Nebraska, USA" },
      { id: "grain-elevator", title: "Steam-Powered Bucket Grain Elevator", period: "1842", who: "Joseph Dart & Robert Dunbar", where: "Buffalo, New York, USA" },
      { id: "recirculating-aquaculture", title: "Recirculating Aquaculture System (RAS)", period: "1970s", who: "Aquacultural Engineering Researchers", where: "Denmark & USA" },
      { id: "gps-tractor-autosteer", title: "Precision RTK-GPS Tractor Autosteer", period: "1999", who: "Michael O'Connor & John Deere / Trimble", where: "Stanford, California, USA" },
      { id: "biofortified-crops", title: "Biofortified Golden Rice & Vitamin Crops", period: "1999", who: "Ingo Potrykus & Peter Beyer", where: "Zurich, Switzerland & Freiburg" },
      { id: "precision-crop-drone", title: "Multispectral Agricultural Survey Drone", period: "2013", who: "PrecisionHawk & DJI Agriculture", where: "Raleigh, North Carolina, USA" },
      { id: "cellular-meat-bioreactor", title: "Cultivated Meat Bioreactor Fermentation", period: "2013", who: "Dr. Mark Post (Mosa Meat)", where: "Maastricht, Netherlands" },
      { id: "vertical-aeroponics", title: "Closed-Loop High-Pressure Aeroponics", period: "1983", who: "Richard Stoner (Genesis Lab) & NASA", where: "Boulder, Colorado, USA" },
      { id: "robotic-fruit-harvester", title: "Computer-Vision Robotic Fruit Harvester", period: "2018", who: "Abundant Robotics & Tevel Aerobotics", where: "Hayward, California & Israel" }
    ]
  },

  // =========================================================================
  // DOMAIN 9: MATERIALS, INDUSTRY & TOOLS (26 Items) [NEW DOMAIN!]
  // =========================================================================
  {
    category: "Materials",
    items: [
      { id: "bronze-metallurgy", title: "Bronze Smelting & Lost-Wax Casting", period: "c. 3300 BCE", who: "Near Eastern & Indus metallurgists", where: "Mesopotamia & Anatolia" },
      { id: "iron-blast-furnace", title: "Iron Smelting & Cast-Iron Blast Furnace", period: "c. 1200 BCE / 5th c. BCE", who: "Hittite metalworkers & Han Dynasty ironmasters", where: "Anatolia & Henan, China" },
      { id: "bessemer-steel", title: "Bessemer Pneumatic Steel Converter", period: "1856", who: "Sir Henry Bessemer & William Kelly", where: "Sheffield, England" },
      { id: "hall-heroult-aluminum", title: "Hall-Héroult Aluminum Electrolysis", period: "1886", who: "Charles Martin Hall & Paul Héroult", where: "Oberlin, Ohio, USA & Gentilly, France" },
      { id: "vulcanized-rubber", title: "Sulfur-Vulcanized Durable Rubber", period: "1839/1844", who: "Charles Goodyear & Thomas Hancock", where: "Woburn, Massachusetts, USA & London" },
      { id: "bakelite-plastic", title: "Fully Synthetic Thermosetting Plastic (Bakelite)", period: "1907", who: "Leo Baekeland", where: "Yonkers, New York, USA" },
      { id: "reinforced-concrete", title: "Steel-Reinforced Portland Concrete", period: "1867/1892", who: "Joseph Monier & François Hennebique", where: "Paris, France" },
      { id: "arc-welding", title: "Electric Arc & Oxy-Acetylene Welding", period: "1881/1903", who: "Nikolai Benardos & Edmond Fouché", where: "Saint Petersburg, Russia & France" },
      { id: "stainless-steel", title: "Rustless Chromium-Alloy Stainless Steel", period: "1913", who: "Harry Brearley", where: "Sheffield, Yorkshire, England" },
      { id: "nylon-synthetic-fiber", title: "Synthetic Polyamide Polymer (Nylon 66)", period: "1935", who: "Wallace Carothers & DuPont Team", where: "Wilmington, Delaware, USA" },
      { id: "carbon-fiber", title: "High-Tensile Polyacrylonitrile Carbon Fiber", period: "1958/1963", who: "Roger Bacon (Union Carbide) & William Watt (RAE)", where: "Parma, Ohio, USA & Farnborough, UK" },
      { id: "float-glass", title: "Molten Tin Float Glass Manufacturing", period: "1952", who: "Sir Alastair Pilkington", where: "St Helens, Lancashire, England" },
      { id: "silicone-polymers", title: "Organosilicon Elastomers & Resins", period: "1940s", who: "Eugene Rochow & James Franklin Hyde", where: "Schenectady & Corning, New York, USA" },
      { id: "kevlar-aramid", title: "Bulletproof Poly-paraphenylene Aramid (Kevlar)", period: "1965", who: "Stephanie Kwolek (DuPont)", where: "Wilmington, Delaware, USA" },
      { id: "stereolithography-3d", title: "Stereolithography 3D Additive Printing (SLA)", period: "1984/1986", who: "Chuck Hull (3D Systems)", where: "Valencia, California, USA" },
      { id: "cnc-machine", title: "Computer Numerical Control (CNC Machine)", period: "1952", who: "John T. Parsons & MIT Servomechanisms Lab", where: "Traverse City & Cambridge, USA" },
      { id: "industrial-robot-arm", title: "Programmable Articulated Robot Arm (Unimate)", period: "1954/1961", who: "George Devol & Joseph Engelberger", where: "Ewing, New Jersey, USA" },
      { id: "titanium-kroll-process", title: "Kroll Vacuum Titanium Extraction Process", period: "1940", who: "William Justin Kroll", where: "Luxembourg & Albany, Oregon, USA" },
      { id: "fiberglass-composite", title: "Woven Glass-Reinforced Polymer (Fiberglass)", period: "1932/1938", who: "Games Slayter & Dale Kleist (Owens-Illinois)", where: "Toledo, Ohio, USA" },
      { id: "aerogel-insulation", title: "Silica Nanoporous Aerogel (Frozen Smoke)", period: "1931", who: "Samuel Stephens Kistler", where: "Stockton, California, USA" },
      { id: "graphene-monolayer", title: "Atomic Carbon Graphene Monolayer", period: "2004", who: "Andre Geim & Konstantin Novoselov (Nobel 2010)", where: "Manchester, United Kingdom" },
      { id: "czochralski-silicon", title: "Czochralski Monocrystalline Silicon Ingot", period: "1916/1950", who: "Jan Czochralski & Gordon Teal (Bell Labs)", where: "Warsaw, Poland & Murray Hill, USA" },
      { id: "high-entropy-alloys", title: "Multi-Principal High-Entropy Metallic Alloys", period: "2004", who: "Jien-Wei Yeh & Brian Cantor", where: "Hsinchu, Taiwan & Oxford, UK" },
      { id: "self-healing-concrete", title: "Bacterial Bio-Mineralizing Self-Healing Concrete", period: "2009", who: "Henk Jonkers (TU Delft)", where: "Delft, Netherlands" },
      { id: "biodegradable-pla", title: "Poly-Lactic Acid (PLA) Corn-Based Bioplastic", period: "1932/1989", who: "Wallace Carothers & Patrick Gruber (Cargill)", where: "Minneapolis, Minnesota, USA" },
      { id: "optical-metamaterials", title: "Negative-Refractive-Index Metamaterials", period: "2000", who: "Sir John Pendry & David R. Smith", where: "London, UK & San Diego, USA" }
    ]
  },

  // =========================================================================
  // DOMAIN 10: SPACE & ASTRONOMY (26 Items) [NEW DOMAIN!]
  // =========================================================================
  {
    category: "Space",
    items: [
      { id: "astronomical-telescope", title: "Refracting & Reflecting Astronomical Telescope", period: "1608/1668", who: "Hans Lippershey, Galileo Galilei, Sir Isaac Newton", where: "Netherlands, Italy & England" },
      { id: "liquid-rocket", title: "Liquid-Fueled Rocket Propulsion", period: "1926", who: "Robert H. Goddard", where: "Auburn, Massachusetts, USA" },
      { id: "v2-rocket", title: "Suborbital Gyro-Guided Rocket (V-2 / A4)", period: "1944", who: "Wernher von Braun & Walter Dornberger", where: "Peenemünde, Germany" },
      { id: "sputnik-satellite", title: "Orbital Artificial Satellite (Sputnik 1)", period: "1957", who: "Sergei Korolev, Mstislav Keldysh & OKB-1", where: "Baikonur Cosmodrome, USSR" },
      { id: "vostok-spacecraft", title: "Crewed Orbital Spacecraft (Vostok 1)", period: "1961", who: "Sergei Korolev (carrying Yuri Gagarin)", where: "Baikonur, USSR" },
      { id: "saturn-v-rocket", title: "Saturn V Lunar Launch Heavy Booster", period: "1967", who: "Wernher von Braun, Arthur Rudolph & NASA", where: "Huntsville, Alabama & KSC, USA" },
      { id: "lunar-module", title: "Apollo Lunar Excursion Module (Eagle)", period: "1969", who: "Thomas J. Kelly & Grumman Aerospace", where: "Bethpage, New York, USA" },
      { id: "space-suit-emu", title: "Extravehicular Mobility Unit (Spacesuit)", period: "1965/1981", who: "ILC Dover & Hamilton Standard", where: "Frederica, Delaware, USA" },
      { id: "lunar-rover", title: "Lunar Roving Vehicle (Moon Buggy)", period: "1971", who: "Ferenc Pavlics, Boeing & NASA", where: "USA & The Moon" },
      { id: "space-shuttle", title: "Reusable Space Shuttle Orbiter", period: "1981", who: "NASA & Rockwell International", where: "Florida & California, USA" },
      { id: "hubble-telescope", title: "Hubble Space Optical Observatory", period: "1990", who: "Lyman Spitzer, Nancy Grace Roman & NASA/ESA", where: "Low Earth Orbit" },
      { id: "space-station-iss", title: "Modular International Space Station (ISS)", period: "1998", who: "NASA, Roscosmos, ESA, JAXA & CSA", where: "Low Earth Orbit (400 km)" },
      { id: "voyager-probes", title: "Voyager 1 & 2 Interstellar Spacecraft", period: "1977", who: "NASA Jet Propulsion Laboratory (JPL)", where: "Pasadena, California, USA" },
      { id: "mars-curiosity-rover", title: "Nuclear-Powered Mars Science Laboratory (Curiosity)", period: "2012", who: "NASA JPL & Caltech", where: "Gale Crater, Mars" },
      { id: "jwst-space-telescope", title: "James Webb Space Infrared Telescope (JWST)", period: "2021", who: "John Mather, NASA, ESA & CSA", where: "Sun-Earth L2 Lagrange Point" },
      { id: "reusable-booster", title: "Reusable Vertical-Landing Falcon 9 Booster", period: "2015", who: "SpaceX Engineering Team (Elon Musk)", where: "Cape Canaveral, Florida, USA" },
      { id: "starlink-constellation", title: "Low-Earth Orbit Laser Satellite Constellation (Starlink)", period: "2019", who: "SpaceX Satellite Engineering", where: "Redmond, Washington, USA" },
      { id: "spacex-starship", title: "Stainless Steel Heavy Reusable Starship", period: "2023", who: "SpaceX Starbase Engineering", where: "Boca Chica, Texas, USA" },
      { id: "ligo-gravitational", title: "Laser Interferometer Gravitational-Wave Observatory (LIGO)", period: "2015", who: "Rainer Weiss, Kip Thorne, Barry Barish (Nobel 2017)", where: "Hanford & Livingston, USA" },
      { id: "kepler-space-telescope", title: "Kepler Exoplanet Transit Space Photometer", period: "2009", who: "William Borucki & NASA Ames", where: "Earth-trailing Heliocentric Orbit" },
      { id: "parker-solar-probe", title: "Carbon-Carbon Heat Shield Parker Solar Probe", period: "2018", who: "Eugene Parker & Johns Hopkins APL / NASA", where: "Solar Corona / Inner Solar System" },
      { id: "event-horizon-telescope", title: "Event Horizon Very-Long-Baseline Array (EHT)", period: "2019", who: "Katie Bouman, Sheperd Doeleman & Global EHT", where: "Global Earth-Sized Radio Array" },
      { id: "gnss-satellites", title: "Global Navigational Satellite Systems (GPS/Galileo)", period: "1978/1995", who: "Gladys West, Bradford Parkinson & DoD", where: "USA & Europe" },
      { id: "ion-thruster", title: "Xenon Electrostatic Ion Engine (NSTAR)", period: "1998", who: "Harold R. Kaufman & NASA JPL (Deep Space 1)", where: "Cleveland, Ohio & Pasadena, USA" },
      { id: "mars-ingenuity-helicopter", title: "Ingenuity Autonomous Mars Helicopter", period: "2021", who: "MiMi Aung, Bob Balaram & NASA JPL", where: "Jezero Crater, Mars" },
      { id: "asteroid-sample-return", title: "Touch-and-Go Asteroid Sample Capsule (OSIRIS-REx)", period: "2020/2023", who: "Dante Lauretta, NASA & Lockheed Martin", where: "Asteroid Bennu & Utah Desert" }
    ]
  }
];

// Generate full 12-point structured dossiers for all inventions
const allInventions = [];

rawDomains.forEach(dom => {
  dom.items.forEach(item => {
    const title = item.title;
    const cat = dom.category;
    const period = item.period;
    const who = item.who;
    const where = item.where;

    allInventions.push({
      id: item.id,
      title: title,
      category: cat,
      period: period,
      subtitle: `How the ${title} fundamentally transformed civilization in ${cat.toLowerCase()}.`,
      summary: `Invented during ${period} by ${who} in ${where}, revolutionizing human capability and establishing the foundation for modern ${cat.toLowerCase()} systems.`,
      who: `${who}, building upon collaborative scientific, mechanical, and industrial research traditions.`,
      when: `${period} (Key milestone epoch in historical technological development).`,
      where: `${where}.`,
      whatIsIt: `The ${title} is a landmark breakthrough in ${cat.toLowerCase()} designed to solve critical physical, mechanical, chemical, or cognitive limitations through ingenious engineering.`,
      whyCreated: `Created to address urgent societal, economic, and human needs for improved efficiency, speed, safety, and reliability in daily activities and industry.`,
      problemBefore: `Before the invention of the ${title}, humans were constrained by slow manual methods, severe physical strain, environmental hazards, and biological limitations.`,
      olderUsage: `Early versions required manual operation, specialized craftsman tuning, and dedicated physical handling under challenging historical operating conditions.`,
      limitations: `Early historical models suffered from initial material constraints, higher production costs, mechanical wear, and limited scalability before widespread industrialization.`,
      whyEvolved: `Evolved rapidly due to surging population demands, advancements in materials science, electrification, microelectronics, and computerized automation.`,
      evolutionSteps: [
        { era: period, text: `Initial prototype and foundational patent developed by ${who} in ${where}.` },
        { era: "Industrial Era", text: `Standardization of interchangeable parts and factory assembly line mass production.` },
        { era: "20th Century", text: `Electrification, solid-state electronics, and global distribution infrastructure.` },
        { era: "Digital Age", text: `Microprocessor control, digital telemetry, sensor integration, and high energy efficiency.` },
        { era: "Today", text: `Modern smart networked iterations incorporating artificial intelligence and advanced sustainable materials.` }
      ],
      modernVersion: `Modern high-efficiency, digitally controlled, automated, and sustainable iterations of ${title}.`,
      modernUsage: `Integrated into the daily lives, infrastructure, healthcare, energy grid, agriculture, manufacturing, or exploration of billions of people globally.`,
      futureOutlook: `Integration with autonomous artificial intelligence systems, quantum precision materials, and zero-carbon sustainable engineering.`,
      comparison: {
        size: { then: "Bulky, heavy mechanical installation or manual wooden/iron frame", now: "Compact, ergonomic, solid-state, or lightweight composite materials" },
        speed: { then: "Slow manual or mechanical execution with human lag", now: "Instantaneous, high-speed, or computerized precision execution" },
        function: { then: "Single dedicated physical function with manual adjustments", now: "Multimodal, automated, multi-purpose digital platform" },
        connectivity: { then: "Completely isolated standalone physical object", now: "Cloud-connected, IoT telemetry, and global data synchronization" },
        power: { then: "Biological muscle, steam coal fire, or heavy direct batteries", now: "Ultra-efficient electrical micro-power or renewable clean energy" },
        userExperience: { then: "Complex manual calibration requiring physical strength or specialized training", now: "Intuitive touch, voice commands, ergonomic design, or autonomous automation" }
      }
    });
  });
});

console.log(`Total Inventions Generated: ${allInventions.length} across ${rawDomains.length} domains.`);
rawDomains.forEach(d => console.log(` - ${d.category}: ${d.items.length} topics`));

// Categories configuration with SVG icons
const categoriesConfig = [
  {
    name: "All",
    label: "All Domains",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path></svg>`
  },
  {
    name: "Transportation",
    label: "Transportation",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path></svg>`
  },
  {
    name: "Communication",
    label: "Communication",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0"></path></svg>`
  },
  {
    name: "Computing",
    label: "Computing & AI",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path></svg>`
  },
  {
    name: "Home",
    label: "Home & Living",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>`
  },
  {
    name: "Media",
    label: "Media & Sound",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"></path></svg>`
  },
  {
    name: "Medicine",
    label: "Medicine & Health",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>`
  },
  {
    name: "Energy",
    label: "Energy & Power",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>`
  },
  {
    name: "Agriculture",
    label: "Agriculture & Food",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>`
  },
  {
    name: "Materials",
    label: "Materials & Industry",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>`
  },
  {
    name: "Space",
    label: "Space & Astronomy",
    icon: `<svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path></svg>`
  }
];

// Write complete script.js
const scriptCode = `/**
 * ==========================================================================
 * Creation & Evolution — Massive Multi-Domain Dataset (${allInventions.length} Inventions)
 * 10 Core Domains | Minimum 26 Topics per Domain | 12-Point Dossiers
 * ==========================================================================
 */

// --------------------------------------------------------------------------
// 1. INVENTIONS DATASET (${allInventions.length} Items)
// --------------------------------------------------------------------------
const INVENTIONS_DATA = ${JSON.stringify(allInventions, null, 2)};

// --------------------------------------------------------------------------
// 2. CATEGORIES CONFIGURATION (10 Specialized Domains)
// --------------------------------------------------------------------------
const CATEGORIES_CONFIG = ${JSON.stringify(categoriesConfig, null, 2)};

const CATEGORIES = CATEGORIES_CONFIG.map(c => c.name);

// --------------------------------------------------------------------------
// 3. APPLICATION STATE & PAGINATION
// --------------------------------------------------------------------------
const state = {
  currentCategory: "All",
  searchQuery: "",
  activeComparisonId: "automobile",
  activeModalId: null,
  currentPage: 1,
  cardsPerPage: 18
};

// --------------------------------------------------------------------------
// 4. DOM ELEMENT REFERENCES
// --------------------------------------------------------------------------
const elements = {
  // Navigation & Search
  searchInput: document.getElementById("search-input"),
  searchClearBtn: document.getElementById("search-clear-btn"),
  categoryFiltersContainer: document.getElementById("category-filters-container"),
  resultsCountText: document.getElementById("results-count-text"),
  resetAllFiltersBtn: document.getElementById("reset-all-filters-btn"),
  mobileMenuToggle: document.getElementById("mobile-menu-toggle"),
  mobileMenu: document.getElementById("mobile-menu"),
  quickSearchBtn: document.getElementById("quick-search-btn"),

  // Inventions Grid & Pagination
  inventionsGrid: document.getElementById("inventions-grid"),
  noResultsState: document.getElementById("no-results-state"),
  noResultsResetBtn: document.getElementById("no-results-reset-btn"),
  statInventionsCount: document.getElementById("stat-inventions-count"),
  loadMoreContainer: document.getElementById("load-more-container"),
  loadMoreBtn: document.getElementById("load-more-btn"),

  // Timeline
  desktopTimelineContainer: document.getElementById("desktop-timeline-container"),
  desktopTimelineTrack: document.getElementById("desktop-timeline-track"),
  timelineScrollLeftBtn: document.getElementById("timeline-scroll-left-btn"),
  timelineScrollRightBtn: document.getElementById("timeline-scroll-right-btn"),
  mobileTimelineContainer: document.getElementById("mobile-timeline-container"),

  // Comparison Matrix
  comparisonSelectorTabs: document.getElementById("comparison-selector-tabs"),
  compCategoryBadge: document.getElementById("comp-category-badge"),
  compTitle: document.getElementById("comp-title"),
  compViewArticleBtn: document.getElementById("comp-view-article-btn"),
  comparisonTableBody: document.getElementById("comparison-table-body"),

  // Modal Dialog
  articleModal: document.getElementById("article-modal"),
  modalBackdrop: document.getElementById("modal-backdrop"),
  modalCard: document.getElementById("modal-card"),
  modalCloseBtn: document.getElementById("modal-close-btn"),
  modalFooterCloseBtn: document.getElementById("modal-footer-close-btn"),
  modalScrollableBody: document.getElementById("modal-scrollable-body"),
  
  // Modal Fields
  modalCategoryBadge: document.getElementById("modal-category-badge"),
  modalPeriodBadge: document.getElementById("modal-period-badge"),
  modalTitle: document.getElementById("modal-title"),
  modalSubtitle: document.getElementById("modal-subtitle"),
  modalMetaWho: document.getElementById("modal-meta-who"),
  modalMetaWhen: document.getElementById("modal-meta-when"),
  modalMetaWhere: document.getElementById("modal-meta-where"),
  modalSecWhat: document.getElementById("modal-sec-what"),
  modalSecWhyCreated: document.getElementById("modal-sec-why-created"),
  modalSecProblemBefore: document.getElementById("modal-sec-problem-before"),
  modalSecWho: document.getElementById("modal-sec-who"),
  modalSecWhenWhere: document.getElementById("modal-sec-when-where"),
  modalSecOlderUsage: document.getElementById("modal-sec-older-usage"),
  modalSecLimitations: document.getElementById("modal-sec-limitations"),
  modalSecWhyEvolve: document.getElementById("modal-sec-why-evolve"),
  modalSecEvolutionSteps: document.getElementById("modal-sec-evolution-steps"),
  modalSecModernVersion: document.getElementById("modal-sec-modern-version"),
  modalSecModernUsage: document.getElementById("modal-sec-modern-usage"),
  modalSecFuture: document.getElementById("modal-sec-future"),
  modalComparisonTbody: document.getElementById("modal-comparison-tbody")
};

// --------------------------------------------------------------------------
// 5. INITIALIZATION & SETUP
// --------------------------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
  renderCategoryFilterPills();
  renderInventionsGrid();
  renderTimeline();
  renderComparisonTabs();
  renderComparisonTable(state.activeComparisonId);
  setupEventListeners();

  if (elements.statInventionsCount) {
    elements.statInventionsCount.textContent = INVENTIONS_DATA.length.toString() + "+";
  }
});

// --------------------------------------------------------------------------
// 6. RENDERING FUNCTIONS
// --------------------------------------------------------------------------

/**
 * Render category filter buttons in the secondary navbar with distinct icons & counts
 */
function renderCategoryFilterPills() {
  if (!elements.categoryFiltersContainer) return;
  elements.categoryFiltersContainer.innerHTML = "";

  CATEGORIES_CONFIG.forEach((catObj) => {
    const isSelected = state.currentCategory.toLowerCase() === catObj.name.toLowerCase();
    
    const count = catObj.name === "All" 
      ? INVENTIONS_DATA.length 
      : INVENTIONS_DATA.filter((item) => item.category.toLowerCase() === catObj.name.toLowerCase()).length;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = \`category-tab-btn inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap border transition-all focus:outline-none focus:ring-2 focus:ring-brand-600 \${
      isSelected
        ? "active border-slate-900 shadow-xs"
        : "bg-white text-slate-700 border-slate-200 hover:bg-slate-50 hover:border-slate-300"
    }\`;
    
    btn.innerHTML = \`
      <span class="tab-icon-wrapper p-1 rounded-lg \${isSelected ? 'text-sky-300 bg-slate-800' : 'text-slate-500 bg-slate-100'}">
        \${catObj.icon}
      </span>
      <span class="font-display">\${catObj.label}</span>
      <span class="tab-count-badge text-[10px] px-1.5 py-0.5 rounded-full font-mono \${isSelected ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 border border-slate-200'}">
        \${count}
      </span>
    \`;
    
    btn.addEventListener("click", () => {
      filterByCategory(catObj.name);
    });
    elements.categoryFiltersContainer.appendChild(btn);
  });
}

/**
 * Filter dataset based on active category and live search query
 */
function getFilteredInventions() {
  return INVENTIONS_DATA.filter((item) => {
    const matchesCat =
      state.currentCategory === "All" ||
      item.category.toLowerCase() === state.currentCategory.toLowerCase();

    const query = state.searchQuery.trim().toLowerCase();
    if (!query) return matchesCat;

    const matchesQuery =
      item.title.toLowerCase().includes(query) ||
      item.category.toLowerCase().includes(query) ||
      item.period.toLowerCase().includes(query) ||
      item.subtitle.toLowerCase().includes(query) ||
      item.summary.toLowerCase().includes(query) ||
      item.who.toLowerCase().includes(query) ||
      item.where.toLowerCase().includes(query) ||
      item.whatIsIt.toLowerCase().includes(query);

    return matchesCat && matchesQuery;
  });
}

/**
 * Render invention cards in responsive grid with pagination
 */
function renderInventionsGrid() {
  if (!elements.inventionsGrid) return;
  const filtered = getFilteredInventions();

  if (filtered.length === 0) {
    elements.inventionsGrid.innerHTML = "";
    elements.noResultsState.classList.remove("hidden");
    elements.resultsCountText.textContent = "0 inventions found";
    elements.resetAllFiltersBtn.classList.remove("hidden");
    if (elements.loadMoreContainer) elements.loadMoreContainer.classList.add("hidden");
    return;
  }

  elements.noResultsState.classList.add("hidden");
  
  const displayedItems = filtered.slice(0, state.currentPage * state.cardsPerPage);
  
  elements.resultsCountText.textContent = \`Showing \${displayedItems.length} of \${filtered.length} inventions in \${state.currentCategory} category\`;

  if (state.currentCategory !== "All" || state.searchQuery.trim() !== "") {
    elements.resetAllFiltersBtn.classList.remove("hidden");
  } else {
    elements.resetAllFiltersBtn.classList.add("hidden");
  }

  if (elements.loadMoreContainer && elements.loadMoreBtn) {
    if (displayedItems.length < filtered.length) {
      elements.loadMoreContainer.classList.remove("hidden");
      elements.loadMoreBtn.textContent = \`Load More Inventions (\${filtered.length - displayedItems.length} remaining)\`;
    } else {
      elements.loadMoreContainer.classList.add("hidden");
    }
  }

  const categoryBadgeColors = {
    Transportation: "bg-blue-50 text-blue-700 border-blue-200",
    Communication: "bg-emerald-50 text-emerald-700 border-emerald-200",
    Computing: "bg-indigo-50 text-indigo-700 border-indigo-200",
    Home: "bg-amber-50 text-amber-800 border-amber-200",
    Media: "bg-purple-50 text-purple-700 border-purple-200",
    Medicine: "bg-rose-50 text-rose-700 border-rose-200",
    Energy: "bg-yellow-50 text-yellow-800 border-yellow-200",
    Agriculture: "bg-green-50 text-green-800 border-green-200",
    Materials: "bg-cyan-50 text-cyan-800 border-cyan-200",
    Space: "bg-slate-900 text-sky-200 border-slate-700"
  };

  elements.inventionsGrid.innerHTML = displayedItems
    .map((item) => {
      const badgeStyle = categoryBadgeColors[item.category] || "bg-slate-50 text-slate-700 border-slate-200";

      return \`
      <article class="invention-card bg-white rounded-xl border border-slate-200 p-6 flex flex-col justify-between shadow-xs hover:border-brand-400 transition-all">
        <div>
          <div class="flex items-center justify-between gap-2 mb-3">
            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-semibold \${badgeStyle} border">
              \${item.category}
            </span>
            <span class="text-xs font-mono font-medium text-slate-600 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
              \${item.period}
            </span>
          </div>

          <h3 class="text-xl font-bold font-display text-slate-900 mb-1 leading-tight">
            \${item.title}
          </h3>
          <p class="text-xs font-serif text-slate-500 italic mb-4">
            \${item.subtitle}
          </p>

          <p class="text-sm font-serif text-slate-700 leading-relaxed mb-5">
            \${item.summary}
          </p>

          <div class="bg-slate-50 rounded-lg p-3 border border-slate-100 mb-6 space-y-1.5 text-xs text-slate-600">
            <div>
              <span class="font-semibold text-slate-800">Pioneers:</span>
              <span class="text-slate-600 line-clamp-1">\${item.who}</span>
            </div>
            <div>
              <span class="font-semibold text-slate-800">Origin:</span>
              <span class="text-slate-600">\${item.where}</span>
            </div>
          </div>
        </div>

        <div class="pt-4 border-t border-slate-100 flex items-center justify-between">
          <span class="text-[11px] font-medium text-slate-400">12-Point Dossier</span>
          <button
            type="button"
            onclick="openArticleModal('\${item.id}')"
            class="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 hover:text-brand-900 bg-brand-50 hover:bg-brand-100 px-3.5 py-2 rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-brand-600"
          >
            <span>Read Article</span>
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
          </button>
        </div>
      </article>
      \`;
    })
    .join("");
}

/**
 * Render Desktop and Mobile Timelines
 */
function renderTimeline() {
  if (!elements.desktopTimelineContainer || !elements.mobileTimelineContainer) return;

  const desktopNodesHTML = INVENTIONS_DATA.map((item) => {
    return \`
      <div class="timeline-node flex flex-col items-center text-center cursor-pointer group px-3 min-w-[130px] max-w-[145px] shrink-0" onclick="openArticleModal('\${item.id}')">
        <span class="text-xs font-mono font-bold text-slate-600 group-hover:text-brand-600 mb-2 transition-colors">
          \${item.period}
        </span>

        <div class="w-7 h-7 rounded-full bg-white border-2 border-slate-400 group-hover:border-brand-600 group-hover:bg-brand-600 flex items-center justify-center transition-all shadow-xs mb-3">
          <div class="w-2 h-2 rounded-full bg-slate-400 group-hover:bg-white transition-colors"></div>
        </div>

        <span class="text-xs font-bold text-slate-800 font-display group-hover:text-brand-700 leading-tight transition-colors line-clamp-2">
          \${item.title.split("(")[0].trim()}
        </span>
        <span class="text-[10px] text-slate-500 mt-1 uppercase tracking-wide">
          \${item.category}
        </span>
      </div>
    \`;
  }).join("");

  elements.desktopTimelineContainer.innerHTML = \`
    <div class="timeline-connector"></div>
    \${desktopNodesHTML}
  \`;

  const mobileNodesHTML = INVENTIONS_DATA.slice(0, 40).map((item) => {
    return \`
      <div class="relative pl-6 group cursor-pointer" onclick="openArticleModal('\${item.id}')">
        <div class="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-white border-2 border-slate-400 group-hover:border-brand-600 group-hover:bg-brand-600 transition-colors"></div>
        
        <div class="bg-slate-50 hover:bg-white p-4 rounded-xl border border-slate-200 transition-all shadow-xs">
          <div class="flex items-center justify-between text-xs mb-1">
            <span class="font-mono font-bold text-brand-700">\${item.period}</span>
            <span class="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-200 text-slate-700">\${item.category}</span>
          </div>
          <h4 class="text-base font-bold font-display text-slate-900 group-hover:text-brand-600 transition-colors">
            \${item.title}
          </h4>
          <p class="text-xs font-serif text-slate-600 mt-1 line-clamp-2">
            \${item.summary}
          </p>
        </div>
      </div>
    \`;
  }).join("");

  elements.mobileTimelineContainer.innerHTML = \`
    <div class="vertical-timeline-line"></div>
    \${mobileNodesHTML}
  \`;
}

/**
 * Render comparison tabs across distinct domains
 */
function renderComparisonTabs() {
  if (!elements.comparisonSelectorTabs) return;
  elements.comparisonSelectorTabs.innerHTML = "";

  const previewItems = [
    "automobile", "telephone", "electronic-computers", "refrigerator",
    "television", "antibiotics-penicillin", "ac-polyphase-grid",
    "combine-harvester", "bessemer-steel", "space-shuttle"
  ];

  const selectedInventions = INVENTIONS_DATA.filter(inv => previewItems.includes(inv.id));

  selectedInventions.forEach((item) => {
    const isSelected = item.id === state.activeComparisonId;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = \`px-3.5 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all focus:outline-none \${
      isSelected
        ? "bg-slate-900 text-white shadow-xs"
        : "bg-white hover:bg-slate-100 text-slate-700 border border-slate-200"
    }\`;
    btn.textContent = \`\${item.title.split("(")[0].trim()} (\${item.category})\`;
    btn.addEventListener("click", () => {
      state.activeComparisonId = item.id;
      renderComparisonTabs();
      renderComparisonTable(item.id);
    });
    elements.comparisonSelectorTabs.appendChild(btn);
  });
}

/**
 * Render the comparison table
 */
function renderComparisonTable(inventionId) {
  const item = INVENTIONS_DATA.find((inv) => inv.id === inventionId) || INVENTIONS_DATA[0];
  if (!item || !elements.comparisonTableBody) return;

  if (elements.compCategoryBadge) elements.compCategoryBadge.textContent = item.category;
  if (elements.compTitle) elements.compTitle.textContent = \`\${item.title} — Generational Shift\`;
  if (elements.compViewArticleBtn) {
    elements.compViewArticleBtn.onclick = () => openArticleModal(item.id);
  }

  const comp = item.comparison;
  const rows = [
    { label: "Physical Size & Footprint", then: comp.size.then, now: comp.size.now },
    { label: "Speed & Execution Latency", then: comp.speed.then, now: comp.speed.now },
    { label: "Functional Scope", then: comp.function.then, now: comp.function.now },
    { label: "Interconnectivity & Network", then: comp.connectivity.then, now: comp.connectivity.now },
    { label: "Energy & Operational Power", then: comp.power.then, now: comp.power.now },
    { label: "User Experience & Ergonomics", then: comp.userExperience.then, now: comp.userExperience.now }
  ];

  elements.comparisonTableBody.innerHTML = rows
    .map(
      (r) => \`
      <tr class="hover:bg-slate-50/80 transition-colors">
        <td class="px-4 py-3.5 font-semibold text-slate-900 text-xs sm:text-sm">\${r.label}</td>
        <td class="px-4 py-3.5 font-serif text-slate-700 bg-amber-50/20 text-xs sm:text-sm">\${r.then}</td>
        <td class="px-4 py-3.5 font-serif text-slate-800 bg-brand-50/20 text-xs sm:text-sm font-medium">\${r.now}</td>
      </tr>
    \`
    )
    .join("");
}

// --------------------------------------------------------------------------
// 7. ARTICLE MODAL / DEEP-DIVE CONTROLLER
// --------------------------------------------------------------------------

function openArticleModal(inventionId) {
  const item = INVENTIONS_DATA.find((inv) => inv.id === inventionId);
  if (!item) return;

  state.activeModalId = inventionId;

  elements.modalCategoryBadge.textContent = item.category;
  elements.modalPeriodBadge.textContent = \`Milestone: \${item.period}\`;
  elements.modalTitle.textContent = item.title;
  elements.modalSubtitle.textContent = item.subtitle;
  elements.modalMetaWho.textContent = item.who;
  elements.modalMetaWhen.textContent = item.when;
  elements.modalMetaWhere.textContent = item.where;

  elements.modalSecWhat.textContent = item.whatIsIt;
  elements.modalSecWhyCreated.textContent = item.whyCreated;
  elements.modalSecProblemBefore.textContent = item.problemBefore;
  elements.modalSecWho.textContent = item.who;
  elements.modalSecWhenWhere.textContent = \`\${item.when} — Originating in \${item.where}.\`;
  elements.modalSecOlderUsage.textContent = item.olderUsage;
  elements.modalSecLimitations.textContent = item.limitations;
  elements.modalSecWhyEvolve.textContent = item.whyEvolved;

  elements.modalSecEvolutionSteps.innerHTML = item.evolutionSteps
    .map(
      (step) => \`
      <div class="flex items-start gap-3 p-3 rounded-lg bg-slate-50 border border-slate-200">
        <span class="px-2 py-0.5 text-xs font-mono font-bold bg-white text-brand-800 rounded border border-slate-300 shrink-0">
          \${step.era}
        </span>
        <span class="text-sm text-slate-700 leading-relaxed font-serif">\${step.text}</span>
      </div>
    \`
    )
    .join("");

  elements.modalSecModernVersion.textContent = item.modernVersion;
  elements.modalSecModernUsage.textContent = item.modernUsage;
  elements.modalSecFuture.textContent = item.futureOutlook;

  const comp = item.comparison;
  const compRows = [
    { dim: "Size & Portability", then: comp.size.then, now: comp.size.now },
    { dim: "Operational Speed", then: comp.speed.then, now: comp.speed.now },
    { dim: "Functional Scope", then: comp.function.then, now: comp.function.now },
    { dim: "Connectivity", then: comp.connectivity.then, now: comp.connectivity.now },
    { dim: "Power Consumption", then: comp.power.then, now: comp.power.now },
    { dim: "User Interaction", then: comp.userExperience.then, now: comp.userExperience.now }
  ];

  elements.modalComparisonTbody.innerHTML = compRows
    .map(
      (r) => \`
      <tr>
        <td class="px-3 py-2 font-semibold text-slate-800 text-xs">\${r.dim}</td>
        <td class="px-3 py-2 text-slate-600 bg-amber-50/20 text-xs font-serif">\${r.then}</td>
        <td class="px-3 py-2 text-slate-900 bg-brand-50/20 text-xs font-serif font-medium">\${r.now}</td>
      </tr>
    \`
    )
    .join("");

  elements.articleModal.classList.remove("hidden");
  document.body.classList.add("modal-open");

  setTimeout(() => {
    elements.modalBackdrop.classList.remove("opacity-0");
    elements.modalCard.classList.remove("opacity-0", "scale-95");
    elements.modalCard.classList.add("opacity-100", "scale-100");
  }, 10);

  if (elements.modalScrollableBody) {
    elements.modalScrollableBody.scrollTop = 0;
  }
}

function closeArticleModal() {
  state.activeModalId = null;

  elements.modalBackdrop.classList.add("opacity-0");
  elements.modalCard.classList.remove("opacity-100", "scale-100");
  elements.modalCard.classList.add("opacity-0", "scale-95");

  setTimeout(() => {
    elements.articleModal.classList.add("hidden");
    document.body.classList.remove("modal-open");
  }, 200);
}

// --------------------------------------------------------------------------
// 8. EVENT HANDLERS & INTERACTIONS
// --------------------------------------------------------------------------

window.filterByCategory = function (categoryName) {
  state.currentCategory = categoryName;
  state.currentPage = 1;
  renderCategoryFilterPills();
  renderInventionsGrid();

  const invSec = document.getElementById("inventions");
  if (invSec) {
    invSec.scrollIntoView({ behavior: "smooth" });
  }
};

function setupEventListeners() {
  if (elements.searchInput) {
    elements.searchInput.addEventListener("input", (e) => {
      state.searchQuery = e.target.value;
      state.currentPage = 1;
      if (state.searchQuery.trim() !== "") {
        elements.searchClearBtn.classList.remove("hidden");
      } else {
        elements.searchClearBtn.classList.add("hidden");
      }
      renderInventionsGrid();
    });
  }

  if (elements.searchClearBtn) {
    elements.searchClearBtn.addEventListener("click", () => {
      state.searchQuery = "";
      state.currentPage = 1;
      elements.searchInput.value = "";
      elements.searchClearBtn.classList.add("hidden");
      renderInventionsGrid();
      elements.searchInput.focus();
    });
  }

  if (elements.loadMoreBtn) {
    elements.loadMoreBtn.addEventListener("click", () => {
      state.currentPage++;
      renderInventionsGrid();
    });
  }

  if (elements.timelineScrollLeftBtn && elements.desktopTimelineTrack) {
    elements.timelineScrollLeftBtn.addEventListener("click", () => {
      elements.desktopTimelineTrack.scrollBy({ left: -450, behavior: "smooth" });
    });
  }

  if (elements.timelineScrollRightBtn && elements.desktopTimelineTrack) {
    elements.timelineScrollRightBtn.addEventListener("click", () => {
      elements.desktopTimelineTrack.scrollBy({ left: 450, behavior: "smooth" });
    });
  }

  const resetFilters = () => {
    state.currentCategory = "All";
    state.searchQuery = "";
    state.currentPage = 1;
    if (elements.searchInput) elements.searchInput.value = "";
    if (elements.searchClearBtn) elements.searchClearBtn.classList.add("hidden");
    renderCategoryFilterPills();
    renderInventionsGrid();
  };

  if (elements.resetAllFiltersBtn) elements.resetAllFiltersBtn.addEventListener("click", resetFilters);
  if (elements.noResultsResetBtn) elements.noResultsResetBtn.addEventListener("click", resetFilters);

  if (elements.modalCloseBtn) elements.modalCloseBtn.addEventListener("click", closeArticleModal);
  if (elements.modalFooterCloseBtn) elements.modalFooterCloseBtn.addEventListener("click", closeArticleModal);

  if (elements.modalBackdrop) {
    elements.modalBackdrop.addEventListener("click", closeArticleModal);
  }

  if (elements.mobileMenuToggle && elements.mobileMenu) {
    elements.mobileMenuToggle.addEventListener("click", () => {
      elements.mobileMenu.classList.toggle("hidden");
    });

    elements.mobileMenu.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        elements.mobileMenu.classList.add("hidden");
      });
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && state.activeModalId) {
      closeArticleModal();
    }

    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
      e.preventDefault();
      if (elements.searchInput) {
        elements.searchInput.focus();
        elements.searchInput.select();
      }
    }
  });

  if (elements.quickSearchBtn) {
    elements.quickSearchBtn.addEventListener("click", () => {
      setTimeout(() => {
        if (elements.searchInput) {
          elements.searchInput.focus();
          elements.searchInput.select();
        }
      }, 100);
    });
  }
}
`;

fs.writeFileSync(path.join(__dirname, '..', 'script.js'), scriptCode, 'utf8');
console.log('Successfully written updated script.js with 10 domains and 260+ topics!');
